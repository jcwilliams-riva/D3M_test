from pandas import DataFrame
import pandas as pd
import os
from typing import List, Dict, Tuple, Any

def transform(csv_path:str, output_dir:str):
    schema = {
        "Employee ID": "object",
        "Employee Name (Last/First/Mid)": "object",
        "Org ID": "object",
        "Organization Name": "object"
    }
    df:DataFrame = pd.read_csv(csv_path, dtype=schema)
    df.columns = ["EmpId", "EmpName", "OrgId", "OrgName"]
    employees:Dict[str,str] = {}
    orgs:Dict[str,str] = {}
    empOrgMap:List[Dict[str,str]] = []
    for row in df.to_numpy():
        empId:str = str(row[0]).strip()
        empName:str = str(row[1]).strip()
        orgId:str = str(row[2]).strip()
        orgName:str = str(row[3]).strip()
        orgs[orgId] = {
            "OrgId": orgId,
            "OrgName": orgName
        }
        empLastName, empFirstName = [str(n).strip() for n in empName.split(",")]
        empFirstName, *mid = empFirstName.split(" ")
        employees[empId] = {
            "EmpId": empId,
            "EmpLastName": empLastName,
            "EmpFirstName": empFirstName,
            "EmpMiddle": None if len(mid) == 0 else str(mid[0]).strip()
        }
        empOrgMap.append({
            "OrgId": orgId,
            "EmpId": empId
        })
    # for
    pd.DataFrame([val for key,val in employees.items()])\
        .to_csv(f"{output_dir}/Employee.csv", index=False)
        
    pd.DataFrame([val for key,val in orgs.items()])\
        .to_csv(f"{output_dir}/Org.csv", index=False)
        
    pd.DataFrame(empOrgMap)\
        .to_csv(f"{output_dir}/EmployeeOrgMap.csv", index=False)
# transform()
    
    
if __name__ == "__main__":
    transform('./csv/Employee Information.csv', './csv')
