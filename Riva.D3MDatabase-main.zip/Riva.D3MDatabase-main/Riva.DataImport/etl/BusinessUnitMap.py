from pandas import DataFrame
import pandas as pd
import os
from typing import List, Dict, Tuple, Any

def transform(csv_path:str, output_dir:str) -> List[Dict[str, Tuple[int, Any]]]:
    df = pd.read_csv(csv_path)
    lookup = {code:bu for bu,code in df.values}
    # BusinessUnit
    business_unit = df.iloc[:,0].unique()
    business_unit.sort()
    business_unit_lu = {val:id for id,val in enumerate(business_unit, start=1)}
    # ProejctCode
    project_code = df.iloc[:,1].unique()
    project_code.sort()
    project_name_code_lu = {val:id for id,val in enumerate(project_code, start=1)}
    # Build BusinessUnit to ProejctCode Map
    lookup_table = []
    for code, code_id in project_name_code_lu.items():
        bu = lookup[code]
        bu_id = business_unit_lu[bu]
        lookup_table.append((code_id, bu_id))
    # for
    
    df_business_unit = pd.DataFrame(
        columns=['BusinessUnitId', 'BusinessUnitName'],
        data=[(id,key) for key,id in business_unit_lu.items()]
    )
    df_business_unit.to_csv(f"{output_dir}/BusinessUnit.csv", index=False)
    
    df_project_code = pd.DataFrame(
        columns=['ProjectCodeId', 'ProjectCodeName'],
        data=[(id,key) for key,id in project_name_code_lu.items()]
    )
    df_project_code.to_csv(f"{output_dir}/ProjectCode.csv", index=False)
    
    df_project_code_map = pd.DataFrame(
        columns=['ProjectCodeId', 'BusinessUnitId'],
        data=lookup_table
    )
    df_project_code_map.to_csv(f"{output_dir}/ProjectCodeMap.csv", index=False)
    
    
if __name__ == "__main__":
    transform('./csv/BusinessUnitMap.csv', './csv')
