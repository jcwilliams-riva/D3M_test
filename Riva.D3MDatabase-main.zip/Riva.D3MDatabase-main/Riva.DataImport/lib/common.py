import json
import os
from typing import Dict, List


def get_json(filepath:str) -> Dict:
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)
   
    
def get_file(filepath:str) -> str:
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()