# RIVA Data Import Project

This code imports delimited files into a RDBMS. It's compatible with MSSQL, MySQL, PostgreSQL, and MariaDB.

The 'entry point' to import files is `./import_to_sql.py` in the root directory. It will import any delimited file in the `./csv` directory, as long as it is specified in the corresponding environment configuration in the `./env` directory:
* `./env/local.json` (for a local database instance)
* `./env/prod.json` (for the remote database instance in production)

## Set Database Credentials (username and password)
Database credential files are stored in the `./credentials` directory. By default, JSON files in this folder are excluded from the Git repository for security reasons. This configuration can only be stored on a local workstation. To set the credentials, rename the `./credentials/sql_server_user.json.template` to `sql_server_user.json`. Then edit the fields, entering your username and password for each environment (local|prod). For a local database, you may set `isTrusted` to false with no username or password, using your Windows identity for a local MSSQL server.
```json
{
    "local": {
        "server": "localhost",
        "dbname": "dbname",
        "username": null,
        "password": null,
        "isTrusted": true
    },
    "prod": {
        "server": "riva-data-analytics-d3m-0.database.windows.net,1433",
        "dbname": "RIVA_Azure_Data_Analytics_Project_D3M",
        "username": "username",
        "password": "password",
        "isTrusted": false
    }
}
```

## Import Configuration
To map a CSV file, or other delimited data file, to a database table, edit the configuration file that corresponds to the deployment environment in the `./env` directory. For example, if testing an import to a local database instance, set the `DatabaseConfig` and `ImportConfig` object literals in the `./env/local.json` file.
Example:
```json
{
    "database_config": {
        "server": "localhost", // the database server address; usually an IP address with a port number.
        "dbname": "dbname", // the name of the database
        "is_trusted": "yes" // or 'no' for username/password authentication
    },

    "csv_import_config": {
        "csv_dir": "csv", // the directory where to search for data files
        "files": [
            {
                "source": "data.csv", // filename of the data file
                "table_schema": "dbo", // the schema name of the table
                "table_name": "table_name", // the name of the destination table
                "include": true, // include/exclude from the import scipt
                "truncate": true, // delete all data from the destination table before importing the data
                "delimiter": "," // the delimiter; can be `\t` (tab), `|` (pipe), or some other designated delimter
            }
        ]
    }
}
```

The `database_config` object (above) maps to an instance of the `./models/DatabaseConfig.py` class.

The `csv_import_config` object (above) maps to an instance of the `./models/ImportConfig` class.

To parse the database configuration JSON file in Python, use the `from_json` static method of the `ImportConfig` class. For example:
```python
from models.ImportConfig import ImportConfig
from models.CsvImportConfig import CsvImportConfig
from models.DatabaseConfig import DatabaseConfig
from models.FileConfig import FileConfig
from typing import List

env:str = 'prod'
host_config:ImportConfig = ImportConfig.from_json(f"/env/{env}.json")
csv_import_config:CsvImportConfig = host_config.csv_import_config
database_config:DatabaseConfig = host_config.database_config
files:List[FileConfig] = csv_import_config.files
for cfg in files:
    tablename = f"{cfg.table_schema}.{cfg.table_name}"
    print(f"Importing data to {tablename}...")
    # import code here
# for
```
See `./import_to_sql.py` for the full code.

## Import Data
BEFORE importing data, <strong><u>the table must first be created in the destination database.</u></strong> The import class (`./lib/PyCsvImport.py`) will read the table schema in the database and convert values from the data file to the appropriate data type.

All files in the `./csv` directory are excluded for data privacy reasons. DATA IS NOT BACKED UP TO THE GIT REPO.

Download your CSV files to the `./csv` directory.

Once your configuration is complete, you can run `./import_to_sql.py` by opening it and pressing the 'play' icon in the upper right corner or run from the command line with:
```bash
python3 -m ./import_to_sql.py
```