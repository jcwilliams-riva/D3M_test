import os
import sys
sys.path.append('./')
sys.path.append('../')
from typing import Dict, List
from lib.PyCsvImport import PyCsvImport
import pyodbc
from models.ImportConfig import ImportConfig
from models.CsvImportConfig import CsvImportConfig
from models.DatabaseConfig import DatabaseConfig
from models.FileConfig import FileConfig
from lib.common import get_json

    
def get_connection_string(cfg:DatabaseConfig, username:str, password:str) -> str:
    """
    Returns a connection string for the given database config.
    :param cfg: The database config.
    :param username: The username to use for the connection.
    :param password: The password to use for the connection.
    :return: A connection string.
    """
    cs = f"""
    Driver={{SQL Server}};
    Server={cfg.server};
    Database={cfg.dbname};
    Trusted_Connection={cfg.is_trusted};
    """
    if cfg.is_trusted == 'no':
        cs += f"""
        UID={username};
        PWD={password};"""
    return cs
    
if __name__ == '__main__':
    # Set config vars here.
    env:str = 'prod' # Set the environment name. Values = local|dev|staging|prod
    create_sql_insert_files:bool = False # Set to True to create SQL insert files.
    batch_size:int = 1000 # Number of rows to insert at a time. 1000 is a good number.
    table_name_filter = [] # Set to a list of table names to only import those tables.
    #
    # Don't change below this line unless you know what you're doing.
    ROOT:str = os.curdir
    config_path = f"{ROOT}/env/{env}.json"
    host_config:ImportConfig = ImportConfig.from_json(config_path)
    csv_import_config:CsvImportConfig = host_config.csv_import_config
    database_config:DatabaseConfig = host_config.database_config
    files:List[FileConfig] = csv_import_config.files 
    if len(table_name_filter) > 0:
        files = [f for f in files if f.table_name in table_name_filter]
    #
    csv_dir:str = csv_import_config.csv_dir
    sql_server_credentials:Dict = get_json(f"{ROOT}/credentials/sql_server_user.json")
    username = sql_server_credentials[env]['username']
    password = sql_server_credentials[env]['password']
    cs:str = get_connection_string(database_config, username, password)
    get_connection = lambda: pyodbc.connect(cs)
    # Import CSV files.
    importer = PyCsvImport(connection=get_connection, column_name_qualifier='[]', batch_size=batch_size)
    importer.debug = True
    file_count = 0
    for cfg in files:
        if not cfg.include:
            continue
        tablename = f"{cfg.table_schema}.{cfg.table_name}"
        print(f"Importing data to {tablename}...")
        filepath = f"{ROOT}/{csv_dir}/{cfg.source}"
        
        if cfg.truncate:
            importer.execute_sql([f"TRUNCATE TABLE {tablename}"])
        
        results = importer.from_file(
            filepath
            , table_schema=cfg.table_schema
            , table_name=cfg.table_name
            , delimiter=cfg.delimiter
            , sql_only=create_sql_insert_files)
        
        if create_sql_insert_files:
            with open(f'./sql/{tablename}-{file_count}.sql', 'w') as fo:
                fo.write('\n'.join(results))
                
        file_count += 1
    # for
# if