from CVTimerTrigger2.services.CvPartnerImport import import_reports
import json
from typing import Dict, List
import asyncio

async def test_imports(auth_token, conn, base_url, query_string, report_types, tables):
    success = await import_reports(auth_token, conn, base_url, query_string, report_types, tables, True, True)
    assert success


if __name__ == '__main__':
    env: Dict = json.loads(open('./local.settings.json', 'r', encoding='utf-8').read())['Values']
    auth_token = env['AuthToken']
    conn = env['SqlServer']
    base_url = env['CvPartnerApiBaseUrl']
    query_string = env['CvPartnerQueryString']
    report_types: List[str] = str(env['CvPartnerReportTypes']).split(',')
    tables: List[str] = str(env['CvPartnerTables']).split(',') 
    
    asyncio.run( test_imports(auth_token, conn, base_url, query_string, report_types, tables) )