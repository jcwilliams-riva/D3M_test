from . import PyCsvImport as py
from requests import Response
from typing import List, Dict, Any
import time
import aiohttp
from aiohttp import ClientResponse
import requests
import os

def __log(msg: str, verbose=False):
    if verbose:
        print(msg)
        

def get_json_request(url: str, auth_token: str=None, type='GET') -> Any:
    headers = {
        "Accept": "application/json,text/plain"
    }
    
    if auth_token:
        headers["Authorization"] = f"Token token={auth_token}"
        
    res: Response = None
    try:
        if (type == 'POST'):
            res = requests.post(url, headers=headers)
        else:
            res = requests.get(url, headers=headers)
    except Exception as ex:
        raise ex
    
    if res is not None:
        return res.json()
    return None


def download_content(url) -> str:
    res = requests.get(url)
    content: str = res.content.decode('utf-8')
    return content


async def get_request_async(url: str, auth_token: str=None, type='GET') -> ClientResponse:
    headers = {
        "Accept": "application/json,text/plain"
    }
    
    if auth_token:
        headers["Authorization"] = f"Token token={auth_token}"
        
    response_obj: ClientResponse = None
    session = aiohttp.ClientSession()
    try:
        if (type == 'POST'):
            response_obj = await session.post(url, headers=headers)
        else:
            response_obj = await session.get(url, headers=headers)
    except Exception as ex:
        raise ex
    finally:
        await session.close()
        
    return response_obj

        
async def get_json_request_async(url: str, auth_token: str=None, type='GET') -> Any:
    res: ClientResponse = await get_request_async(url, auth_token, type)
    _json = await res.json(encoding='utf-8')
    return _json


async def get_text_request_async(url: str, auth_token: str=None, type='GET') -> str:
    res: ClientResponse = await get_request_async(url, auth_token, type)
    txt = await res.text(encoding='utf-8')
    return txt


def get_report_id(url: str, auth_token: str, verbose=False):
    __log(f"Making POST request to {url}...", verbose=verbose)
    report_json: Dict = get_json_request(url, auth_token, 'POST')
    __log(f"POST request received from {url}.", verbose=verbose)
    report_id = report_json['_id']
    __log(f"Retrieved report ID '{report_id}'", verbose=verbose)
    return report_id


def get_report_url(base_url: str, report_id: str, auth_token: str, verbose=False):
    res_json: Dict = None
    report_url = f'{base_url}/{report_id}'
    while True:
        __log(f"Making GET request to {report_url}...", verbose=verbose)
        res_json: Dict = get_json_request(report_url, auth_token, 'GET')
        __log(f"GET request received from {report_url}.", verbose=verbose)    
        state = res_json['state']
        __log(f"Current report state is '{state}'", verbose=verbose)
        if state == 'finished':
            break
        else:
            __log("Thread sleep...", verbose=verbose)
            time.sleep(10)
            continue
    # while
    csv_report_url = res_json['cv_report']['url']
    __log("Report URL received!", verbose=verbose)
    return csv_report_url


def download_report(
    auth_token: str,
    base_url: str,
    query_string: str,
    report_type: str,
    verbose=False,
    write_file=False) -> str:
    
    csv_filepath = f'./csv/{report_type}.csv'
    
    if write_file and os.path.exists(csv_filepath):
        __log(f"{csv_filepath} already exists.", verbose=verbose)
        with open(csv_filepath, 'r', encoding='utf-8') as f:
            return f.read()
    
    # 1. Make the initial request for the report creation and get the report ID.
    report_id = get_report_id(f'{base_url}{query_string}{report_type}', auth_token, verbose=verbose)
    
    # 2. Request status of report ID.
    #    Wait for the report generation to be complete. Then download the report BLOB.
    csv_report_url = get_report_url(base_url, report_id, auth_token, verbose=verbose)
 
    # Download the report from the provided URL.
    __log(f"Downloading content...", verbose=verbose)
    content: str = download_content(csv_report_url)
    
    # TEST
    if write_file:
        __log(f"Writing {csv_filepath}.", verbose=verbose)
        with open(csv_filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
    return content


async def import_report(
    importer: py.PyCsvImport,
    auth_token: str,
    base_url: str,
    query_string: str,
    report_type: str,
    table: str,
    conn: str,
    verbose=False,
    write_file=False) -> None:
    
    __log(f"Importing {table}...", verbose=verbose)
    content = download_report(auth_token, base_url, query_string, report_type, verbose, write_file)
    __log(f"Imported {table}...", verbose=verbose)
    
    if content is not None and len(content) > 0:
        __log(f"Recieved CSV with content length {len(content)}.", verbose=verbose)
        table_schema, table_name = table.split('.')
        _ = importer.execute_sql([f"TRUNCATE TABLE {table}"], conn)
        _ = await importer.from_string(content, table_schema, table_name, conn, ',')
    else:
        raise Exception(f"Failed to download CSV report '{report_type}'.")
    # if
    

async def import_reports(
    auth_token: str,
    conn: str,
    base_url: str,
    query_string: str,
    report_types: List[str],
    tables: List[str],
    verbose=False,
    write_files=False) -> bool:
    
    importer = py.PyCsvImport()
    success_count = 0
    for report_type, table_name in zip(report_types, tables):
        await import_report(importer, auth_token, base_url, query_string, report_type, table_name, conn, verbose, write_files)
        success_count += 1
    
    # Execute ETL proc.
    sp_sql = """
    DECLARE	@return_value int;
    EXEC @return_value = [cvp_load].[usp_ImportCvPartnerData];
    SELECT 'Return Value' = @return_value;
    """
    success = success_count == len(tables)
    if success:   
        importer.execute_sql([sp_sql], conn)
        __log("Exececuted ETL successfully.", verbose=verbose)
        
    return success
