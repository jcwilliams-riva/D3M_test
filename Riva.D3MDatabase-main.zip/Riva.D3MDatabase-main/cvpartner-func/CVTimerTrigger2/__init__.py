import datetime
import logging
import azure.functions as func
import os
from typing import List
from .services import CvPartnerImport as cv

# `0 */5 * * * *` every 5 minutes 
# `0 0 * * * 1` every monday
# `0 30 9 * * 1-5`	at 9:30 AM every weekday
# `0 0 7 * * 1-5` - production
async def main(req: func.TimerRequest, context: func.Context) -> None:
    
    auth_token = os.environ['AuthToken']
    conn = os.environ['SqlServer']
    cvpartner_url = os.environ['CvPartnerApiBaseUrl']
    query_string = os.environ['CvPartnerQueryString']
    cvpartner_report_types: List[str] = str(os.environ['CvPartnerReportTypes']).split(',')
    cvpartner_tables: List[str] = str(os.environ['CvPartnerTables']).split(',')

    success = await cv.import_reports(auth_token, conn, cvpartner_url, query_string, cvpartner_report_types, cvpartner_tables, True, False)

    if success:
        logging.info('Successfully imported all CV Partner reports.')
    else:
        logging.warning('Failed to import all CV Partner reports.')

    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    logging.info('Python timer trigger function ran at %s', utc_timestamp)
