# Get Started

Create a Conda environment for this repo.
```bash
conda create -n cvpartner python=3.7
conda acrivate cvpartner
```

Install requirements:
```bash
python3 -m pip install -r ./requirements.txt
```

## Editing the Code.
The entry point for the Azure function is in `./CVTimerTrigger2/__init__.py` and imports all functionality from the `./CVTimerTrigger2/services` directory.

### Integration Tests
To run an integration test to ensure connection to CV Partner, run the `./tests.py` file. This will download CSV files from CV Partner to the `./csv` directory. These files are NOT tracked by the Git repository.

## CV Partner API Nuances
When making a POST request to the CV Partner API endpoint:
`https://rivasolutions.cvpartner.com/api/v2/cv-report?encoding=UTF-16LE&output_format=csv&report_type=<REPORT_TYPE>`

The initial response will be similar to the JSON below:

```json
{
    "_id": "634ed4dbb10e340fa9e2b666",
    "created_at": "2022-10-18T16:31:23.778Z",
    "updated_at": "2022-10-18T16:31:23.778Z",
    "updated_ago": "N/A",
    "downloader_id": "62de7d238c9ce8100b3c3cc6",
    "percent_complete": 0,
    "number_of_cvs": 0,
    "number_of_completed_cvs": 0,
    "state": "started",
    "cv_report": {
        "url": null
    }
}
```

Note the `state` and `cv_report` properties.

Get the `_id` property from the JSON above. Then make a GET request to:
`https://rivasolutions.cvpartner.com/api/v2/cv-report/<THE_REPORT_ID>`

Then download CSV from the given URL in `cv_report.url` when `state == 'finished'`. The URL will be to a file in an AWS S3 bucket.

This logic is implemented in the `./CVTimerTrigger2/services/CvPartnerImport.py` file.

## For Local Development
The `./local.settings.json` file is excluded from the repository for obvious reasons since it contains credentials.
To develop and test on your development machine, create this file in the main directory with the following values:
```json
{
    "IsEncrypted": false,
    "Values": {
        "FUNCTIONS_WORKER_RUNTIME": "python",
        "AzureWebJobsStorage": "UseDevelopmentStorage=true",
        "AuthToken": "CV_PARTNER_AUTH_TOKEN",
        "CvPartnerApiBaseUrl": "https://rivasolutions.cvpartner.com/api/v2/cv-report",
        "CvPartnerQueryString": "?encoding=UTF-16LE&output_format=csv&report_type=",
        "CvPartnerReportTypes": "technologies,usage_report,certifications",
        "CvPartnerTables": "cvp_load.CvPartnerTechnologies,cvp_load.CvPartnerUsageReport,cvp_load.CvPartnerCertifications",
        "SqlServer": "Driver={SQL Server}; Server=SERVER_ADDRESS; Database=DATABASE_NAME; UID=USERNAME; PWD=PASSWORD;",
    }
}
```

Whatever key/values are in the `local.settings.json` file will also need to be entered into the Configuration panel of your function app which stores your environment variables.

## To Deploy the Azure Function App
Ensure access to the CVPartnerIngest Function in [Azure Portal](https://portal.azure.com/#@rivasolutionsinc.com/resource/subscriptions/e5b9ec20-dc18-4af1-828f-eb3b926decc0/resourceGroups/Data_analytics/providers/Microsoft.Web/sites/CVPartnerIngest/appServices).

Environment variables the function depends on are set in the [Configuration control panel](https://portal.azure.com/#@rivasolutionsinc.com/resource/subscriptions/e5b9ec20-dc18-4af1-828f-eb3b926decc0/resourceGroups/Data_analytics/providers/Microsoft.Web/sites/CVPartnerIngest/configuration).

1. Install the [Azure PowerShell CLI](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows?tabs=azure-cli).
2. Install the [Azure CLI Tools extension](https://marketplace.visualstudio.com/items?itemName=ms-vscode.azurecli) for VS Code.
3. Then run `func azure functionapp publish CVPartnerIngest`