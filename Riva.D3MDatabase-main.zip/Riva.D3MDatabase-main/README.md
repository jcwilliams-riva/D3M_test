# Riva.D3MDatabase
This repository contains the database schema and ETL for the RIVA Analytics Azure SQL Server Database.
