﻿CREATE TABLE deltek.Utilization(
	[Employee ID] varchar(6) null,
	[Employee Name] varchar(100) null,
	[Year] int null,
	[Period Number] varchar(5) null,
	[Status] varchar(10) null,
	[Account ID] varchar(10) null,
	[Project ID] varchar(25) null,
	[Pay Type] varchar(5) null,
	[Hours Date] date null,
	[Entered Hours] real null,
	[Total(Entered Hours)] real null
)
GO
CREATE NONCLUSTERED INDEX IX_delTek_Utilization
	ON deltek.Utilization([Employee ID], [Account ID], [Project ID])
GO
