﻿CREATE TABLE deltek.ProjectCodeMap
(
	Id INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	BusinessUnitId INT NOT NULL,
	ProjectCodeId INT NOT NULL,

	Constraint FK_deltek_ProjectCodeMap__BusinessUnitId
		Foreign Key (BusinessUnitId)
		References deltek.BusinessUnit(BusinessUnitId),

	Constraint FK_deltek_ProjectCodeMap__ProjectCodeId
		Foreign Key (ProjectCodeId)
		References deltek.ProjectCode(ProjectCodeId)
)
go

create nonclustered index IX_deltek_ProjectCodeMap__BusinessUnitId
	on deltek.ProjectCodeMap(BusinessUnitId)
go

create nonclustered index IX_deltek_ProjectCodeMap__ProjectCodeId
	on deltek.ProjectCodeMap(ProjectCodeId)
go
