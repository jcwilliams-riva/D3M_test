﻿CREATE TABLE deltek.ProjectCode
(
	ProjectCodeId INT NOT NULL PRIMARY KEY,
	ProjectCodeName VARCHAR(25) NOT NULL
)
go

create nonclustered index IX_deltek_ProjectCode__ProjectCodeName
	on deltek.ProjectCode(ProjectCodeName)
go
