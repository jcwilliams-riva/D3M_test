﻿create table [deltek].[ProjectList] (
	[Project ID] varchar(25) null,
	[Project Name] varchar(50) null,
	[Project Type Desc] varchar(25) null,
	[Project Classification] varchar(25) null,
	[Project Start Date] date null,
	[Project End Date] date null,
	[Total Funded] int null,
	[Cost Funded] int null,
	[Fee Funded] int null,
	[Project Value Cost] int null,
	[Project Value Fee] int null
)
go
CREATE NONCLUSTERED INDEX IX_delTek_ProjectList
	ON deltek.ProjectList([Project ID])
GO
