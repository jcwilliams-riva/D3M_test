﻿CREATE TABLE deltek.EmployeeList
(
	[Employee Id] varchar(10) null,
	[Last Name] varchar(25) null,
	[Preferred/First Name] varchar(25) null,
	[Cost Cent Description]  varchar(100) null,
	[Position Code]  varchar(25) null,
	[Current Work Email]  varchar(50) null,
	[Hire Date] date null,
	[Employee Type]  varchar(25) null,
	[Termination Date] date null
)
GO
CREATE NONCLUSTERED INDEX IX_delTek_EmployeeList
	ON deltek.EmployeeList([Employee Id], [Current Work Email])
GO
