﻿CREATE TABLE deltek.BusinessUnit
(
	BusinessUnitId INT NOT NULL PRIMARY KEY,
	BusinessUnitName VARCHAR(25) NOT NULL,
	BusinessUnitFullName VARCHAR(25) NOT NULL
)
go

create nonclustered index IX_deltek_BusinessUnit__BusinessUnitName
	on deltek.BusinessUnit(BusinessUnitName)
go

create nonclustered index IX_deltek_BusinessUnit__BusinessUnitFullName
	on deltek.BusinessUnit(BusinessUnitFullName)
go
