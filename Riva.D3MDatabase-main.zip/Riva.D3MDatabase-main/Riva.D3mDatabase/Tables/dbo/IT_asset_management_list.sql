﻿CREATE TABLE dbo.IT_asset_management_list(
	[ID] [int] PRIMARY KEY NOT NULL,
	[Title] [varchar](255) NULL,
	[Asset_Tag] [varchar](255) NULL,
	[Manufacturer] [varchar](255) NULL,
	[Model] [varchar](255) NULL,
	[Asset_Type] [varchar](255) NULL,
	[Status] [varchar](255) NULL,
	[Asset_Location] [varchar](255) NULL,
	[In_Service_Date] [varchar](255) NULL,
	[Disposed_Date] [varchar](255) NULL,
	[Assigned_To] [varchar](255) NULL,
	[Condition_Notes] [varchar](1000) NULL,
	[Purchase_Date] [date] NULL,
	[Warranty_Expiration_Date] [date] NULL,
	[Purchase_Cost] [float] NULL,
	[Replacement_Cost] [float] NULL,
	[Path] [varchar](255) NULL
)
GO
