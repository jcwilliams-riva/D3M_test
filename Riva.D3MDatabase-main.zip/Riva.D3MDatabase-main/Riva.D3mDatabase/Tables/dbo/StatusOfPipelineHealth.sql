
create table dbo.StatusOfPipelineHealth(
	Filled int null,
	[Pivot1 Names] varchar(255) null,
	[Pivot1 Values] varchar(max) null,
	[Growth Opp ID] varchar(255)
)
go
create nonclustered index ix_StatusOfPipelineHealth__GrowthOppId 
	on dbo.StatusOfPipelineHealth([Growth Opp ID])
go

--select * from dbo.StatusOfPipelineHealth