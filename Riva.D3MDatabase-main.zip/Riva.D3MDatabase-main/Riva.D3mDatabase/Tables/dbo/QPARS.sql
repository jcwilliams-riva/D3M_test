CREATE TABLE dbo.QPARS (
	[ID] [int] NOT NULL PRIMARY KEY,
	[Response ID] [varchar](255) NULL,
	[Department] VARCHAR(255) NULL,
	[Customer Service Response] VARCHAR(255) NULL,
	[Customer Service Comments] VARCHAR(1000) NULL,
	[Quality Response] VARCHAR(255) NULL,
	[Quality Comments] VARCHAR(1000) NULL,
	[Accountability Response] VARCHAR(255) NULL,
	[Accountability Comments] VARCHAR(1000) NULL,
	[Timeliness Response] VARCHAR(255) NULL,
	[Timeliness Comments] VARCHAR(1000) NULL,
	[Performance Response] VARCHAR(255) NULL,
	[Performance Comments] VARCHAR(1000) NULL,
	[Completion time] DATETIME NULL,
	[(P&C) In Delivery Dept] VARCHAR(255) NULL,
	[Strategic Direction] VARCHAR(1000) NULL
)
go