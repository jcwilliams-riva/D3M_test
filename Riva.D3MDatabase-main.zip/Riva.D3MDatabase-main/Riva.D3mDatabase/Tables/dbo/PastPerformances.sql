CREATE TABLE [dbo].[PastPerformances](
	[Technical] varchar(255) null,
	[Practice] varchar(255) null,
	[Category] varchar(255) null,
	[Term] varchar(255) null,
	[Matching Terms] varchar(255) null,
	[Confidence] real null,
	[Threshold] real null,
	[Term Count] int null,
	[Term Importance] real null,
	[Importance in Doc] real null,
	[Importance Scale] int null,
	[Importance Category] varchar(255) null,
	[Source Doc] varchar(255) null,
	[Source URL] varchar(255) null,
	[Project] varchar(255) null,
	[Account] varchar(255) null,
	[TCV] real null,
	[Practices] varchar(255) null,
	[Vendors] varchar(255) null,
	[Award Date] date null,
	[PrimeorSub] varchar(255) null,
	[TechnologiesCovered] varchar(255) null
)
GO


