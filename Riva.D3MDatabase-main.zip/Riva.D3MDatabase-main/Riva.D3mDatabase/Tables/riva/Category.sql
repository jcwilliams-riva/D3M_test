create table riva.Category(
    CategoryId int not null primary key identity(1,1),
    CategoryName varchar(100) not null,
    ParentId int null
)
go

alter table riva.Category
    add constraint FK_riva_Category__ParentId
		foreign Key (ParentId)
		references riva.Category(CategoryId)
go

create nonclustered index ix_riva_Category__ParentId
    on riva.Category(ParentId)
go