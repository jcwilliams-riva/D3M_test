create table riva.TechAssessment(
    Id bigint not null primary key identity(1,1),
    DocId int not null,
    TermId bigint not null,
    MatchingTerms varchar(255) null,
    Confidence decimal(5,4) null,
    Threshold decimal(5,4) null,
    TermCount int null,
    TermImportance decimal(5,4) null,
    ImportanceInDoc decimal(5,4) null,
    ImportanceScale int null,
    ImportanceCategory varchar(50) null
)
go

alter table riva.TechAssessment
    add constraint FK_riva_TechAssessment__DocId
		foreign Key (DocId)
		references riva.Document(DocId)
go

alter table riva.TechAssessment
    add constraint FK_riva_TechAssessment__TermId
		foreign Key (TermId)
		references riva.Term(TermId)
go

create nonclustered index IX_riva_TechAssessment__DocId
    on riva.TechAssessment(DocId)
go

create nonclustered index IX_riva_TechAssessment__TermId
    on riva.TechAssessment(TermId)
go