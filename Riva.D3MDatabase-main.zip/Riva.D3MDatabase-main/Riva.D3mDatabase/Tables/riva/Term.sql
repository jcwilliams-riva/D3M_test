create table riva.Term(
    TermId bigint not null primary key identity(1,1),
    Term varchar(255) not null,
    CategoryId int null,
    Lemmatized varchar(255)  null,
    Stemmed varchar(255)  null,
    AliasId bigint null,
    RelatedId bigint null,
    [Definition] varchar(500) null,
    Context varchar(500) null
)
go

alter table riva.Term
    add constraint FK_riva_Term__CategoryId
        foreign key(CategoryId)
        references riva.Category(CategoryId)
go

alter table riva.Term
    add constraint FK_riva_Term__AliasId
        foreign key(AliasId)
        references riva.Term(TermId)
go

alter table riva.Term
    add constraint FK_riva_Term__RelatedId
        foreign key(RelatedId)
        references riva.Term(TermId)
go

create nonclustered index ix_riva_Term_CategoryId
    on riva.Term(CategoryId)
go

create nonclustered index ix_riva_Term_AliasId
    on riva.Term(AliasId)
go

create nonclustered index ix_riva_Term_RelatedId
    on riva.Term(RelatedId)
go