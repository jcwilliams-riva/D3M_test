create table riva.QPARS(
	[KEY] varchar(25) null,
	[QPARS Comments] varchar(1000) null,
	[QPAR RESPONSE] varchar(25) null,
	[QPAR CATEGORY] varchar(25) null,
	[Response ID] varchar(5) null,
	[Office] varchar(25) null,
	[Department] varchar(25) null,
	[Completion time] datetime null,
	[Quarter + Yr] varchar(10) null,
	[(P&C) In Delivery Dept] varchar(5) null,
	[Strategic Direction] varchar(500) null,
	[ID] varchar(5) null
)
go