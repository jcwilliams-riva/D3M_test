create table riva.Document(
    DocId int not null primary key identity(1,1),
    DocName varchar(255) null,
    DocUrl varchar(255) null,
    DocType varchar(5) null,
    DocContent varchar(max) null,
    SharePointId int null,
    ProjectId int null
)
go

alter table riva.Document
    add constraint FK_riva_Document__ProjectId
		foreign Key (ProjectId)
		references riva.Project(ProjectId)
go

create nonclustered index ix_riva_Document__ProjectId
    on riva.Document(ProjectId)
go