create table riva.Project(
    ProjectId int not null primary key identity(1,1),
    SharePointId int null,
    ProjectName varchar(100) null,
    ProjectUrl varchar(255) null,
    Account varchar(255) null,
    AwardDate date null,
    TCV money null,
    PrimeOrSub varchar(10) null,
    Tech varchar(255) null
)
go