CREATE TABLE util.HolidayDimension(
	[TheDate] [date] NOT NULL,
	[HolidayText] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO


