create table survey.SurveyFormMap(
    Id int primary key identity(1,1),
    Question varchar(255) not null,
    FieldType varchar(25) null,
    ColName varchar(5) not null,
    DataType varchar(25) null
)
go