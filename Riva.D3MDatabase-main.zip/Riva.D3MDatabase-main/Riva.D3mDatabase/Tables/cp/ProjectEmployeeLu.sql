﻿create table cp.ProjectEmployeeLu(
	Id int primary key identity(1,1),
	ProjectId int not null,
	EmployeeId int not null

	, Constraint FK_CpProjectEmployeeLu__ProjectId
		Foreign Key (ProjectId)
		References cp.Project(ProjectId)

	, Constraint FK_CpProjectEmployeeLu__EmployeeTypeId
		Foreign Key (EmployeeId)
		References cp.Employee(EmployeeId)
)
go
create nonclustered index IX_CpProjectEmployeeLu__ProjectId
	on cp.ProjectEmployeeLu(ProjectId)
go
create nonclustered index IX_CpProjectEmployeeLu__EmployeeId
	on cp.ProjectEmployeeLu(EmployeeId)
go