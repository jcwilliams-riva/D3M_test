﻿create table cp.OptionYearLabel(
	OptionYearId int primary key identity(1,1),
	OptionYear varchar(10) not null
)
go
