﻿create table cp.MacroOrganizationLabel(
	MacroOrganizationId int primary key identity(1,1),
	MacroOrganization varchar(10) not null,
)
go
