﻿create table cp.Employee(
	EmployeeId int primary key identity(1,1),
	ExternalEmployeeId varchar(10) not null,
	EmployeeName varchar(50) not null,
	EmployeeEmail varchar(50) null,
	EmployeePreferredFirstName varchar(25) null,
	--Foreign keys
	BusinessUnitId int null,
	RivaLevelId int null,
	PositionId int null,
	EmployeeTypeId int null

	, Constraint FK_CpEmployee__BusinessUnitId
		Foreign Key (BusinessUnitId)
		References cp.BusinessUnitLabel(BusinessUnitId)

	, Constraint FK_CpEmployee__RivaLevelId
		Foreign Key (RivaLevelId)
		References cp.RivaLevelLabel(RivaLevelId)
	
	, Constraint FK_CpEmployee__PositionId
		Foreign Key (PositionId)
		References cp.Position(PositionId)

	, Constraint FK_CpEmployee__EmployeeTypeId
		Foreign Key (EmployeeTypeId)
		References cp.EmployeeTypeLabel(EmployeeTypeId)
)
go
create nonclustered index IX_CpEmployee__BusinessUnitId
	on cp.Employee(BusinessUnitId)
go
create nonclustered index IX_CpEmployee__RivaLevelId
	on cp.Employee(RivaLevelId)
go
create nonclustered index IX_CpEmployee__PositionId
	on cp.Employee(PositionId)
go
create nonclustered index IX_CpEmployee__EmployeeTypeId
	on cp.Employee(EmployeeTypeId)
go
