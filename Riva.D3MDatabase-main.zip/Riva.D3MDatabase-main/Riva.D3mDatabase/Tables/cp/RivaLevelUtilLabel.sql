﻿create table cp.RivaLevelUtilLabel(
	RivaLevelUtilId int primary key identity(1,1),
	RivaLevelUtil int not null
)
go
