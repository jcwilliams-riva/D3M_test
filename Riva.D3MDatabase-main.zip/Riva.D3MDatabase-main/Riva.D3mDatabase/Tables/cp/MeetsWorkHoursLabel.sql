﻿create table cp.MeetsWorkHoursLabel(
	MeetsWorkHoursId int primary key identity(1,1),
	MeetsWorkHours varchar(25) not null
)
go
