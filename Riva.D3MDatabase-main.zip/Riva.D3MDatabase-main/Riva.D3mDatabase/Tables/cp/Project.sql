﻿create table cp.Project(
	ProjectId int primary key identity(1,1),
	ExternalProjectId varchar(25),
	ProjectNameCode varchar(10) not null
)
go