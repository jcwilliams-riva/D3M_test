﻿create table cp.MeetsRivaUtilLevelLabel(
	MeetsRivaUtilLevelId int primary key identity(1,1),
	MeetsRivaUtilLevel varchar(50) not null
)
go
