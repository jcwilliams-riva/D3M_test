﻿create table cp.BusinessUnitLabel(
	BusinessUnitId int primary key identity(1,1),
	BusinessUnit varchar(25) not null,
	MacroOrganizationId int null,
	Constraint FK_BusinessUnitLabel__MacroOrganizationId
		Foreign Key(MacroOrganizationId)
		References cp.MacroOrganizationLabel(MacroOrganizationId)
)
go
