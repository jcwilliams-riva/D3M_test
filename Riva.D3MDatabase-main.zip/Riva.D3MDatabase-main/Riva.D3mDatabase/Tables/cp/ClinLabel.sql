﻿create table cp.ClinLabel(
	ClinId int primary key identity(1,1),
	Clin varchar(10) not null
)
go
