﻿create table cp.CostCenterLabel(
	CostCenterId int primary key identity(1,1),
	CostCenter varchar(50) not null
)
go
