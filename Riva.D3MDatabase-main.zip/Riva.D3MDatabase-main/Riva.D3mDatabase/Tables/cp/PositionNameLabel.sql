﻿create table cp.PositionNameLabel(
	PositionNameId int primary key identity(1,1),
	PositionName varchar(25) not null
)
go
