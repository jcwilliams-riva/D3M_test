﻿create table cp.SubClinLabel(
	SubClinId int primary key identity(1,1),
	SubClin varchar(10) not null,
	ClinId int not null

	, Constraint FK_CpSubClinLabel__ClinId
		Foreign Key (ClinId)
		References cp.ClinLabel(ClinId)
)
go
create nonclustered index IX_CpSubClinLabel__ClinId
	on cp.SubClinLabel(ClinId)
go