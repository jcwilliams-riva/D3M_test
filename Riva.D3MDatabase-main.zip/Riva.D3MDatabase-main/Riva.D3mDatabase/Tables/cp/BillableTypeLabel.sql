﻿create table cp.BillableTypeLabel(
	BillableTypeId int primary key identity(1,1),
	BillableType varchar(25) not null
)
go