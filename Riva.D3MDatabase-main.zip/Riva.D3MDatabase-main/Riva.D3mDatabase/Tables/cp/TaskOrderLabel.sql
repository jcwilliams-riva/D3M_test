﻿create table cp.TaskOrderLabel(
	TaskOrderId int primary key identity(1,1),
	TaskOrder varchar(10) not null,
	ProjectId int not null

	, Constraint FK_CpTaskOrderLabel__ProjectId
		Foreign Key (ProjectId)
		References cp.Project(ProjectId)
)
go
create nonclustered index IX_CpTaskOrderLabel__ProjectId
	on cp.TaskOrderLabel(ProjectId)
go
