﻿create table cp.EmployeeTypeLabel(
	EmployeeTypeId int primary key identity(1,1),
	EmployeeType varchar(25) not null
)
go
