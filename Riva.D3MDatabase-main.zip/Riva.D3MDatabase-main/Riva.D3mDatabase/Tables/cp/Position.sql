﻿create table cp.Position(
	PositionId int primary key identity(1,1),
	PositionCode varchar(25) not null,
	PositionName varchar(25) not null
)
go
