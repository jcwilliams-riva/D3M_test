/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[Macro Organization]
*/
create table cp.MacroOrganizationLabel(
	MacoOrganizationId int primary key identity(1,1),
	MacoOrganization varchar(10) not null,
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[Meets 80% Util Lvl]
*/
create table cp.UtilLevelLabel(
	UtilLevelId int primary key identity(1,1),
	UtilLevel varchar(50) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[BILLABLE]
*/
create table cp.BillableTypeLabel(
	BillableTypeId int primary key identity(1,1),
	BillableType varchar(25) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[Meets Work Hours]
*/
create table cp.MeetsWorkHoursLabel(
	MeetsWorkHoursId int primary key identity(1,1),
	MeetsWorkHours varchar(25) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[Meets RIVA Util Lvl]
*/
create table cp.MeetsRivaUtilLevelLabel(
	MeetsRivaUtilLevelId int primary key identity(1,1),
	MeetsRivaUtilLevel varchar(50) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[Option Year ]
*/
create table cp.OptionYearLabel(
	OptionYearId int primary key identity(1,1),
	OptionYear varchar(10) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[CLIN ]
*/
create table cp.ClinLabel(
	ClinId int primary key identity(1,1),
	Clin varchar(10) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[Sub CLIN ]
*/
create table cp.SubClinLabel(
	SubClinId int primary key identity(1,1),
	SubClin varchar(10) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[RIVA LEVEL UTIL]
*/
create table cp.RivaLevelUtilLabel(
	RivaLevelUtilId int primary key identity(1,1),
	RivaLevelUtil tinyint not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[RIVA LEVEL]
*/
create table cp.RivaLevelLabel(
	RivaLevelId int primary key identity(1,1),
	RivaLevel varchar(25) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[Position Code]
		cp_load.CostPointPaylocityUtilReport.[POSITION NAME]
*/
create table cp.Position(
	PositionId int primary key identity(1,1),
	PositionCode varchar(25) not null,
	PositionName varchar(25) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[BU]
*/
create table cp.BusinessUnitLabel(
	BusinessUnitId int primary key identity(1,1),
	BusinessUnit varchar(25) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[Employee Type]
*/
create table cp.EmployeeTypeLabel(
	EmployeeTypeId int primary key identity(1,1),
	EmployeeType varchar(25) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[Cost Cent Description]
*/
create table cp.CostCenterLabel(
	CostCenterId int primary key identity(1,1),
	CostCenter varchar(50) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[NAME 2]
*/
create table cp.Employee(
	EmployeeId int primary key identity(1,1),
	ExternalEmployeeId varchar(10) not null,
	EmployeeName varchar(50) not null,
	EmployeeEmail varchar(50) null,
	EmployeePreferredFirstName varchar(25) null,
	--Foreign keys
	BusinessUnitId int null,
	RivaLevelId int null,
	PositionId int null,
	EmployeeTypeId int null

	, Constraint FK_CpEmployee__BusinessUnitId
		Foreign Key (BusinessUnitId)
		References cp.BusinessUnitLabel(BusinessUnitId)

	, Constraint FK_CpEmployee__RivaLevelId
		Foreign Key (RivaLevelId)
		References cp.RivaLevelLabel(RivaLevelId)
	
	, Constraint FK_CpEmployee__PositionId
		Foreign Key (PositionId)
		References cp.Position(PositionId)

	, Constraint FK_CpEmployee__EmployeeTypeId
		Foreign Key (EmployeeTypeId)
		References cp.EmployeeTypeLabel(EmployeeTypeId)
)
go
create nonclustered index IX_CpEmployee__BusinessUnitId
	on cp.Employee(BusinessUnitId)
go
create nonclustered index IX_CpEmployee__RivaLevelId
	on cp.Employee(RivaLevelId)
go
create nonclustered index IX_CpEmployee__PositionId
	on cp.Employee(PositionId)
go
create nonclustered index IX_CpEmployee__EmployeeTypeId
	on cp.Employee(EmployeeTypeId)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[Project Name Code]
		cp_load.CostPointPaylocityUtilReport.[Project ID]
*/
create table cp.Project(
	ProjectId int primary key identity(1,1),
	ExternalProjectId varchar(25),
	ProjectNameCode varchar(10) not null
)
go

/*
	Maps to:
		cp_load.CostPointPaylocityUtilReport.[Task Order ]
*/
create table cp.TaskOrderLabel(
	TaskOrderId int primary key identity(1,1),
	TaskOrder varchar(10) not null,
	ProjectId int not null

	, Constraint FK_CpTaskOrderLabel__ProjectId
		Foreign Key (ProjectId)
		References cp.Project(ProjectId)
)
go
create nonclustered index IX_CpTaskOrderLabel__ProjectId
	on cp.TaskOrderLabel(ProjectId)
go

create table cp.ProjectEmployeeLu(
	Id int primary key identity(1,1),
	ProjectId int not null,
	EmployeeId int not null

	, Constraint FK_CpProjectEmployeeLu__ProjectId
		Foreign Key (ProjectId)
		References cp.Project(ProjectId)

	, Constraint FK_CpProjectEmployeeLu__EmployeeTypeId
		Foreign Key (EmployeeId)
		References cp.Employee(EmployeeId)
)
go
create nonclustered index IX_CpProjectEmployeeLu__ProjectId
	on cp.ProjectEmployeeLu(ProjectId)
go
create nonclustered index IX_CpProjectEmployeeLu__EmployeeId
	on cp.ProjectEmployeeLu(EmployeeId)
go