﻿create table cp.RivaLevelLabel(
	RivaLevelId int primary key identity(1,1),
	RivaLevel varchar(25) not null
)
go
