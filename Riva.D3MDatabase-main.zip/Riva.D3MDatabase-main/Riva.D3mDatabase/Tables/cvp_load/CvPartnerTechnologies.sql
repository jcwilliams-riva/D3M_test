CREATE TABLE [cvp_load].[CvPartnerTechnologies](
	[Name] [varchar](255) NULL,
	[Email] [varchar](255) NULL,
	[Department] [varchar](255) NULL,
	[Country] [varchar](255) NULL,
	[Nationality] [varchar](255) NULL,
	[UPN] [varchar](255) NULL,
	[External User ID] [varchar](255) NULL,
	[CV Partner User ID] [varchar](255) NULL,
	[CV Partner CV ID] [varchar](255) NULL,
	[Skill name (int)] [varchar](255) NULL,
	[Year experience] [int] NULL,
	[Proficiency (0-5)] [int] NULL,
	[Skill name (int) is masterdata] [bit] NULL,
	[Category (int)] [varchar](255) NULL,
	[Custom tag: RIVA Career Level] [varchar](255) NULL,
	[Custom tag: Years of Experience ] [varchar](255) NULL,
	[Custom tag: Supervisor name] [varchar](255) NULL,
	[Custom tag: Supervisor (Y/N)] [varchar](255) NULL,
	[Custom tag: RIVA Path ] [varchar](255) NULL,
	[Custom tag: Business Units] [varchar](255) NULL,
	[Custom tag: Clearance/Sponsor] [varchar](255) NULL
) ON [PRIMARY]
GO


