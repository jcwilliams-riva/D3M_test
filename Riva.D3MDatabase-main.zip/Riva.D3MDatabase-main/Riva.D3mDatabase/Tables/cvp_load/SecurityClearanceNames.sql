﻿CREATE TABLE cvp_load.SecurityClearanceNames(
	[Access] [nvarchar](50) NULL,
	[Eligibility] [nvarchar](50) NULL,
	[Lastname] [nvarchar](50) NULL,
	[Firstname] [nvarchar](50) NULL
) ON [PRIMARY]
GO
