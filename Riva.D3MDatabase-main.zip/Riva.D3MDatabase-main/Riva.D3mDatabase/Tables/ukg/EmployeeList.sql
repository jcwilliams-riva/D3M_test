﻿CREATE TABLE ukg.EmployeeList
(
	[Employee Number] varchar(10) null,
	[Employee Name (Last Suffix, First MI)] varchar(50) null,
	[Employment Status] varchar(25) null,
	[Employee Email] varchar(50) null,
	[Job] varchar(50) null,
	[Org Level 1] varchar(50) null,
	[Org Level 2] varchar(50) null,
	[Org Level 3] varchar(50) null,
	[Supervisor Name (Unsecured)] varchar(50) null,
	[Supervisor Email] varchar(50) null,
	[Last Hire Date] date null,
	[Original Hire] date null,
	[Termination Date] date null,
	[Termination Type] varchar(25) null,
	[Termination Reason] varchar(50) null,
	[Address Line 1] varchar(255) null,
	[City] varchar(100) null,
	[State] varchar(5) null,
	[Zip Code (Formatted)] varchar(10) null,
	[Birth Date] date null,
	[Gender Code] char(1) null,
	[Ethnicity] varchar(100) null
)
GO
CREATE NONCLUSTERED INDEX IX_ukg_EmployeeList
	ON ukg.EmployeeList([Employee Number], [Employee Email])
GO
