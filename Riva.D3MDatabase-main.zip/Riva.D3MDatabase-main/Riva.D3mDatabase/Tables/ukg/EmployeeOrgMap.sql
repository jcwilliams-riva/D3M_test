
create table ukg.EmployeeOrgMap(
    Id int primary key identity(1,1) not null,
    OrgId varchar(10) not null,
    EmpId varchar(7) not null
)
go

create nonclustered index IX_ukg_EmployeeOrgMap__OrgId
	on ukg.EmployeeOrgMap(OrgId)
go

create nonclustered index IX_ukg_EmployeeOrgMap__EmpId
	on ukg.EmployeeOrgMap(EmpId)
go

alter table ukg.EmployeeOrgMap
    add Constraint FK_ukg_EmployeeOrgMap__OrgId
        Foreign Key (OrgId)
        References ukg.Org(OrgId)
go

alter table ukg.EmployeeOrgMap
    add Constraint FK_ukg_EmployeeOrgMap__EmpId
        Foreign Key (EmpId)
        References ukg.Employee(EmpId)
go