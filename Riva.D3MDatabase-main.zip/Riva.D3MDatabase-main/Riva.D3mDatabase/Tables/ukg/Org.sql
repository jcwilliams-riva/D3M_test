create table ukg.Org(
    OrgId varchar(10) primary key not null,
    OrgName varchar(50) not null
)
go