﻿CREATE TABLE ukg.CareerLevel
(
	[Company Name] varchar(50) null,
	[Employee Name (Last Suffix, First MI)] varchar(50) null,
	[Employee Number] varchar(10) null,
	[Employment Status] varchar(25) null,
	[Location] varchar(50) null,
	[Employment_CareerLevel] varchar(10) null,
	[Org Level 1] varchar(50) null,
	[Job] varchar(50) null
)
GO
CREATE NONCLUSTERED INDEX IX_ukg_CareerLevel
	ON ukg.CareerLevel([Employee Number], [Employment_CareerLevel])
GO
