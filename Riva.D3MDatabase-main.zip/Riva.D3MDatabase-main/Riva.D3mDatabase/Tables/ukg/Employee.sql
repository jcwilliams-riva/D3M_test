create table ukg.Employee(
    EmpId varchar(7) primary key not null,
    EmpFirstName varchar(25) null,
    EmpLastName varchar(25) null,
    EmpMiddle varchar(25) null
)
go