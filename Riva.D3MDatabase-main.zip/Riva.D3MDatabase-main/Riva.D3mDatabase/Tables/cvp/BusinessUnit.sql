﻿CREATE TABLE cvp.BusinessUnit
(
	BusinessUnitId INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	BusinessUnitName VARCHAR(255) NOT NULL,
	BusinessUnitAlias VARCHAR(255) NULL
)
GO

CREATE NONCLUSTERED INDEX IX_CvpBusinessUnit__BusinessUnitName ON cvp.BusinessUnit(BusinessUnitName)
GO

CREATE NONCLUSTERED INDEX IX_CvpBusinessUnit__BusinessUnitAlias ON cvp.BusinessUnit(BusinessUnitAlias)
GO
