﻿CREATE TABLE cvp.CvCertificationLu(
	Id int PRIMARY KEY IDENTITY(1,1),
	SectionId int NOT NULL,
	CertificationId int NOT NULL,
	CertOrganizer varchar(500),
	CertDescription varchar(max),
	CertHighlighted bit NULL DEFAULT(0),
	Updated datetime NULL,
	UpdatedByOwner datetime NULL,
	MonthCompleted int NULL,
	YearCompleted int NULL,
	MonthExpires int NULL,
	YearExpires int NULL,
	BusinessUnitId int NULL,
	SponsorId int NULL,
	IsSupervisor bit NULL,
	CareerLevelId int NULL,
	PathId int NULL,
	SupervisorId int NULL,
	YearsOfExperience int NULL,

	CONSTRAINT FK_CvCertificationLu__CertificationId
		FOREIGN KEY (CertificationId) 
		REFERENCES cvp.Certification(CertificationId)
		ON DELETE CASCADE,

	CONSTRAINT FK_CvCertificationLu__SectionId
		FOREIGN KEY (SectionId) 
		REFERENCES cvp.Section(SectionId)
		ON DELETE CASCADE,

	CONSTRAINT FK_CvCertificationLu__BusinessUnitId
		FOREIGN KEY (BusinessUnitId) 
		REFERENCES cvp.BusinessUnit(BusinessUnitId)
		ON DELETE CASCADE,

	CONSTRAINT FK_CvCertificationLu__SponsorId
		FOREIGN KEY (SponsorId) 
		REFERENCES cvp.ClearanceSponsor(SponsorId)
		ON DELETE CASCADE,

	CONSTRAINT FK_CvCertificationLu__CareerLevelId
		FOREIGN KEY (CareerLevelId) 
		REFERENCES cvp.CareerLevel(CareerLevelId)
		ON DELETE CASCADE,

	CONSTRAINT FK_CvCertificationLu__PathId
		FOREIGN KEY (PathId) 
		REFERENCES cvp.[Path](PathId)
		ON DELETE CASCADE,

	CONSTRAINT FK_CvCertificationLu__SupervisorId
		FOREIGN KEY (SupervisorId) 
		REFERENCES cvp.Employee(EmployeeId)
		ON DELETE CASCADE
)
GO

CREATE NONCLUSTERED INDEX IX_CvCertificationLu__CertificationId
	ON cvp.CvCertificationLu(CertificationId)
GO

CREATE NONCLUSTERED INDEX IX_CvCertificationLu__SectionId 
	ON cvp.CvCertificationLu(SectionId)
GO

CREATE NONCLUSTERED INDEX IX_CvCertificationLu__BusinessUnitId 
	ON cvp.CvCertificationLu(BusinessUnitId)
GO

CREATE NONCLUSTERED INDEX IX_CvCertificationLu__SponsorId 
	ON cvp.CvCertificationLu(SponsorId)
GO

CREATE NONCLUSTERED INDEX IX_CvCertificationLu__CareerLevelId 
	ON cvp.CvCertificationLu(CareerLevelId)
GO

CREATE NONCLUSTERED INDEX IX_CvCertificationLu__PathId
	ON cvp.CvCertificationLu(PathId)
GO

CREATE NONCLUSTERED INDEX IX_CvCertificationLu__SupervisorId
	ON cvp.CvCertificationLu(SupervisorId)
GO
