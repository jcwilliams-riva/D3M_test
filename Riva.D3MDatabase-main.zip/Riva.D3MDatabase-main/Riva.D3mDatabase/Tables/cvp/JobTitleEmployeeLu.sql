﻿CREATE TABLE cvp.JobTitleEmployeeLu
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	EmployeeId int NOT NULL,
	JobTitleId int NOT NULL,

	CONSTRAINT FK_CvPartnerJobTitleEmployeeLu__EmployeeId
		FOREIGN KEY (EmployeeId)
		REFERENCES cvp.Employee(EmployeeId),

	CONSTRAINT FK_CvPartnerJobTitleEmployeeLu__JobTitleId
		FOREIGN KEY (JobTitleId)
		REFERENCES cvp.JobTitle(JobTitleId)
)
GO
CREATE NONCLUSTERED INDEX IX_CvPartnerJobTitleEmployeeLu__EmployeeId
	ON cvp.JobTitleEmployeeLu(EmployeeId)
GO
CREATE NONCLUSTERED INDEX IX_CvPartnerJobTitleEmployeeLu__JobTitleId
	ON cvp.JobTitleEmployeeLu(JobTitleId)
GO
