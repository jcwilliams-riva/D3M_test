﻿CREATE TABLE cvp.SkillCategoryLu
(
	Id INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	SkillId INT NOT NULL,
	SkillCategoryId INT NOT NULL,

	CONSTRAINT FK_CvpSkillCategoryLu__SkillId
		FOREIGN KEY (SkillId)
		REFERENCES cvp.Skill(SkillId),

	CONSTRAINT FK_CvpSkillCategoryLu__SkillCategoryId
		FOREIGN KEY (SkillCategoryId)
		REFERENCES cvp.SkillCategory(SkillCategoryId)
)
GO

CREATE NONCLUSTERED INDEX IX_CvpSkillCategoryLu__SkillId
	ON cvp.SkillCategoryLu(SkillId)
GO

CREATE NONCLUSTERED INDEX IX_CvpSkillCategoryLu__SkillCategoryId
	ON cvp.SkillCategoryLu(SkillCategoryId)
GO
