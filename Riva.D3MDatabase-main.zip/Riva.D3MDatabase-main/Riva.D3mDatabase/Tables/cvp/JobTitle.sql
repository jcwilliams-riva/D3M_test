﻿CREATE TABLE cvp.JobTitle
(
	JobTitleId INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	JobTitleName varchar(255) NOT NULL
)
GO
