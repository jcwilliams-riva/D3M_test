﻿CREATE TABLE cvp.Certification
(
	CertificationId INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	CertificationTitle VARCHAR(500) NOT NULL
)
GO
