﻿CREATE TABLE cvp.Employee(
	EmployeeId int PRIMARY KEY IDENTITY(1,1),
	ExternalUserId varchar(25) NOT NULL,
	EmployeeName varchar(255) NULL,
	EmployeeEmail varchar(255) NULL,
	PhoneNumber varchar(25) NULL
)
GO
CREATE UNIQUE INDEX IX_CvPartnerEmployee__ExternalUserId 
	ON cvp.Employee(ExternalUserId)
GO
CREATE UNIQUE INDEX IX_CvPartnerEmployee__EmployeeEmail 
	ON cvp.Employee(EmployeeEmail)
GO
