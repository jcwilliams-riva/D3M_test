﻿CREATE TABLE [cvp].[ClearanceSponsor]
(
	SponsorId INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	SponsorName VARCHAR(50) NOT NULL
)
GO
