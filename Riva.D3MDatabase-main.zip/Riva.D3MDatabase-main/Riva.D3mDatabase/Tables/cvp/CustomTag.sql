﻿CREATE TABLE cvp.CustomTag(
	TagId int PRIMARY KEY,
	TagName varchar(255) NOT NULL,

	INDEX IX_CvpCustomTag__TagId UNIQUE(TagId)
)
GO
