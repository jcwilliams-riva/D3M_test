﻿CREATE TABLE cvp.CvSkillLu
(
	Id INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	SkillId int NOT NULL,
	CvId int NOT NULL,
	YearsExperience int NULL,
	Proficiency smallint NULL,
	CareerLevelId INT NULL,
	SupervisorId INT NULL,
	IsSupervisor BIT NULL,
	PathId INT NULL,
	BusinessUnitId INT NULL,
	SponsorId INT NULL,

	CONSTRAINT FK_CvpCvSkillLu__SkillId
		FOREIGN KEY (SkillId)
		REFERENCES cvp.Skill(SkillId),

	CONSTRAINT FK_CvpCvSkillLu__CvId
		FOREIGN KEY (CvId)
		REFERENCES cvp.Cv(CvId),

	CONSTRAINT FK_CvpCvSkillLu__CareerLevelId
		FOREIGN KEY (CareerLevelId)
		REFERENCES cvp.CareerLevel(CareerLevelId),

	CONSTRAINT FK_CvpCvSkillLu__SupervisorId
		FOREIGN KEY (SupervisorId)
		REFERENCES cvp.Employee(EmployeeId),

	CONSTRAINT FK_CvpCvSkillLu__PathId
		FOREIGN KEY (PathId)
		REFERENCES cvp.Path(PathId),

	CONSTRAINT FK_CvpCvSkillLu__BusinessUnitId
		FOREIGN KEY (BusinessUnitId)
		REFERENCES cvp.BusinessUnit(BusinessUnitId),

	CONSTRAINT FK_CvpCvSkillLu__SponsorId
		FOREIGN KEY (SponsorId)
		REFERENCES cvp.ClearanceSponsor(SponsorId)
)
GO

CREATE NONCLUSTERED INDEX IX_CvpCvSkillLu__SkillId
	ON cvp.CvSkillLu(SkillId)
GO

CREATE NONCLUSTERED INDEX IX_CvpCvSkillLu__CvId
	ON cvp.CvSkillLu(CvId)
GO

CREATE NONCLUSTERED INDEX IX_CvpCvSkillLu__CareerLevelId
	ON cvp.CvSkillLu(CareerLevelId)
GO

CREATE NONCLUSTERED INDEX IX_CvpCvSkillLu__SupervisorId
	ON cvp.CvSkillLu(SupervisorId)
GO

CREATE NONCLUSTERED INDEX IX_CvpCvSkillLu__PathId
	ON cvp.CvSkillLu(PathId)
GO

CREATE NONCLUSTERED INDEX IX_CvpCvSkillLu__BusinessUnitId
	ON cvp.CvSkillLu(BusinessUnitId)
GO

CREATE NONCLUSTERED INDEX IX_CvpCvSkillLu__SponsorId
	ON cvp.CvSkillLu(SponsorId)
GO
