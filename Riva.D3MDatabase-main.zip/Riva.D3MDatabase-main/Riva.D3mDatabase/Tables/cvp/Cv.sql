﻿CREATE TABLE cvp.Cv(
	CvId int PRIMARY KEY IDENTITY(1,1),
	ExternalCvId varchar(25) NOT NULL,
	EmployeeId int NOT NULL,

	CONSTRAINT FK_CvpCv__EmployeeId
		FOREIGN KEY (EmployeeId)
		REFERENCES cvp.Employee(EmployeeId)
)
GO
CREATE UNIQUE INDEX IX_CvpCv__ExternalCvId 
	ON cvp.Cv(ExternalCvId)
GO

CREATE NONCLUSTERED INDEX IX_CvpCv__EmployeeId
	ON cvp.Cv(EmployeeId)
GO
