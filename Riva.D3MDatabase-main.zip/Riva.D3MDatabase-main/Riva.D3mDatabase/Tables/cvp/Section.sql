﻿CREATE TABLE cvp.Section(
	SectionId int PRIMARY KEY IDENTITY(1,1),
	ExternalSectionId varchar(25),
	CvId int NOT NULL,
	CONSTRAINT FK_CvpSection__CvId 
		FOREIGN KEY (CvId) 
		REFERENCES cvp.Cv(CvId) 
		ON DELETE CASCADE
)
GO
CREATE UNIQUE INDEX IX_CvpSection__ExternalSectionId 
	ON cvp.Section(ExternalSectionId)
GO
CREATE NONCLUSTERED INDEX IX_CvpSection__CvId 
	ON cvp.Section(CvId)
GO
