﻿CREATE TABLE cvp.Usage
(
	Id INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	CvId int NOT NULL,
	OwnerLastRemovedOrAddedSection DATETIME NULL,
	OwnerLastUpdatedCv DATETIME NULL,
	LastUpdatedCv DATETIME NULL,
	SummaryOfQualifications INT NULL,
	OwnerLastUpdatedQualifications DATETIME NULL,
	ProjectExperiences INT NULL,
	UniqueRoles INT NULL,
	OwnerLastUpdatedProjectExperiences DATETIME NULL,
	HighlightedRoles INT NULL,
	OwnerLastUpdatedHighlightedRoles DATETIME NULL,
	SkillCategories INT NULL,
	OwnerLastUpdatedSkillCategories DATETIME NULL,
	Educations INT NULL,
	YearsOfEducation INT NULL,
	OwnerLastUpdatedEducations DATETIME NULL,
	WorkExperiences INT NULL,
	YearsSinceFirstWorkExperience INT NULL,
	OwnerLastUpdatedWorkExperiences DATETIME NULL,
	Certifications INT NULL,
	OwnerLastUpdatedCertifications DATETIME NULL,
	Courses INT NULL,
	OwnerLastUpdatedCourses DATETIME NULL,
	Presentations INT NULL,
	OwnerLastUpdatedPresentations DATETIME NULL,
	Recommendations INT NULL,
	OwnerLastUpdatedRecommendations DATETIME NULL,
	Positions INT NULL,
	OwnerLastUpdatedPositions DATETIME NULL,
	Mentoring INT NULL,
	OwnerLastUpdatedMentoring DATETIME NULL,
	Publications INT NULL,
	OwnerLastUpdatedPublications DATETIME NULL,
	HonorsAndAwards INT NULL,
	OwnerLastUpdatedHonorsAndAwards DATETIME NULL,
	Languages INT NULL,
	OwnerLastUpdatedLanguages DATETIME NULL,
	Category VARCHAR(10)

	CONSTRAINT FK_Usage__CvId
		FOREIGN KEY (CvId)
		REFERENCES cvp.Cv(CvId)
		ON DELETE CASCADE
)
GO
CREATE NONCLUSTERED INDEX IX_Usage__CvId
	ON cvp.Usage(CvId)
GO