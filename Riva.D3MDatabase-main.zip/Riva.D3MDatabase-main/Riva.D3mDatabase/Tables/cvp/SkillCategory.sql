﻿CREATE TABLE cvp.SkillCategory
(
	SkillCategoryId INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	SkillCategoryName VARCHAR(255) NOT NULL
)
GO
