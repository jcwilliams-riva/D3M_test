﻿CREATE TABLE [cvp].[CareerLevel]
(
	CareerLevelId INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	CareerLevelDesc varchar(5) NOT NULL
)
GO