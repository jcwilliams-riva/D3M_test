CREATE TABLE cp_load.EmployeeInformation(
    [Employee ID] varchar(10) null,
    [Employee First Name and Last Name] varchar(100) null,
    [Gender] char(1) null,
    [Hourly Rate] decimal(12,4) null,
    [Annual Amount] decimal(12,4) null,
    [Labor Group Type] varchar(5) null,
    [Labor Group Description] varchar(25) null,
    [Labor Location] varchar(100) null,
    [Labor Location Description] varchar(100) null,
    [Manager Name] varchar(100) null,
    [Home Org ID] varchar(10) null,
    [Home Org Name] varchar(50) null,
    [Original Hire Date] date null,
    [Adjusted Hire Date] date null,
    [Termination Date] date null,
    [Employee Status] varchar(25) null,
    [Supervisor Name] varchar(100)
)
GO