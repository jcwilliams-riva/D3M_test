create index IX_TechnomileTableauExport_GrowthOppId
	on dbo.TechnomileTableauExport([Growth Opp ID] asc, [Data Refresh Date] asc)
go