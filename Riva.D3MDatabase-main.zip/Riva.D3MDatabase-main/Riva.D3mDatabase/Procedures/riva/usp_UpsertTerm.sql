create procedure riva.usp_UpsertTerm(
	@term varchar(255),
	@stemmed varchar(255) = null,
	@lemma varchar(255) = null,
	@definition varchar(500) = null,
	@context varchar(500) = null,
	@cat_name varchar(100) = null
) 
AS

DECLARE @cat_id int = (SELECT TOP 1 CategoryId FROM riva.Category WHERE CategoryName = @cat_name);
DECLARE @termId bigint = (SELECT TOP 1 TermId FROM riva.Term WHERE Term = @term);

IF @termId IS NULL
BEGIN
	INSERT INTO riva.Term(Term, CategoryId, Lemmatized, Stemmed, [Definition], Context)
	VALUES(@term, @cat_id, @lemma, @stemmed, @definition, @context);
END
ELSE
BEGIN
	UPDATE riva.Term SET
		Lemmatized = @lemma,
		Stemmed = @stemmed,
		CategoryId = @cat_id,
		[Definition] = @definition,
		Context = @context
	WHERE TermId = @termId;
END