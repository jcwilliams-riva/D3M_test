create procedure riva.usp_UpsertDocument(
	@doc_name varchar(255),
	@doc_url varchar(255) = null,
	@doc_type varchar(5) = null,
	@doc_content varchar(max) = null,
	@sharepoint_id int = null,
	@project_id int = null
)
AS

declare @doc_id int = (SELECT TOP 1 DocId from riva.Document WHERE DocName = @doc_name);

IF @doc_id IS NULL
BEGIN
	INSERT INTO riva.Document(DocName, DocUrl, DocType, DocContent, SharePointId, ProjectId)
	VALUES(@doc_name, @doc_url, @doc_type, @doc_content, @sharepoint_id, @project_id);
END
ELSE
BEGIN
	UPDATE riva.Document SET 
		DocType = @doc_type,
		DocUrl = @doc_url,
		DocContent = @doc_content,
		SharePointId = @sharepoint_id,
		ProjectId = @project_id
	WHERE DocId = @doc_id;
END