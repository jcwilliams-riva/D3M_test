create procedure riva.usp_InsertTechAssessment(
	@doc_name varchar(255),
	@term varchar(255),
	@matching_terms varchar(255) = null,
	@confidence decimal(5,4) = null,
	@threshold decimal(5,4) = null,
	@term_count int = 0,
	@term_importance decimal(5,4) = null,
	@importance_in_doc decimal(5,4) = null,
	@importance_scale int = null,
	@importance_category varchar(50) = null,
	@term_lemma varchar(255) = null,
	@term_stemmed varchar(255) = null,
	@term_cat varchar(255) = null
)
AS

declare @doc_id int = (SELECT TOP 1 DocId FROM riva.Document WHERE DocName = @doc_name);
declare @term_id bigint = (SELECT TOP 1 TermId FROM riva.Term WHERE Term = @term);

IF @term_id IS NULL
BEGIN
	INSERT INTO riva.Term(Term, Lemmatized, Stemmed, CategoryId)
	VALUES(@term
	, @term_lemma
	, @term_stemmed
	, (SELECT TOP 1 CategoryId FROM riva.Category WHERE CategoryName = @term_cat));
	
	SET @term_id = (SELECT TOP 1 TermId FROM riva.Term WHERE Term = @term);
END

declare @tech_id bigint = (SELECT TOP 1 Id FROM riva.TechAssessment WHERE TermId = @term_id AND DocId = @doc_id);

IF (@tech_id IS NOT NULL)
BEGIN
	UPDATE riva.TechAssessment SET 
		MatchingTerms = @matching_terms,
		Confidence = @confidence,
		Threshold = @threshold,
		TermCount = @term_count,
		TermImportance = @term_importance,
		ImportanceInDoc = @importance_in_doc,
		ImportanceScale = @importance_scale,
		ImportanceCategory = @importance_category
	WHERE Id = @tech_id;
END
ELSE IF (@doc_id IS NOT NULL AND @tech_id IS NULL)
BEGIN
	INSERT INTO riva.TechAssessment(DocId, TermId, MatchingTerms, Confidence, Threshold, TermCount, TermImportance,
		ImportanceInDoc, ImportanceScale, ImportanceCategory)
	VALUES(@doc_id, @term_id, @matching_terms, @confidence, @threshold, @term_count, @term_importance,
		@importance_in_doc, @importance_scale, @importance_category);
END
