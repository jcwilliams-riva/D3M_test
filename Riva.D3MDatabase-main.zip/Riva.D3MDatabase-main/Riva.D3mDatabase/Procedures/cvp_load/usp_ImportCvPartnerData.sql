create procedure cvp_load.usp_ImportCvPartnerData as

SET NOCOUNT ON;
DECLARE @RC int;
EXECUTE @RC = [cvp].[usp_ClearAllTables];

insert into cvp.Certification(CertificationTitle)
	select
		t1.[Name (int)] as CertificationTitle
	from
		cvp_load.CvPartnerCertifications as t1
	where
		t1.[Name (int)] is not null
	group by 
		t1.[Name (int)]
;
	


insert into cvp.SkillCategory(SkillCategoryName)
	select 
		t.[Category (int)] as SkillCategoryName
	from
		cvp_load.CvPartnerTechnologies as t
	where
		t.[Category (int)] is not null
	group by
		t.[Category (int)]
;


insert into cvp.Skill(SkillName)
	select 
		t.[Skill name (int)] as SkillName
	from
		cvp_load.CvPartnerTechnologies as t
	where
		t.[Skill name (int)] is not null
	group by
		t.[Skill name (int)]
;


insert into cvp.SkillCategoryLu(SkillId, SkillCategoryId)
	select 
		sk.SkillId,
		cat.SkillCategoryId
	from
		cvp_load.CvPartnerTechnologies as t
		inner join cvp.Skill as sk on t.[Skill name (int)] = sk.SkillName
		inner join cvp.SkillCategory as cat on t.[Category (int)] = cat.SkillCategoryName
	where
		t.[Skill name (int)] is not null
		and t.[Category (int)] is not null
	group by
		sk.SkillId,
		cat.SkillCategoryId
;


insert into cvp.BusinessUnit(BusinessUnitName, BusinessUnitAlias)
	select 
		BusinessUnits as BusinessUnitName
		, case 
			when BusinessUnits in ('DEFENSE & NATIONAL SECURITY/CORPORATE', 'DEFENSE & NATIONAL SECURITY') then 'DEFENSE & NATIONAL SECURITY'
			when BusinessUnits in ('FEDERAL CIVILIAN/CORPORATE', 'FEDERAL CIVILIAN/DEFENSE & NATIONAL SECURITY', 'FEDERAL CIVILIAN') then 'FEDERAL CIVILIAN'
			when BusinessUnits in ('FEDERAL HEALTH', 'FEDERAL HEALTH/FEDERAL CIVILIAN', 'FEDERAL HEALTH/FEDERAL CIVILIAN/CORPORATE') then 'FEDERAL HEALTH'
			else BusinessUnits
		end as BusinessUnitAlias
	from 
		cvp.vw_CvPartnerCustomTags as t
	where 
		t.BusinessUnits is not null
	group by 
		t.BusinessUnits
;


insert into cvp.CareerLevel(CareerLevelDesc)
	select
		t1.CareerLevel as CareerLevelDesc
	from
		cvp.vw_CvPartnerCustomTags as t1
	where
		t1.CareerLevel is not null
	group by
		t1.CareerLevel
;


insert into cvp.[Path](PathDesc)
	select
		t1.Path as PathDesc
	from
		cvp.vw_CvPartnerCustomTags as t1
	where
		t1.[Path] is not null
	group by
		t1.[Path]
;


insert into cvp.ClearanceSponsor(SponsorName)
	select
		t1.ClearanceSponsor as SponsorName
	from
		cvp.vw_CvPartnerCustomTags as t1
	where
		t1.ClearanceSponsor is not null
	group by
		t1.ClearanceSponsor
;


insert into cvp.Employee(ExternalUserId, EmployeeName, EmployeeEmail, PhoneNumber)
	select 
		UserId as ExternalUserId,
		EmployeeName,
		EmployeeEmail,
		PhoneNumber
	from (select distinct
			coalesce(usage.[CV Partner User ID], tech.[CV Partner User ID], crt.[CV Partner User ID]) as UserId
			, coalesce(usage.[Name], tech.[Name], crt.[Name]) as EmployeeName
			, coalesce(usage.Email, tech.Email, crt.Email) as EmployeeEmail
			, usage.[Phone Number] as PhoneNumber
		from
			cvp_load.CvPartnerUsageReport as usage

			full join cvp_load.CvPartnerTechnologies as tech
				on usage.[CV Partner User ID] = tech.[CV Partner User ID]
					or usage.Email = tech.Email

			full join cvp_load.CvPartnerCertifications as crt
				on isnull(usage.[CV Partner User ID], tech.[CV Partner User ID]) = crt.[CV Partner User ID]
					or isnull(usage.Email, tech.Email) = crt.Email
		) as t
	where 
		UserId is not null
	group by
		UserId,
		EmployeeName,
		EmployeeEmail,
		PhoneNumber
;


insert into cvp.JobTitle(JobTitleName)
	select
		[Title (int)] as JobTitleName
	from 
		cvp_load.CvPartnerUsageReport as t1
	where
		[Title (int)] is not null
	group by 
		[Title (int)]
;


insert into cvp.JobTitleEmployeeLu(EmployeeId, JobTitleId)
	select 
		emp.EmployeeId
		, job.JobTitleId
	from 
		cvp_load.CvPartnerUsageReport as t1
		inner join cvp.Employee as emp on emp.ExternalUserId = t1.[CV Partner User ID]
		inner join cvp.JobTitle as job on job.JobTitleName = t1.[Title (int)]
	where 
		t1.[CV Partner User ID] is not null
		and t1.[Title (int)] is not null
	group by
		emp.EmployeeId
		, job.JobTitleId
;


insert into cvp.Cv(ExternalCvId, EmployeeId)
	select 
		[CV Partner CV ID] as ExternalCvId
		, emp.EmployeeId
	from
		cvp_load.CvPartnerUsageReport as t1
		inner join cvp.Employee as emp on emp.ExternalUserId = t1.[CV Partner User ID]
	where 
		[CV Partner CV ID] is not null
	group by
		[CV Partner CV ID]
		, emp.EmployeeId
;


insert into cvp.Section(ExternalSectionId, CvId)
	select 
		[CV Partner section ID] as ExternalSectionId,
		cv.CvId
	from
		cvp_load.CvPartnerCertifications as t1
		inner join cvp.Cv as cv on cv.ExternalCvId = t1.[CV Partner CV ID]
	where 
		t1.[CV Partner CV ID] is not null
	group by
		[CV Partner section ID],
		cv.CvId
;


insert into cvp.CvCertificationLu(SectionId, CertificationId, CertOrganizer, CertDescription, CertHighlighted
	, Updated, UpdatedByOwner, MonthCompleted, YearCompleted, MonthExpires, YearExpires
	, IsSupervisor, BusinessUnitId, CareerLevelId, SponsorId, PathId, SupervisorId, YearsOfExperience)
	select distinct
		sec.SectionId,
		crt.CertificationId,
		t1.[Organiser (int)] as CertOrganizer,
		t1.[Long description (int)] as CertDescription,
		t1.[Highlighted] as CertHighlighted,
		t1.[Updated],
		t1.[Updated by owner] as UpdatedByOwner,
		t1.[Month] as MonthCompleted,
		t1.[Year] as YearCompleted,
		t1.[Month expire] as MonthExpires,
		t1.[Year expire] as YearExpires,
		case t1.[Custom tag: Supervisor (Y/N)] when 'YES' then 1 else 0 end as IsSupervisor,
		bu.BusinessUnitId,
		cl.CareerLevelId,
		cs.SponsorId,
		p.PathId,
		sponsor.EmployeeId as SupervisorId,
		replace(t1.[Custom tag: Years of Experience ], '+', '') as YearsOfExperience
	from
		cvp_load.CvPartnerCertifications as t1
		inner join cvp.Section as sec on sec.ExternalSectionId = t1.[CV Partner section ID]
		inner join cvp.Certification as crt on t1.[Name (int)] = crt.CertificationTitle
		left join cvp.BusinessUnit as bu on t1.[Custom tag: Business Units] = bu.BusinessUnitName
		left join cvp.CareerLevel as cl on t1.[Custom tag: RIVA Career Level] = cl.CareerLevelDesc
		left join cvp.ClearanceSponsor as cs on t1.[Custom tag: Clearance/Sponsor] = cs.SponsorName
		left join cvp.Path as p on t1.[Custom tag: RIVA Path ] = p.PathDesc
		left join cvp.Employee as sponsor on t1.[Custom tag: Clearance/Sponsor] = sponsor.EmployeeName
	where
		t1.[CV Partner section ID] is not null
;


insert into cvp.CvSkillLu(SkillId, CvId, YearsExperience, Proficiency,
	CareerLevelId, SupervisorId, IsSupervisor, PathId, BusinessUnitId, SponsorId)
	select distinct
		sk.SkillId
		, cv.CvId
		, replace(t.[Year experience], '+', '') as YearsExperience
		, t.[Proficiency (0-5)] as Proficiency
		, cl.CareerLevelId
		, sup.EmployeeId as SupervisorId
		, case t.[Custom tag: Supervisor (Y/N)] when 'YES' then 1 else 0 end as IsSupervisor
		, p.PathId
		, bu.BusinessUnitId
		, sponsor.SponsorId
	from cvp_load.CvPartnerTechnologies as t
		inner join cvp.Skill as sk on t.[Skill name (int)] = sk.SkillName
		inner join cvp.Cv as cv on t.[CV Partner CV ID] = cv.ExternalCvId
		left join cvp.CareerLevel as cl on t.[Custom tag: RIVA Career Level] = cl.CareerLevelDesc
		left join cvp.Employee as sup on t.[Custom tag: Supervisor name] = sup.EmployeeName
		left join cvp.Path as p on t.[Custom tag: RIVA Path ] = p.PathDesc
		left join cvp.BusinessUnit as bu on t.[Custom tag: Business Units] = bu.BusinessUnitName
		left join cvp.ClearanceSponsor as sponsor on t.[Custom tag: Clearance/Sponsor] = sponsor.SponsorName
;


insert into cvp.Usage(
	CvId
	, OwnerLastRemovedOrAddedSection
	, OwnerLastUpdatedCv
	, LastUpdatedCv
	, SummaryOfQualifications
	, OwnerLastUpdatedQualifications
	, ProjectExperiences
	, UniqueRoles
	, OwnerLastUpdatedProjectExperiences
	, HighlightedRoles
	, OwnerLastUpdatedHighlightedRoles
	, SkillCategories
	, OwnerLastUpdatedSkillCategories
	, Educations
	, YearsOfEducation
	, OwnerLastUpdatedEducations
	, WorkExperiences
	, YearsSinceFirstWorkExperience
	, OwnerLastUpdatedWorkExperiences
	, Certifications
	, OwnerLastUpdatedCertifications
	, Courses
	, OwnerLastUpdatedCourses
	, Presentations
	, OwnerLastUpdatedPresentations
	, Recommendations
	, OwnerLastUpdatedRecommendations
	, Positions
	, OwnerLastUpdatedPositions
	, Mentoring
	, OwnerLastUpdatedMentoring
	, Publications
	, OwnerLastUpdatedPublications
	, HonorsAndAwards
	, OwnerLastUpdatedHonorsAndAwards
	, Languages
	, OwnerLastUpdatedLanguages
	, Category
	)
	select distinct 
		cv.CvId
		, t1.[Owner last removed or added a section] as OwnerLastRemovedOrAddedSection
		, t1.[Owner last updated CV] as OwnerLastUpdatedCv
		, t1.[Last updated CV] as LastUpdatedCv
		, t1.[Summary Of Qualifications] as SummaryOfQualifications
		, t1.[Owner last updated Qualifications] as OwnerLastUpdatedQualifications
		, t1.[Project Experiences] as ProjectExperiences
		, t1.[Unique roles] as UniqueRoles
		, t1.[Owner last updated Project Experiences] as OwnerLastUpdatedProjectExperiences
		, t1.[Highlighted roles] as HighlightedRoles
		, t1.[Owner last updated Highlighted roles] as OwnerLastUpdatedHighlightedRoles
		, t1.[Skill categories] as SkillCategories
		, t1.[Owner last updated Skill categories] as OwnerLastUpdatedSkillCategories
		, t1.Educations as Educations
		, t1.[Years of education] as YearsOfEducation
		, t1.[Owner last updated Educations] as OwnerLastUpdatedEducations
		, t1.[Work experiences] as WorkExperiences
		, t1.[Years since first work experience] as YearsSinceFirstWorkExperience
		, t1.[Owner last updated Work experiences] as OwnerLastUpdatedWorkExperiences
		, t1.Certifications
		, t1.[Owner last updated Certifications] as OwnerLastUpdatedCertifications
		, t1.Courses
		, t1.[Owner last updated Courses] as OwnerLastUpdatedCourses
		, t1.Presentations
		, t1.[Owner last updated Presentations] as OwnerLastUpdatedPresentations
		, t1.Recommendations
		, t1.[Owner last updated Recommendations] as OwnerLastUpdatedRecommendations
		, t1.Positions
		, t1.[Owner last updated Positions] as OwnerLastUpdatedPositions
		, t1.Mentoring
		, t1.[Owner last updated Mentoring] as OwnerLastUpdatedMentoring
		, t1.Publications
		, t1.[Owner last updated Publications] as OwnerLastUpdatedPublications
		, t1.[Honors and awards]
		, t1.[Owner last updated Honors and awards] as OwnerLastUpdatedHonorsAndAwards
		, t1.Languages
		, t1.[Owner last updated Languages] as OwnerLastUpdatedLanguages
		, t1.[Category (int)] as Category
	from 
		cvp_load.CvPartnerUsageReport as t1
		inner join cvp.Employee as emp on t1.[CV Partner User ID] = emp.ExternalUserId
		inner join cvp.Cv as cv on cv.ExternalCvId = t1.[CV Partner CV ID]
;

insert into cvp.UpdateLog(DataRefreshDate)values(GETUTCDATE());