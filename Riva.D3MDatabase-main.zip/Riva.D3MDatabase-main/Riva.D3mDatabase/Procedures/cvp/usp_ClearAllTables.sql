CREATE procedure cvp.usp_ClearAllTables as

alter table cvp.CvCertificationLu nocheck constraint all;
alter table cvp.Cv nocheck constraint all;
alter table cvp.CvSkillLu nocheck constraint all;
alter table cvp.JobTitleEmployeeLu nocheck constraint all;
alter table cvp.Section nocheck constraint all;
alter table cvp.SkillCategoryLu nocheck constraint all;
alter table cvp.Usage nocheck constraint all;

delete from cvp.CvCertificationLu;
dbcc checkident('cvp.CvCertificationLu', reseed, 0);

delete from cvp.Certification;
dbcc checkident('cvp.Certification', reseed, 0);

delete from cvp.Cv;
dbcc checkident('cvp.Cv', reseed, 0);

delete from cvp.CvSkillLu;
dbcc checkident('cvp.CvSkillLu', reseed, 0);

delete from cvp.JobTitleEmployeeLu;
dbcc checkident('cvp.JobTitleEmployeeLu', reseed, 0);

delete from cvp.Section;
dbcc checkident('cvp.Section', reseed, 0);

delete from cvp.SkillCategoryLu;
dbcc checkident('cvp.SkillCategoryLu', reseed, 0);

delete from cvp.Usage;
dbcc checkident('cvp.Usage', reseed, 0);

--delete from cvp.BusinessUnit;
--dbcc checkident('cvp.BusinessUnit', reseed, 0);

delete from cvp.CareerLevel;
dbcc checkident('cvp.CareerLevel', reseed, 0);

delete from cvp.ClearanceSponsor;
dbcc checkident('cvp.ClearanceSponsor', reseed, 0);

delete from cvp.Employee;
dbcc checkident('cvp.Employee', reseed, 0);

delete from cvp.JobTitle;
dbcc checkident('cvp.JobTitle', reseed, 0);

delete from cvp.Path;
dbcc checkident('cvp.Path', reseed, 0);

delete from cvp.Skill;
dbcc checkident('cvp.Skill', reseed, 0);

delete from cvp.SkillCategory;
dbcc checkident('cvp.SkillCategory', reseed, 0);


alter table cvp.CvCertificationLu with check check constraint all;
alter table cvp.Cv with check check constraint all;
alter table cvp.CvSkillLu with check check constraint all;
alter table cvp.JobTitleEmployeeLu with check check constraint all;
alter table cvp.Section with check check constraint all;
alter table cvp.SkillCategoryLu with check check constraint all;
alter table cvp.Usage with check check constraint all;
GO


