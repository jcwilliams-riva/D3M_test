create procedure dbo.usp_RemoveDuplicateRecords(@DataRefrechDate date) as

with dups as (
	select 
		ROW_NUMBER() over(partition by [Growth Opp ID] order by [Growth Opp ID]) as rn,
		[Growth Opp ID]
	from dbo.TechnomileTableauExport as t
	where [Data Refresh Date] = @DataRefrechDate
)

delete from dups where rn >= 2
GO


