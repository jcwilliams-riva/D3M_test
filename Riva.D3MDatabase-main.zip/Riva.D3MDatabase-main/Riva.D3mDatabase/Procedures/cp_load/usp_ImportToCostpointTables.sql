create procedure cp_load.usp_ImportToCostpointTables as

exec cp.usp_ClearAllTables;

insert into cp.MacroOrganizationLabel(MacroOrganization)
	select t.[Macro Organization] as MacroOrganization
	from cp_load.CostPointPaylocityUtilReport as t
	where [Macro Organization] is not null
	group by [Macro Organization]
	order by MacroOrganization;

insert into cp.Account(ExternalAccountId)
	select t.[Account ID] as ExternalAccountId
	from cp_load.CostPointPaylocityUtilReport as t
	where [Account ID] is not null
	group by [Account ID]
	order by ExternalAccountId;

insert into cp.BillableTypeLabel(BillableType)
	select t.BILLABLE as BillableType
	from cp_load.CostPointPaylocityUtilReport as t
	where BILLABLE is not null
	group by t.BILLABLE
	order by BillableType;

insert into cp.BusinessUnitLabel(BusinessUnit, MacroOrganizationId)
	select BU as BusinessUnit, mac.MacroOrganizationId
	from 
		cp_load.CostPointPaylocityUtilReport as t
		inner join cp.MacroOrganizationLabel as mac
			on t.[Macro Organization] = mac.MacroOrganization
	where BU is not null
	group by BU, mac.MacroOrganizationId
	order by MacroOrganizationId;

insert into cp.ClinLabel(Clin)
	select [CLIN ] as Clin
	from cp_load.CostPointPaylocityUtilReport as t
	where [CLIN ] is not null
	group by [CLIN ]
	order by Clin;

insert into cp.CostCenterLabel(CostCenter)
	select [Cost Cent Description] as CostCenter
	from cp_load.CostPointPaylocityUtilReport as t
	where [Cost Cent Description] is not null
	group by [Cost Cent Description]
	order by CostCenter;

insert into cp.MeetsRivaUtilLevelLabel(MeetsRivaUtilLevel)
	select [Meets RIVA Util Lvl] as MeetsRivaUtilLevel
	from cp_load.CostPointPaylocityUtilReport as t
	where [Meets RIVA Util Lvl] is not null
	group by [Meets RIVA Util Lvl]
	order by MeetsRivaUtilLevel;

insert into cp.MeetsWorkHoursLabel(MeetsWorkHours)
	select [Meets Work Hours] as MeetsWorkHours
	from cp_load.CostPointPaylocityUtilReport as t
	where [Meets Work Hours] is not null
	group by [Meets Work Hours]
	order by MeetsWorkHours;

insert into cp.OptionYearLabel(OptionYear)
	select t.[Option Year ] as OptionYear
	from cp_load.CostPointPaylocityUtilReport as t
	where [Option Year ] is not null
	group by [Option Year ]
	order by OptionYear;

insert into cp.Position(PositionCode, PositionName)
	select t.[Position Code] as PositionCode, t.[POSITION NAME] as PositionName
	from cp_load.CostPointPaylocityUtilReport as t
	where [Position Code] is not null and [POSITION NAME] is not null
	group by [Position Code], [POSITION NAME]
	order by [Position Code];

insert into cp.Project(ProjectNameCode)
	select t.[Project Name Code] as ProjectNameCode
	from cp_load.CostPointPaylocityUtilReport as t
	where [Project ID] is not null
	group by [Project Name Code]
	order by ProjectNameCode;

insert into cp.TaskOrderLabel(TaskOrder, ProjectId)
	select t.[Task Order ] as TaskOrder, p.ProjectId
	from cp_load.CostPointPaylocityUtilReport as t
	inner join cp.Project as p on t.[Project ID] = p.ExternalProjectId
	where t.[Task Order ] is not null
	group by t.[Task Order ], p.ProjectId
	order by TaskOrder;

insert into cp.RivaLevelLabel(RivaLevel)
	select t.[RIVA LEVEL] as OptionYear
	from cp_load.CostPointPaylocityUtilReport as t
	where [RIVA LEVEL] is not null
	group by [RIVA LEVEL]
	order by OptionYear;

insert into cp.RivaLevelUtilLabel(RivaLevelUtil)
	select t.[RIVA LEVEL UTIL] as RivaLevelUtil
	from cp_load.CostPointPaylocityUtilReport as t
	where [RIVA LEVEL UTIL] is not null
	group by [RIVA LEVEL UTIL]
	order by RivaLevelUtil;

insert into cp.EmployeeTypeLabel(EmployeeType)
	select t.[Employee Type] as EmployeeType
	from cp_load.CostPointPaylocityUtilReport as t
	where [Employee Type] is not null
	group by [Employee Type]
	order by EmployeeType;

insert into cp.Employee(
	ExternalEmployeeId
	, EmployeeName
	, EmployeeEmail
	, EmployeePreferredFirstName
	, BusinessUnitId
	, RivaLevelId
	, PositionId
	, EmployeeTypeId)
	select distinct
		t.[Employee ID] as ExternalEmployeeId
		, t.[NAME 2] as EmployeeName
		, t.[RIVA Email] as EmployeeEmail
		, t.[Preferred/First Name] as EmployeePreferredFirstName
		, bu.BusinessUnitId
		, lvl.RivaLevelId
		, pos.PositionId
		, etype.EmployeeTypeId
	from 
		cp_load.CostPointPaylocityUtilReport as t
		left join cp.BusinessUnitLabel as bu on t.BU = bu.BusinessUnit
		left join cp.RivaLevelLabel as lvl on lvl.RivaLevel = t.[RIVA LEVEL]
		left join cp.Position as pos on pos.PositionCode = t.[Position Code]
		left join cp.EmployeeTypeLabel as etype on etype.EmployeeType = t.[Employee Type]
	where 
		[Employee ID] is not null
		order by EmployeeName;

insert into cp.ProjectEmployeeLu(ProjectId, EmployeeId)
	select
		proj.ProjectId, emp.EmployeeId
	from
		cp.Employee as emp
		inner join cp_load.CostPointPaylocityUtilReport as t 
			on emp.ExternalEmployeeId = t.[Employee ID]
		inner join cp.Project as proj
			on proj.ProjectNameCode = t.[Project Name Code]
	group by proj.ProjectId, emp.EmployeeId
	order by ProjectId, EmployeeId;

insert into cp.Utilization(
	ProjectId
	, TaskOrderId
	, EmployeeId
	, BillableTypeId
	, CostCenterId
	, ClinId
	, SubClinId
	, OptionYearId
	, BusinessUnitId
	, MeetsRivaUtilLevelId
	, MeetsWorkHoursId
	, AccountId
	, PayTypeId
	, RivaLevelUtilId
	, PercWorkedHrs_DivBy_40HrsByMon
	, BillablePerc_AP_40Hrs
	, TotalBillableHoursPerMo
	, TotalHrsWorkedPerMo
	, WorkableHourPerMonth
	, BillableHours
	, PeriodNumber
	, HoursDate
	, EnteredHours
	, TotalEnteredHours
	, WorkingDays)
select distinct
	p.ProjectId
	, tsk.TaskOrderId
	, emp.EmployeeId
	, bill.BillableTypeId
	, cc.CostCenterId
	, clin.ClinId
	, sclin.SubClinId
	, oy.OptionYearId
	, bu.BusinessUnitId
	, rul.MeetsRivaUtilLevelId
	, whl.MeetsWorkHoursId
	, ac.AccountId
	, pt.PayTypeId
	, util.RivaLevelUtilId
	, t.[% worked hrs / 40 hrs by Mon] as PercWorkedHrs_DivBy_40HrsByMon
	, t.[Billable % A/P 40 hrs] as BillablePerc_AP_40Hrs
	, t.[Total Billable Hours Per Mo] as TotalBillableHoursPerMo
	, t.[Total Hrs Worked Per Mo] as TotalHrsWorkedPerMo
	, t.[Workable Hour Per Month] as WorkableHourPerMonth
	, t.[Billable Hours] as BillableHours
	, t.[Period Number] as PeriodNumber
	, t.[Hours Date] as HoursDate
	, t.[Entered Hours] as EnteredHours
	, t.[Total(Entered Hours)] as TotalEnteredHours
	, t.[Working Days] as WorkingDays
from
	cp_load.CostPointPaylocityUtilReport as t
	left join cp.Project as p on t.[Project ID] = p.ExternalProjectId
	left join cp.TaskOrderLabel as tsk on t.[Task Order ] = tsk.TaskOrder
	left join cp.Employee as emp on t.[Employee ID] = emp.ExternalEmployeeId
	left join cp.BillableTypeLabel as bill on t.BILLABLE = bill.BillableType
	left join cp.CostCenterLabel as cc on t.[Cost Cent Description] = cc.CostCenter
	left join cp.ClinLabel as clin on t.[CLIN ] = clin.Clin
	left join cp.SubClinLabel as sclin on t.[Sub CLIN ] = sclin.SubClin
	left join cp.OptionYearLabel as oy on t.[Option Year ] = oy.OptionYear
	left join cp.BusinessUnitLabel as bu on t.BU = bu.BusinessUnit
	left join cp.MeetsRivaUtilLevelLabel as rul on t.[Meets RIVA Util Lvl] = rul.MeetsRivaUtilLevel
	left join cp.MeetsWorkHoursLabel as whl on t.[Meets Work Hours] = whl.MeetsWorkHours
	left join cp.Account as ac on t.[Account ID] = ac.ExternalAccountId
	left join cp.PayTypeLabel as pt on t.[Pay Type] = pt.PayType
	left join cp.RivaLevelUtilLabel  as util on t.[RIVA LEVEL UTIL] = util.RivaLevelUtil
;