﻿-- cp = CostPoint
CREATE SCHEMA [cp]
