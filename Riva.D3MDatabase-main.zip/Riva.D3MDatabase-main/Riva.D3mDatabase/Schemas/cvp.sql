﻿-- cvp = CV Partner
CREATE SCHEMA [cvp]
