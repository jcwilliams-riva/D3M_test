﻿-- util = Utility table
CREATE SCHEMA [util]
