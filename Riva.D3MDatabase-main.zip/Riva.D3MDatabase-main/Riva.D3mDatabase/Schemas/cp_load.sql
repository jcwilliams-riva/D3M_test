﻿-- cp_load = CostPoint Loading Table
CREATE SCHEMA [cp_load]
