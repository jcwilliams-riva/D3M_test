﻿-- cvp_load = CV Partner Loading Table
CREATE SCHEMA [cvp_load]
