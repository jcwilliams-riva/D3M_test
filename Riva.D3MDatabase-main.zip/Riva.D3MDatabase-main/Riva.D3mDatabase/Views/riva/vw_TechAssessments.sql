create view riva.vw_TechAssessments as

select top 1000
    doc.DocId
    , doc.DocName
    , doc.DocType
    , tech.CategoryName as Technical
    , practice.CategoryName as Practice
    , lbl.CategoryName as Category
    , term.Term
    , term.Lemmatized
    , term.Stemmed
    , t.MatchingTerms
    , t.Confidence
    , t.Threshold
    , t.TermCount
    , t.TermImportance
    , t.ImportanceInDoc
    , t.ImportanceScale
    , t.ImportanceCategory
    , doc.DocUrl
    , p.ProjectName
    , p.Account
    , p.TCV
    , p.AwardDate
    , p.PrimeOrSub
    , p.Tech
from
    riva.TechAssessment as t
    left join riva.Document as doc on t.DocId = doc.DocId
    left join riva.Project as p on doc.ProjectId = p.ProjectId
    left join riva.Term as term on t.TermId = term.TermId
    left join riva.Category as lbl on term.CategoryId = lbl.CategoryId
    left join riva.Category as practice on lbl.ParentId = practice.CategoryId
    left join riva.Category as tech on practice.ParentId = tech.CategoryId
go