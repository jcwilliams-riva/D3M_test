create view riva.vw_PastPerformanceMatches as

with cte_tech as (
   select
        t.DocId
        , doc.DocName
        , doc.DocType
        , lbl.CategoryId
        , tech.CategoryName as Technical
        , practice.CategoryName as Practice
        , lbl.CategoryName as Category
        , SUM(t.TermCount) as TermCount
        , DENSE_RANK() over(partition by t.DocId order by SUM(t.TermCount) desc) as Rank
    from
        riva.TechAssessment as t
        inner join riva.Document as doc on t.DocId = doc.DocId and doc.DocType = 'TECH'
        inner join riva.Term as term on t.TermId = term.TermId
        inner join riva.Category as lbl on term.CategoryId = lbl.CategoryId
        inner join riva.Category as practice on lbl.ParentId = practice.CategoryId
        inner join riva.Category as tech on practice.ParentId = tech.CategoryId
    group by
        t.DocId
        , doc.DocName
        , doc.DocType
        , lbl.CategoryId
        , tech.CategoryName
        , practice.CategoryName
        , lbl.CategoryName
)

, cte_riva as (
    select
        doc.DocId
        , doc.DocName
        , doc.DocUrl
        , doc.DocType
        , lbl.CategoryId
        , tech.CategoryName as Technical
        , practice.CategoryName as Practice
        , lbl.CategoryName as Category
        , proj.ProjectId
        , proj.ProjectName
        , proj.TCV
        , proj.AwardDate
        , proj.PrimeOrSub
        , proj.Tech
        --, SUM(t.TermCount) as TermCount
        , DENSE_RANK() over(partition by doc.DocId order by SUM(t.TermCount) desc) as Rank
    from
        riva.TechAssessment as t
        inner join riva.Document as doc on t.DocId = doc.DocId and doc.DocType in ('PP', 'SOW')
        inner join riva.Term as term on t.TermId = term.TermId
        inner join riva.Category as lbl on term.CategoryId = lbl.CategoryId
        inner join riva.Category as practice on lbl.ParentId = practice.CategoryId
        inner join riva.Category as tech on practice.ParentId = tech.CategoryId
        left join riva.Project as proj on doc.ProjectId = proj.ProjectId
    group by
        doc.DocId
        , doc.DocName
        , doc.DocUrl
        , doc.DocType
        , lbl.CategoryId
        , tech.CategoryName
        , practice.CategoryName
        , lbl.CategoryName
        , proj.ProjectId
        , proj.ProjectName
        , proj.TCV
        , proj.AwardDate
        , proj.PrimeOrSub
        , proj.Tech
)

, cte_ranked as (
    select
        tech.DocId
        , tech.DocName
        , tech.DocType
        , tech.Technical
        , tech.Practice
        , tech.Category
        , (case 
            when riva.Rank < tech.Rank then 1
            when riva.Rank = tech.Rank then 0
            else -1
        end) as FitRank
        , riva.ProjectId
        , riva.ProjectName
        , riva.AwardDate
        , riva.TCV
        , riva.PrimeOrSub
        , riva.DocType as PastPerfType
        , riva.DocUrl as PastPerfUrl
        , riva.Tech
        , riva.DocName as PastPerfDocName
    from 
        cte_tech as tech

        left join cte_riva as riva 
            on tech.CategoryId = riva.CategoryId
)

select
    ROW_NUMBER() over(order by DocId, FitRank desc) as RowId
    , t.*
    , case FitRank
        when 1 then 'Exceeds Fit'
        when 0 then 'Fit'
        else 'Poor Fit'
    end as Fit
from cte_ranked as t;
