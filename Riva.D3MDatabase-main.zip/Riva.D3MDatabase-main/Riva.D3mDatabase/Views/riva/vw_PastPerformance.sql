
create view riva.vw_PastPerformance as
select
	d.DocId
	, d.DocName
	, d.DocType
	, d.DocUrl
	, d.SharePointId
	, p.ProjectId
	, p.ProjectName
	, p.Account
	, p.AwardDate
	, p.PrimeOrSub
	, p.TCV
	, p.Tech
from 
	riva.Document as d
	left join riva.Project as p on d.ProjectId = p.ProjectId
go