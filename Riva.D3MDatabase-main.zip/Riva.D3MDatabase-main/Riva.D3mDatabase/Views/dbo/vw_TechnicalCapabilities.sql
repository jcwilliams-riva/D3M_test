
create view dbo.vw_TechnicalCapabilities as
select 
	oppid as GrowthOppId, value as FunctionalArea
from (
	select [Functional Area ] as fa, [Growth Opp ID] as oppid
	from dbo.vw_TechnomileDataLatestVersion
	where [Functional Area ] is not null
	group by [Functional Area ], [Growth Opp ID]
) as t
cross apply string_split(fa, ';');