
create view dbo.vw_FutureOpportunityCounts as
select 
	count(distinct [GrowthOppId]) as OpportunityCount
    , FunctionalArea
from 
	[dbo].[vw_TechnicalCapabilities] as v

	inner join dbo.vw_TechnomileDataLatestVersion as t 
		on v.GrowthOppId = t.[Growth Opp ID]
where 
	t.[RFP Release date] > GETDATE()
group by 
	[FunctionalArea]
go