create view dbo.vw_TechnomileMonthlyPVPoPRevenue as
/*
	Estimates the monthly value of a contract from the Award Date to the end of the Period of Performance (PoP)
	[Est PV PoP Month] = [Potential Value (PV)] / [Period of Performance (Months)]
	[PoP Month (Date)]
	
	Created by: John Bonfardeci
	Created: 2022-09-09

	Modified by: John Bonfardeci
	Modified: 2022-09-10
*/

with cte_date_dim as (
	select 
		ROW_NUMBER() over(order by TheDate) as row_num
		, TheDate
		, TheDay
		, TheLastOfMonth
		, TheFirstOfNextMonth
		, TheYear
		, TheMonth
	from 
		util.DateDimension
)

, cte_data_clean as (
	select
		t.[Growth Opp ID] as opp_id
		, t.[Award Date] as award_date
		, dateadd(month, t.[Period of Performance (Months)], t.[Award Date]) as contract_end_date
		, convert(decimal(12,3), t.[Potential Value (PV)]) as pv
		, convert(int, t.[Period of Performance (Months)]) as pop
		, convert(decimal(12,3), (t.[Potential Value (PV)]) /
			convert(decimal(12,3), t.[Period of Performance (Months)])) as est_pv_pop_month
		, dateadd(month, 1, t.[Award Date]) as first_payday
		, dateadd(month, t.[Period of Performance (Months)] + 1, t.[Award Date]) as last_payday
	from 
		dbo.vw_TechnomileDataLatestVersion as t
	where
		t.[Award Date] is not null
		and isnull(t.[Potential Value (PV)], 0) > 1
		and isnull(t.[Period of Performance (Months)], 0) > 0
)

, cte_start_date as (
	select
		opp_id
		, award_date
		, (case 
			when datepart(day, award_date) > 28 
				then (
					select top 1 TheFirstOfNextMonth 
					from cte_date_dim 
					where TheYear = datepart(year, award_date) and TheMonth = datepart(month, award_date)
				)
			else award_date
		end) as start_date
		, contract_end_date
		, pv
		, pop
		, est_pv_pop_month
		, first_payday
		, last_payday
	from 
		cte_data_clean
)

, cte_pv as (
	select
		ROW_NUMBER() over(partition by opp_id order by dates.TheDate) as row_num
		, opp_id
		, award_date
		, start_date
		, contract_end_date
		, pv
		, pop
		, est_pv_pop_month
		, sum(est_pv_pop_month) over(partition by opp_id order by dates.TheDate) as running_total
		, dates.TheDate as pop_month
	from 
		cte_start_date as t

		inner join cte_date_dim as dates 
			on dates.TheDate >= first_payday and dates.TheDate < last_payday
			--on dates.TheDate > start_date and dates.TheDate <= DATEADD(month, pop, start_date)
			and dates.TheDay = datepart(day, start_date)		
)

, cte_totals as (
	select 
		max(row_num) as row_num
		, opp_id
		, max(award_date) as award_date
		, max(start_date) as start_date
		, max(contract_end_date) as contract_end_date
		, max(est_pv_pop_month) as est_pv_pop_month
		, max(pv) as pv
		, max(pop) as pop
		, max(running_total) as total
		, abs(max(running_total) - max(pv)) as error
		, max(pop_month) as pop_month
	from cte_pv 
	group by opp_id
)

-- test accuracy of running total within tolerance of $5 delta
--select * from cte_totals where error > 5
--select * from cte_totals

select
	row_num as RowNum
	, opp_id as [Growth Opp ID]
	, award_date as [Award Date]
	, [start_date] as [Contract Start Date]
	, contract_end_date as [Contract End Date]
	, pv as [Potential Value (PV)]
	, pop as [Period of Performance (Months)]
	, est_pv_pop_month as [Est PV PoP Month]
	, running_total as [Running Total]
	, pop_month as [PoP Month (Date)]

from cte_pv
;
--where opp_id = 'a0S4P000006exPwUAI' -- test
--select * from cte_totals where error > 5
GO


