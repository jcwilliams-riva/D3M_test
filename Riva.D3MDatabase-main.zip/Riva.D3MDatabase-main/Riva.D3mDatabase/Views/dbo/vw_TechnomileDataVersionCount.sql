create view dbo.vw_TechnomileDataVersionCount as

with version_numbers as (
	select 
		[Data Refresh Date]
		, ROW_NUMBER() over(order by [Data Refresh Date]) as VersionId
	from 
		dbo.TechnomileTableauExport
	group by 
		[Data Refresh Date]
)

, prior_version as (
	select [Data Refresh Date], VersionId
	from version_numbers
	where VersionId = (select max(versionId) from version_numbers)-1
)

, current_ct as (
	select 
		count(0) as VersionCount
		, (select top 1 max(VersionId) from version_numbers) as VersionId
	from 
		dbo.TechnomileTableauExport
	where [Data Refresh Date] = (select top 1 max([Data Refresh Date]) from version_numbers)
)

, previous_ct as (
	select 
		count(0) as VersionCount
		, vn.VersionId
	from 
		dbo.TechnomileTableauExport as t

		inner join prior_version as vn
			on t.[Data Refresh Date] = vn.[Data Refresh Date]
	group by
		vn.VersionId
)

select 
	current_ct.VersionId as CurrentVersionId
	, previous_ct.VersionId as PreviousVersionId
	, current_ct.VersionCount as CurrentVersionCount
	, previous_ct.VersionCount as PreviousVersionCount
	, (current_ct.VersionCount - previous_ct.VersionCount) as Diff
from current_ct full join previous_ct on 1=1
;
GO


