create view dbo.vw_TechnomileDataLatestVersion as

with version_numbers as (
	select 
		[Data Refresh Date]
		, ROW_NUMBER() over(order by [Data Refresh Date]) as VersionId
	from 
		dbo.TechnomileTableauExport
	group by 
		[Data Refresh Date]
)

, uniques as (
	select [Growth Opp ID]
	from dbo.TechnomileTableauExport
	group by [Growth Opp ID]
	having count([Growth Opp ID]) = 1
)

select 
	[Id]
	, [Current Yr Qualified Pipeline (%)]
	, [Current Yr Capture Rate (%)]
	, [Current Yr Win Rate (%)]
	, [Live Pipeline]
	, cur.[Data Refresh Date]
	, [Award Date Buckets]
	, [RFP Release Date Buckets]
	, [Growth Opp Owner]
	, [Growth Opp ID]
	, [Growth Opp Name]
	, [CreatedDate (PD)]
	, [LastModifiedDate (PD)]
	, [Account Name Code]
	, [Total Contract Value (TCV)]
	, [Award Date]
	, [Competition Type]
	, [Contract Type(s)]
	, [Contract Vehicle Name]
	, [Contract Vehicle Code]
	, [Draft RFP Release Date]
	, [Incumbent]
	, [Our Role]
	, [Parent Opportunity]
	, [Period of Performance (Months)]
	, [Place of Delivery Or Performance]
	, [Primary NAICS ID]
	, [Primary NAICS Size Standard]
	, [Primary NAICS Title ]
	, [Primary NAICS Requirement]
	, [Questions Due Date]
	, [RFI Release Date]
	, [RFP/Solicitation ID]
	, [RFP Release date]
	, [Stage]
	, [Start Date]
	, [Proposal Due Date]
	, [Calculated PWIN (%)]
	, [Bid Type]
	, [Type of Award]
	, [GovWin IQ Opportunity URL]
	, [Our Workshare %]
	, [Incumbent Eligibility]
	, [Current Contract End Date ]
	, [Agency Name Code ]
	, [Number of Awards ]
	, [Functional Area ]
	, [End Date]
	, [Partner(s)]
	, [Market]
	, [Prime Name ]
	, [Business Unit]
	, [Opportunity Prioritization]
	, [Financial PWIN]
	, [Fed Department]
	, [Related Site URL]
	, [Technology Vendors]
	, [FTE]
	, [Potential Value (PV)]
	, [Yr 1 PV %]
	, [Yr 2 PV %]
	, [Yr 3 PV %]
	, [Yr 4 PV %]
	, [Yr 5 PV %]
	, [Total Potential Value (TPV)]
	, [Present at Next Growth Meeting]
	, [Account Name]
	, [BD Lead]
	, [Client Delivery]
	, [Capture Manager]
	, [Opportunity ID]
	, [Contract Vehicle (Abbr)]
	, [Contract Vehicle Ceiling]
	, isnull(CreatedDate, [CreatedDate (PD)]) as [CreatedDate]
	, isnull(ModifiedDate, [LastModifiedDate (PD)]) as [ModifiedDate]
	, vn.[VersionId]

	, case 
		when (select top 1 [Growth Opp ID] from uniques as u where cur.[Growth Opp ID] = u.[Growth Opp ID]) is null then 'Prior' 
		else 'Newly Added'
	end as Recency
	, [Program Summary]
	, [Solutions Architect]
from 
	dbo.TechnomileTableauExport as cur
	
	inner join (select top 1 [Data Refresh Date], VersionId 
					from version_numbers 
					order by VersionId desc
				) as vn on cur.[Data Refresh Date] = vn.[Data Refresh Date]
;
GO


