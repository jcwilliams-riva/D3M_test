create view dbo.vw_PastPerformanceCounts as 

with cte as (
select
	count(distinct [Source URL]) as PastPerfCount

	, case
		when Category in ('Human Centered Design') then 'Human Centered Design'
		when Category in ('Programming Language', 'Software Development', 'DevSecOps', 'IT Service'
							, 'IT Support', 'Communications Software', 'Operating System', 'Productivity Software'
							, 'Application Modernization', 'Accessibility')
			then 'Digital Platforms'
		when Category in ('Cybersecurity') then 'Cybersecurity'
		when Practice = 'Applications and Services' then 'Application Services'
		when Practice = 'Data and Analytics' then 'Data & Analytics'
		when Practice = 'Cloud and Infrastructure' then 'Cloud & Infrastructure'
		else Practice
	end as Practice

	, case 
		when Category in ('Analytics', 'Healthcare Analytics') then 'Business Intelligence (BI)'
		when Category in ('AWS Service', 'Azure Service', 'Cloud', 'Google Cloud Platform') 
			then 'Cloud'
		when Category in ('Bioinformatics', 'GIS') then 'Data Science'
		when Category in ('Browser') then 'Web Services'
		when Category in ('Programming Language', 'Software Development', 'DevSecOps', 'IT Service'
							, 'IT Support', 'Communications Software', 'Operating System', 'Productivity Software'
							, 'Application Modernization', 'Accessibility') 
			then 'Systems Engineering'
		when Category in ('Data Governance') then 'Data Management & Governance'
		when Category in ('Database Vendor') then 'Data Storage'
		else Category
	end as Subpractice
from 
	dbo.PastPerformances
where
	Technical = 'Technical' and Category not in ('Gartner')
group by
	Practice, Category
)

select 
	sum(PastPerfCount) as PastPerfCount
	, Practice
	, Subpractice
from cte
group by
	Practice
	, Subpractice
;