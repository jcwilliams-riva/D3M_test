create view cvp.vw_ProjectCvpCompleteness as
with cte_emp_proj as (
    select
        p.[Project ID] as ProjectCode
        , p.[Project Name] as ProjectName
        , e.[Employee Email] as EmployeeEmail
        , e.[Employee Name (Last Suffix, First MI)] as EmployeeName
        , u.[Employee ID] as EmployeeId
    from 
        ukg.EmployeeList as e

        left join deltek.Utilization as u
            on convert(int, replace(u.[Employee ID], 'E', '')) = convert(int, replace(e.[Employee Number], 'E', ''))

        left join deltek.ProjectList as p
            on len(p.[Project ID]) <= 6 
                and p.[Project ID] = substring(u.[Project ID], 1, 6)
    where 
        e.[Employee Email] is not null
        and len(p.[Project ID]) <= 6
        and p.[Project ID] not in ('FRINGE', 'GENADM', 'NON-BILLABLE - G&A', 'BNPADM'
            , 'NON-BILLABLE - O/H', 'NON-BILLABLE O/H', 'KARMA1', 'MATHND', 'OVHEAD', 'SVCNTR')
        and p.[Project ID] not like 'BNPOST%'
    group by
        p.[Project ID]
        , p.[Project Name]
        , e.[Employee Email]
        , u.[Employee ID]
        , e.[Employee Name (Last Suffix, First MI)]
)

select
    p.EmployeeId
    , d.[CV Partner User ID-1] as CvpUserId
    , isnull(d.Name, p.EmployeeName) as EmployeeName
    , d.Email
    , p.ProjectCode
    , p.ProjectName
    , AVG([Percent Filled]) as MeanPercFilled
from 
    cvp.vw_Dashboard as d
    full join cte_emp_proj as p on d.Email = p.EmployeeEmail
where 
    [REQUIRED] = 'REQUIRED'
group by
    d.[CV Partner User ID-1]
    , d.Email
    , p.EmployeeId
    , p.ProjectCode
    , p.ProjectName
    , isnull(d.Name, p.EmployeeName)
