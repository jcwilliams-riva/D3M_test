create view cvp.vw_GraphNodes as

SELECT 
	FromNodeType
	, FromNodeId
	, FromNodeName
	, RelationshipType
	, ToNodeType
	, ToNodeId
	, ToNodeName
FROM (

-- Employee -> JobTitle
SELECT DISTINCT
	'Employee' as FromNodeType
	, emp.EmployeeId as FromNodeId
	, emp.EmployeeName as FromNodeName
	, 'HAS_JOBTITLE' as RelationshipType
	, 'JobTitle' as ToNodeType
	, job.JobTitleId as ToNodeId
	, job.JobTitleName as ToNodeName
FROM cvp.Employee as emp
INNER JOIN cvp.JobTitleEmployeeLu as lu ON emp.EmployeeId = lu.EmployeeId
INNER JOIN cvp.JobTitle as job on lu.JobTitleId = job.JobTitleId
--
UNION ALL
--
-- Employee -> Certification
SELECT DISTINCT 
	'Employee' as FromNodeType
	, emp.EmployeeId as FromNodeId
	, emp.EmployeeName as FromNodeName
	, 'CERTIFIED_IN' as RelationshipType
	, 'Certification' as ToNodeType
	, crt.CertificationId as ToNodeId
	, crt.CertificationTitle as ToNodeId
FROM cvp.Employee as emp
INNER JOIN cvp.Cv as cv on emp.EmployeeId = cv.EmployeeId
INNER JOIN cvp.Section as sec ON cv.CvId = sec.CvId
INNER JOIN cvp.CvCertificationLu as lu on lu.SectionId = sec.SectionId
INNER JOIN cvp.Certification as crt on crt.CertificationId = lu.CertificationId
--
UNION ALL
--
-- Certification -> CertOrganizer
SELECT DISTINCT 
	'Certification' as FromNodeType
	, convert(varchar(20), crt.CertificationId) as FromNodeId
	, crt.CertificationTitle as FromNodeName
	, 'ORGANIZED_BY' as RelationshipType
	, 'CertOrganizer' as ToNodeType
	, ROW_NUMBER() over(order by lu.CertOrganizer) as ToNodeId
	, lu.CertOrganizer as ToNodeName
FROM cvp.CvCertificationLu as lu
INNER JOIN cvp.Certification as crt on lu.CertificationId = crt.CertificationId
	AND lu.CertOrganizer IS NOT NULL
--
UNION ALL
--
-- Certification -> BusinessUnit
SELECT DISTINCT 
	'Certification' as FromNodeType
	, crt.CertificationId as FromNodeId
	, crt.CertificationTitle as FromNodeName
	, 'BIZ_UNIT' as RelationshipType
	, 'BusinessUnit' as ToNodeType
	, lu.BusinessUnitId as ToNodeId
	, bu.BusinessUnitAlias as ToNodeName
FROM cvp.CvCertificationLu as lu 
INNER JOIN cvp.Certification as crt on crt.CertificationId = lu.CertificationId
LEFT JOIN cvp.BusinessUnit as bu on lu.BusinessUnitId = bu.BusinessUnitId
--
UNION ALL
--
-- Certification -> Sponsor
SELECT DISTINCT 
	'Certification' as FromNodeType
	, crt.CertificationId as FromNodeId
	, crt.CertificationTitle as FromNodeName
	, 'SPONSORED_BY' as RelationshipType
	, 'Sponsor' as ToNodeType
	, lu.SponsorId as ToNodeId
	, cs.SponsorName as ToNodeName
FROM cvp.CvCertificationLu as lu
INNER JOIN cvp.Certification as crt on crt.CertificationId = lu.CertificationId
INNER JOIN cvp.ClearanceSponsor as cs on lu.SponsorId = cs.SponsorId
--
UNION ALL
--
-- Certification -> CareerLevel
SELECT DISTINCT 
	'Certification' as FromNodeType
	, crt.CertificationId as FromNodeId
	, crt.CertificationTitle as FromNodeName
	, 'CEREER_LEVEL' as RelationshipType
	, 'CareerLevel' as ToNodeType
	, lu.CareerLevelId as ToNodeId
	, cl.CareerLevelDesc as ToNodeName
FROM cvp.CvCertificationLu as lu
INNER JOIN cvp.Certification as crt on crt.CertificationId = lu.CertificationId
INNER JOIN cvp.CareerLevel as cl on lu.CareerLevelId = cl.CareerLevelId
--
UNION ALL
--
-- Certification -> Path
SELECT DISTINCT 
	'Certification' as FromNodeType
	, crt.CertificationId as FromNodeId
	, crt.CertificationTitle as FromNodeName
	, 'ON_CAREER_PATH' as RelationshipType
	, 'CareerPath' as ToNodeType
	, lu.PathId as ToNodeId
	, p.PathDesc as ToNodeName
FROM cvp.CvCertificationLu as lu
INNER JOIN cvp.Certification as crt on crt.CertificationId = lu.CertificationId
INNER JOIN cvp.[Path] as p on lu.PathId = p.PathId
--
UNION ALL
--
-- Employee -> Skill
SELECT DISTINCT 
	'Employee' as FromNodeType
	, emp.EmployeeId as FromNodeId
	, emp.EmployeeName as FromNodeName
	, 'SKILLED_IN' as RelationshipType
	, 'Skill' as ToNodeType
	, sk.SkillId as ToNodeId
	, sk.SkillName as ToNodeName
FROM cvp.Employee as emp
INNER JOIN cvp.Cv as cv ON emp.EmployeeId = cv.EmployeeId
INNER JOIN cvp.CvSkillLu as cv_lu ON cv.CvId = cv_lu.CvId
INNER JOIN cvp.Skill as sk on cv_lu.SkillId = sk.SkillId
--
UNION ALL
--
-- Skill -> SkillCategory
SELECT DISTINCT 
	'Skill' as FromNodeType
	, sk.SkillId as FromNodeId
	, sk.SkillName as FromNodeName
	, 'IS_UNDER' as RelationshipType
	, 'SkillCategory' as ToNodeType
	, cat.SkillCategoryId as ToNodeId
	, cat.SkillCategoryName as ToNodeName
FROM cvp.Skill as sk
LEFT JOIN cvp.SkillCategoryLu as sk_lu ON sk.SkillId = sk_lu.SkillId
LEFT JOIN cvp.SkillCategory as cat ON sk_lu.SkillCategoryId = cat.SkillCategoryId
--
UNION ALL
--
-- Skill -> CareerLevel
SELECT DISTINCT 
	'Skill' as FromNodeType
	, sk.SkillId as FromNodeId
	, sk.SkillName as FromNodeName
	, 'CAREER_LEVEL' as RelationshipType
	, 'CareerLevel' as ToNodeType
	, cv_lu.CareerLevelId as ToNodeId
	, cl.CareerLevelDesc as ToNodeName
FROM cvp.CvSkillLu as cv_lu
INNER JOIN cvp.Skill as sk on cv_lu.SkillId = sk.SkillId
INNER JOIN cvp.CareerLevel as cl on cv_lu.CareerLevelId = cl.CareerLevelId
--
UNION ALL
--
-- Skill -> Path
SELECT DISTINCT 
	'Skill' as FromNodeType
	, sk.SkillId as FromNodeId
	, sk.SkillName as FromNodeName
	, 'ON_CAREER_PATH' as RelationshipType
	, 'CareerPath' as ToNodeType
	, cv_lu.PathId as ToNodeId
	, p.PathDesc as ToNodeName
FROM cvp.CvSkillLu as cv_lu
INNER JOIN cvp.Skill as sk on cv_lu.SkillId = sk.SkillId
INNER JOIN cvp.[Path] as p on cv_lu.PathId = p.PathId
--
UNION ALL
--
-- Skill -> BusinessUnit
SELECT DISTINCT 
	'Skill' as FromNodeType
	, sk.SkillId as FromNodeId
	, sk.SkillName as FromNodeName
	, 'BIZ_UNIT' as RelationshipType
	, 'BusinessUnit' as ToNodeType
	, cv_lu.BusinessUnitId as ToNodeId
	, bu.BusinessUnitAlias as ToNodeName
FROM cvp.CvSkillLu as cv_lu
INNER JOIN cvp.Skill as sk on cv_lu.SkillId = sk.SkillId
INNER JOIN cvp.BusinessUnit as bu on cv_lu.BusinessUnitId = bu.BusinessUnitId
--
UNION ALL
--
-- Skill -> Sponsor
SELECT DISTINCT 
	'Skill' as FromNodeType
	, sk.SkillId as FromNodeId
	, sk.SkillName as FromNodeName
	, 'SPONSORED_BY' as RelationshipType
	, 'Sponsor' as ToNodeType
	, cv_lu.SponsorId as ToNodeId
	, cs.SponsorName as ToNodeName
FROM cvp.CvSkillLu as cv_lu
INNER JOIN cvp.Skill as sk on cv_lu.SkillId = sk.SkillId
INNER JOIN cvp.ClearanceSponsor as cs on cv_lu.SponsorId = cs.SponsorId
--
UNION ALL
--
-- Employee -> Project
SELECT DISTINCT
	'Employee' as FromNodeType
	, ISNULL(cvp_emp.EmployeeId, emp.EmployeeId) as FromNodeId
	, ISNULL(cvp_emp.EmployeeName, emp.EmployeeName) as FromNodeName
	, 'ASSIGNED_TO' as RelationshipType
	, 'Project' as ToNodeType
	, p.ProjectId as ToNodeId
	, p.ProjectNameCode as ToNodeName
FROM 
	cp.Employee as emp
	INNER JOIN cp.ProjectEmployeeLu as proj_lu 
		ON proj_lu.EmployeeId = emp.EmployeeId
	INNER JOIN cp.Project as p 
		ON proj_lu.ProjectId = p.ProjectId
	FULL JOIN cvp.Employee as cvp_emp 
		ON emp.EmployeeEmail = cvp_emp.EmployeeEmail
) as t
WHERE FromNodeId IS NOT NULL
AND FromNodeName IS NOT NULL
AND ToNodeId IS NOT NULL 
AND ToNodeName IS NOT NULL
;