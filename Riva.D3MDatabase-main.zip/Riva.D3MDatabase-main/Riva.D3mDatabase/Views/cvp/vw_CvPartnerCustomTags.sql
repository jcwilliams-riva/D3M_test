create view cvp.vw_CvPartnerCustomTags as

/*
	Question: What Custom Tags does each data set have in common?
	Answers: 
		Based on the query below, the Usage dataset contains the the Custom Tags from the Tech dataset.
		But sometimes there is a Custom Tag in Usage that is not in the other two...and sometimes Tech as a tag the other two do not.
		The Certification dataset is the only one with a Section ID mapped to a Custom Tag for each Section->Certification.
*/

with cteCert as (
	select 
		t.[CV Partner User ID] as CertUserId
		, t.[CV Partner CV ID] as CertCvId
		, t.[CV Partner section ID] as CertSectionId
		, t.[Custom tag: Business Units] as CertBusinessUnits
		, t.[Custom tag: Clearance/Sponsor] as CertClearanceSponsor
		, t.[Custom tag: RIVA Career Level] as CertRivaCareerLevel
		, t.[Custom tag: RIVA Path ] as CertRivaPath
		, t.[Custom tag: Supervisor (Y/N)] as CertIsSupervisor
		, t.[Custom tag: Supervisor name] as CertSupervisorName
		, t.[Custom tag: Years of Experience ] as CertYearsOfExperience
	from
		cvp_load.CvPartnerCertifications as t
	group by
		t.[CV Partner User ID]
		, t.[CV Partner CV ID]
		, t.[Custom tag: Business Units]
		, t.[Custom tag: Clearance/Sponsor]
		, t.[Custom tag: RIVA Career Level]
		, t.[Custom tag: RIVA Path ]
		, t.[Custom tag: Supervisor (Y/N)]
		, t.[Custom tag: Supervisor name]
		, t.[Custom tag: Years of Experience ]
		, t.[CV Partner section ID]
)

, cteTech as (
	select
		t.[CV Partner User ID] as TechUserId
		, t.[CV Partner CV ID] as TechCvId
		, t.[Custom tag: Business Units] as TechBusinessUnits
		, t.[Custom tag: Clearance/Sponsor] as TechClearanceSponsor
		, t.[Custom tag: RIVA Career Level] as TechRivaCareerLevel
		, t.[Custom tag: RIVA Path ] as TechRivaPath
		, t.[Custom tag: Supervisor (Y/N)] as TechIsSupervisor
		, t.[Custom tag: Supervisor name] as TechSupervisorName
		, t.[Custom tag: Years of Experience ] as TechYearsOfExperience
	from
		cvp_load.CvPartnerTechnologies as t
	group by
		t.[CV Partner User ID]
		, t.[CV Partner CV ID]
		, t.[Custom tag: Business Units]
		, t.[Custom tag: Clearance/Sponsor]
		, t.[Custom tag: RIVA Career Level]
		, t.[Custom tag: RIVA Path ]
		, t.[Custom tag: Supervisor (Y/N)]
		, t.[Custom tag: Supervisor name]
		, t.[Custom tag: Years of Experience ]
)

, cteUsage as (
	select
		t.[CV Partner User ID] as UsageUserId
		, t.[CV Partner CV ID] as UsageCvId
		, t.[Custom tag: Business Units] as UsageBusinessUnits
		, t.[Custom tag: Clearance/Sponsor] as UsageClearanceSponsor
		, t.[Custom tag: RIVA Career Level] as UsageRivaCareerLevel
		, t.[Custom tag: RIVA Path ] as UsageRivaPath
		, t.[Custom tag: Supervisor (Y/N)] as UsageIsSupervisor
		, t.[Custom tag: Supervisor name] as UsageSupervisorName
		, t.[Custom tag: Years of Experience ] as UsageYearsOfExperience
	from
		cvp_load.CvPartnerUsageReport as t
	group by
		t.[CV Partner User ID]
		, t.[CV Partner CV ID]
		, t.[Custom tag: Business Units]
		, t.[Custom tag: Clearance/Sponsor]
		, t.[Custom tag: RIVA Career Level]
		, t.[Custom tag: RIVA Path ]
		, t.[Custom tag: Supervisor (Y/N)]
		, t.[Custom tag: Supervisor name]
		, t.[Custom tag: Years of Experience ]
)

select distinct
	coalesce(t1.CertUserId, t2.TechUserId, t3.UsageUserId) as UserId
	, case when t1.CertUserId is null then 'CERT'
		when t2.TechUserId is null then 'TECH'
		when t3.UsageUserId is null then 'USAGE'
		else 'NONE'
	end as Missing
	--, t1.CertUserId, t2.TechUserId, t3.UsageUserId
	, coalesce(t1.CertBusinessUnits, t2.TechBusinessUnits, t3.UsageBusinessUnits) as BusinessUnits
	, t1.CertBusinessUnits, t2.TechBusinessUnits, t3.UsageBusinessUnits
	
	, coalesce(t1.CertClearanceSponsor, t2.TechClearanceSponsor, t3.UsageClearanceSponsor) as ClearanceSponsor
	, t1.CertClearanceSponsor, t2.TechClearanceSponsor, t3.UsageClearanceSponsor

	, t1.CertIsSupervisor, t2.TechIsSupervisor, t3.UsageIsSupervisor

	, coalesce(t1.CertRivaCareerLevel, t2.TechRivaCareerLevel, t3.UsageRivaCareerLevel) as CareerLevel
	, t1.CertRivaCareerLevel, t2.TechRivaCareerLevel, t3.UsageRivaCareerLevel
	
	, coalesce(t1.CertRivaPath, t2.TechRivaPath, t3.UsageRivaPath) as [Path]
	, t1.CertRivaPath, t2.TechRivaPath, t3.UsageRivaPath

	, coalesce(t1.CertSupervisorName, t2.TechSupervisorName, t3.UsageSupervisorName) as SupervisorName
	, t1.CertSupervisorName, t2.TechSupervisorName, t3.UsageSupervisorName

	, t1.CertYearsOfExperience, t2.TechYearsOfExperience, t3.UsageYearsOfExperience
from
	cteCert as t1

	full join cteTech as t2 
		on t1.CertUserId = t2.TechUserId
		and t1.CertCvId = t2.TechCvId
		and t1.CertBusinessUnits = t2.TechBusinessUnits
		and t1.CertClearanceSponsor = t2.TechClearanceSponsor
		and t1.CertIsSupervisor = t2.TechIsSupervisor
		and t1.CertRivaCareerLevel = t2.TechRivaCareerLevel
		and t1.CertRivaPath = t2.TechRivaPath
		and t1.CertSupervisorName = t2.TechSupervisorName
		and t1.CertYearsOfExperience = t2.TechYearsOfExperience

	full join cteUsage as t3
		on t3.UsageUserId = isnull(t1.CertUserId, t2.TechUserId)
		and t3.UsageCvId = isnull(t1.CertCvId, t2.TechCvId)
		and t3.UsageBusinessUnits = isnull(t1.CertBusinessUnits, t2.TechBusinessUnits)
		and t3.UsageClearanceSponsor = isnull(t1.CertClearanceSponsor, t2.TechClearanceSponsor)
		and t3.UsageIsSupervisor = isnull(t1.CertIsSupervisor, t2.TechIsSupervisor)
		and t3.UsageRivaCareerLevel = isnull(t1.CertRivaCareerLevel, t2.TechRivaCareerLevel)
		and t3.UsageRivaPath = isnull(t1.CertRivaPath, t2.TechRivaPath)
		and t3.UsageSupervisorName = isnull(t1.CertSupervisorName, t2.TechSupervisorName)
		and t3.UsageYearsOfExperience = isnull(t1.CertYearsOfExperience, t2.TechYearsOfExperience)
;