
create view [cvp].[vw_RequiredFieldsByEmployee] as

select distinct
	--ROW_NUMBER() over(partition by unpvt.[CV Partner User ID] order by unpvt.[CV Partner User ID]) RowNum
	unpvt.[CV Partner User ID] as CvPartnerUserId
	, unpvt.[CV Partner CV ID] as CvPartnerCvId
	, unpvt.FieldName
	, (case when FieldValue in ('N/A', '0', NULL) or len(trim(FieldValue)) = 0 then null 
		else FieldValue 
	end) as FieldValue
	, fld.IsRequired
	, (case 
		when unpvt.FieldName = 'Custom tag: Business Units' and unpvt.FieldValue = 'CORPORATE' then 1 
		else 0 
	end) as IsCorporateEmployee
from (
	select
		[CV Partner User ID]
		, [CV Partner CV ID]
		, isnull(convert(varchar(255), [Educations]), 'N/A') as [Educations]
		, isnull(convert(varchar(255), [Project Experiences]), 'N/A') as [Project Experiences]
		, isnull(convert(varchar(255), case when [Skill categories] <= 1 then 0 else [Skill categories] end), 'N/A') as [Skill categories]
		, isnull(convert(varchar(255), [Summary Of Qualifications]), 'N/A') as [Summary Of Qualifications]
		, isnull(convert(varchar(255), [Work experiences]), 'N/A') as [Work experiences]
		, isnull(convert(varchar(255), isnull(biz.BusinessUnitAlias, [Custom tag: Business Units])), 'N/A') as [Custom tag: Business Units]
		, isnull(convert(varchar(255), [Custom tag: Clearance/Sponsor]), 'N/A') as [Custom tag: Clearance/Sponsor]
		, isnull(convert(varchar(255), [Custom tag: RIVA Career Level]), 'N/A') as [Custom tag: RIVA Career Level] 
		, isnull(convert(varchar(255), [Custom tag: RIVA Path ]), 'N/A') as [Custom tag: RIVA Path]
		, isnull(convert(varchar(255), [Custom tag: Supervisor (Y/N)]), 'N/A') as [Custom tag: Supervisor (Y/N)]
		, isnull(convert(varchar(255), [Custom tag: Supervisor name]), 'N/A') as [Custom tag: Supervisor name]
		, isnull(convert(varchar(255), [Custom tag: Years of Experience ]), 'N/A') as [Custom tag: Years of Experience]
		, isnull(convert(varchar(255), [Certifications]), 'N/A') as [Certifications]
		, isnull(convert(varchar(255), [Courses]), 'N/A') as [Courses]
		, isnull(convert(varchar(255), [Highlighted roles]), 'N/A') as [Highlighted roles]
		, isnull(convert(varchar(255), [Honors and awards]), 'N/A') as [Honors and awards]
		, isnull(convert(varchar(255), [Languages]), 'N/A') as [Languages]
		, isnull(convert(varchar(255), [Positions]), 'N/A') as [Positions]
		, isnull(convert(varchar(255), [Presentations]), 'N/A') as [Presentations]
		, isnull(convert(varchar(255), [Publications]), 'N/A') as [Publications]
		, isnull(convert(varchar(255), [Unique roles]), 'N/A') as [Unique roles]
		, isnull(convert(varchar(255), [Years of education]), 'N/A') as [Years of education]
	from 
		cvp_load.CvPartnerUsageReport as t
		left join cvp.BusinessUnit as biz on t.[Custom tag: Business Units] = biz.BusinessUnitName
) as t1
unpivot(FieldValue for FieldName in (
	[Educations]
	, [Project Experiences]
	, [Skill categories]
	, [Summary Of Qualifications]
	, [Work experiences]
	, [Custom tag: Business Units]
	, [Custom tag: Clearance/Sponsor]
	, [Custom tag: RIVA Career Level]
	, [Custom tag: RIVA Path]
	, [Custom tag: Supervisor (Y/N)]
	, [Custom tag: Supervisor name]
	, [Custom tag: Years of Experience]
	, [Certifications]
	, [Courses]
	, [Highlighted roles]
	, [Honors and awards]
	, [Languages]
	, [Positions]
	, [Presentations]
	, [Publications]
	, [Unique roles]
	, [Years of education]
)) as unpvt
left join cvp.Field as fld on fld.FieldName = unpvt.FieldName
--where unpvt.FieldName = 'Custom tag: Business Units'
--order by unpvt.[CV Partner User ID]
;
GO


