
create view [cvp].[vw_Dashboard] as

with field_ct as (
	select 
		count(0) TotalFieldCount
		, sum(cast(IsRequired as int)) as RequiredFieldCount
		, sum(cast(IsBeneficial as int)) as BeneficialFieldCount
	from cvp.Field
)

, cte_completed_counts as (
	select 
		CvPartnerCvId
		, sum(case when IsRequired = 1 and FieldValue is not null then 1 else 0 end) as RequiredFilledCount
		, sum(case when IsRequired = 0 and FieldValue is not null then 1 else 0 end) as BeneficialFilledCount
		, field_ct.RequiredFieldCount
		, field_ct.RequiredFieldCount-1 as CorpRequiredFieldCount
		, field_ct.BeneficialFieldCount
		, field_ct.TotalFieldCount
		, sum(IsCorporateEmployee) as IsCorporateEmployee
	from
		cvp.vw_RequiredFieldsByEmployee
		full join field_ct on 1=1
	group by
		CvPartnerCvId
		, field_ct.RequiredFieldCount
		, field_ct.BeneficialFieldCount
		, field_ct.TotalFieldCount
)
--select * from cte_completed_counts

, cte_compliant as (
	select 
		CvPartnerCvId
		, RequiredFilledCount
		, (RequiredFilledCount + BeneficialFilledCount) as TotalFilledCount
		, convert(decimal(5,2), (case IsCorporateEmployee when 0 then 11 else 10 end)) as NumFieldsRequired
		, TotalFieldCount
		, (case 
			when (IsCorporateEmployee = 0 and RequiredFilledCount >= RequiredFieldCount) 
				or (IsCorporateEmployee = 1 and RequiredFilledCount >= CorpRequiredFieldCount) then 1
			else 0
		end) as IsCompliant
	from 
		cte_completed_counts
)
--select * from cte_compliant where CvPartnerCvId = '62163e72082d2a11479d6c0b'

, cte_perc_complete as (
	select 
		CvPartnerCvId
		, RequiredFilledCount
		, TotalFilledCount
		, NumFieldsRequired
		, TotalFieldCount
		, (case 
			when (RequiredFilledCount/NumFieldsRequired) > 1.0 then 1.0 
			else RequiredFilledCount / NumFieldsRequired 
		end) as PercentFilled
		, (case when IsCompliant = 1 then 'Y' else 'N' end) as IsCompliantYN
	from 
		cte_compliant
)
--select * from cte_perc_complete where CvPartnerCvId = '62163e72082d2a11479d6c0b'

, cte_certs as (
	select
		crt.[CV Partner CV ID]
		, crt.[Month]
		, crt.[Year]
		, crt.[Month expire]
		, crt.[Year expire]
		, crt.[Name (int)] as [Certification]
		, crt.[Organiser (int)] as [Cert Organizer]
		, crt.[Long description (int)]
		, crt.[Custom tag: RIVA Career Level] as [Custom tag: RIVA Career Level-1]
		, crt.[Custom tag: Years of Experience ] as [Custom tag: Years of Experience -1]
		, crt.[Custom tag: Supervisor name] as [Custom tag: Supervisor name-1]
		, crt.[Custom tag: Supervisor (Y/N)] as [Custom tag: Supervisor (Y/N)-1]
		, crt.[Custom tag: RIVA Path ] as [Custom tag: RIVA Path -1]
		, crt.[Custom tag: Business Units] as [Custom tag: Business Units-1]
		, crt.[Custom tag: Clearance/Sponsor] as [Custom tag: Clearance/Sponsor-1]
	from
		cvp_load.CvPartnerCertifications as crt
	group by
		crt.[CV Partner CV ID]
		, crt.[Month]
		, crt.[Year]
		, crt.[Month expire]
		, crt.[Year expire]
		, crt.[Name (int)]
		, crt.[Organiser (int)]
		, crt.[Long description (int)]
		, crt.[Custom tag: RIVA Career Level]
		, crt.[Custom tag: Years of Experience ]
		, crt.[Custom tag: Supervisor name]
		, crt.[Custom tag: Supervisor (Y/N)]
		, crt.[Custom tag: RIVA Path ]
		, crt.[Custom tag: Business Units]
		, crt.[Custom tag: Clearance/Sponsor]
)
--select * from cte_certs

, cte_tech as (
	select
		tech.[CV Partner CV ID]
		, tech.[Skill name (int)]
		, tech.[Category (int)]
		, tech.[Custom tag: RIVA Career Level]
		, tech.[Custom tag: Years of Experience ]
		, tech.[Custom tag: Supervisor name]
		, tech.[Custom tag: Supervisor (Y/N)]
		, tech.[Custom tag: RIVA Path ]
		, tech.[Custom tag: Business Units]
		, tech.[Custom tag: Clearance/Sponsor]
		, tech.[Year experience]
		, tech.[Proficiency (0-5)]
	from
		cvp_load.CvPartnerTechnologies as tech
	group by
		tech.[CV Partner CV ID]
		, tech.[Skill name (int)]
		, tech.[Category (int)]
		, tech.[Custom tag: RIVA Career Level]
		, tech.[Custom tag: Years of Experience ]
		, tech.[Custom tag: Supervisor name]
		, tech.[Custom tag: Supervisor (Y/N)]
		, tech.[Custom tag: RIVA Path ]
		, tech.[Custom tag: Business Units]
		, tech.[Custom tag: Clearance/Sponsor]
		, tech.[Year experience]
		, tech.[Proficiency (0-5)]
)
--select * from cte_tech

, cte_skills as (
	select 
		tech.[CV Partner CV ID] as CvPartnerCvId
		, tech.[Skill name (int)] as SkillName
	from 
		cvp_load.CvPartnerTechnologies as tech
	where
		len(isnull(tech.[Skill name (int)], '')) > 0
	group by
		tech.[CV Partner CV ID]
		, tech.[Skill name (int)]
)

, cte_update_log as (
	select top 1 cast(DataRefreshDate as date) as DataRefreshDate 
	from cvp.UpdateLog 
	order by DataRefreshDate desc
)

--select * from cte_skills
--select * from cte_tech
--select * from cte_perc_complete
--select * from cte_completed_counts
--select count(0) from cte_update_log
--select count(0) from field_ct
--select count(0) from (

, cte_skills_count_by_cv as (
	select (case count(0) when 0 then null else count(0) end) as skill_count, CvPartnerCvId
	from cte_skills
	group by CvPartnerCvId
)

select
	cte_perc_complete.IsCompliantYN as [Compliant (Y/N)]

	-- Aggregates
	, cte_update_log.DataRefreshDate as [Data Refresh Date]
	, (select top 1 skill_count from cte_skills_count_by_cv where CvPartnerCvId = usage.[CV Partner CV ID]) as [Skills Count]
	, cte_perc_complete.TotalFieldCount as [Max Count of Fields]
	, cte_perc_complete.RequiredFilledCount as [Sum Filled by User & Req]
	, cte_perc_complete.PercentFilled as [Percent Filled]
	, cte_perc_complete.NumFieldsRequired as [Count of Fields by ID & Req]
	, cte_perc_complete.TotalFilledCount as [Total Filled Per User]
	, (case when cte_fields.FieldValue is not null then 1 else 0 end) as [FILLED]
	, cte_fields.FieldName as [CV Partner Sections]
	, (case cte_fields.FieldValue when '0' then null else cte_fields.FieldValue end) as [Section Values]
	, (case cte_fields.IsRequired when 1 then 'REQUIRED' else 'BENEFICIAL' end) as [REQUIRED]

	-- Employee
	, usage.[Name] as [Name]
	, usage.[Title (int)]
	, usage.[Email]
	, usage.[External User ID]
	, cte_fields.CvPartnerUserId as [CV Partner User ID-1]
	, cte_fields.CvPartnerCvId as [CV Partner CV ID]
	, usage.[Phone Number]

	-- Usages
	, usage.[Owner last removed or added a section]
	, usage.[Owner last updated CV]
	, usage.[Last updated CV]

	-- Skills/Technologies
	, usage.[Custom tag: RIVA Career Level]
	, usage.[Custom tag: Years of Experience ]
	, usage.[Custom tag: Supervisor name]
	, usage.[Custom tag: Supervisor (Y/N)]
	, usage.[Custom tag: RIVA Path ]
	, isnull(
		(select top 1 BusinessUnitAlias from cvp.BusinessUnit where BusinessUnitName = usage.[Custom tag: Business Units])
		, usage.[Custom tag: Business Units]
	) as [Custom tag: Business Units]
	, usage.[Custom tag: Clearance/Sponsor]
	, tech.[Skill name (int)] as [Int]
	, tech.[Year experience]
	, tech.[Proficiency (0-5)]
	, tech.[Category (int)] as [Primary Categories]

	-- Certifications
	, crt.[Month]
	, crt.[Year]
	, crt.[Month expire]
	, crt.[Year expire]
	, crt.[Certification]
	, crt.[Cert Organizer]
	, crt.[Long description (int)]
	--, crt.[Custom tag: RIVA Career Level-1]
	--, crt.[Custom tag: Years of Experience -1]
	--, crt.[Custom tag: Supervisor name-1]
	--, crt.[Custom tag: Supervisor (Y/N)-1]
	--, crt.[Custom tag: RIVA Path -1]
	--, (select top 1 BusinessUnitAlias from cvp.BusinessUnit where BusinessUnitName = crt.[Custom tag: Business Units-1]) as [Custom tag: Business Units-1]
	--, crt.[Custom tag: Clearance/Sponsor-1]

from 
	cvp_load.CvPartnerUsageReport as usage

	left join cte_tech as tech
		on usage.[CV Partner CV ID] = tech.[CV Partner CV ID]

	left join cte_certs as crt 
		on usage.[CV Partner CV ID] = crt.[CV Partner CV ID]
	
	left join cte_perc_complete
		on cte_perc_complete.CvPartnerCvId = usage.[CV Partner CV ID]

	left join cvp.vw_RequiredFieldsByEmployee as cte_fields 
		on cte_perc_complete.CvPartnerCvId = cte_fields.CvPartnerCvId

	full join cte_update_log on 1=1
--) as vw
group by
	cte_perc_complete.IsCompliantYN

	-- Aggregates
	, cte_update_log.DataRefreshDate
	, cte_perc_complete.TotalFieldCount
	, cte_perc_complete.RequiredFilledCount
	, cte_perc_complete.PercentFilled
	, cte_perc_complete.NumFieldsRequired
	, cte_perc_complete.TotalFilledCount
	, (case when cte_fields.FieldValue is not null then 1 else 0 end)
	, cte_fields.FieldName
	, (case cte_fields.FieldValue when '0' then null else cte_fields.FieldValue end)
	, (case cte_fields.IsRequired when 1 then 'REQUIRED' else 'BENEFICIAL' end)

	-- Employee
	, usage.[Name]
	, usage.[Title (int)]
	, usage.[Email]
	, usage.[External User ID]
	, cte_fields.CvPartnerUserId
	, cte_fields.CvPartnerCvId
	, usage.[Phone Number]
	, usage.[CV Partner CV ID]

	-- Usages
	, usage.[Owner last removed or added a section]
	, usage.[Owner last updated CV]
	, usage.[Last updated CV]

	-- Skills/Technologies
	, usage.[Custom tag: RIVA Career Level]
	, usage.[Custom tag: Years of Experience ]
	, usage.[Custom tag: Supervisor name]
	, usage.[Custom tag: Supervisor (Y/N)]
	, usage.[Custom tag: RIVA Path ]
	, usage.[Custom tag: Clearance/Sponsor]
	, usage.[Custom tag: Business Units]
	, tech.[Skill name (int)]
	, tech.[Year experience]
	, tech.[Proficiency (0-5)]
	, tech.[Category (int)]

	-- Certifications
	, crt.[Month]
	, crt.[Year]
	, crt.[Month expire]
	, crt.[Year expire]
	, crt.[Certification]
	, crt.[Cert Organizer]
	, crt.[Long description (int)]
	--, crt.[Custom tag: RIVA Career Level-1]
	--, crt.[Custom tag: Years of Experience -1]
	--, crt.[Custom tag: Supervisor name-1]
	--, crt.[Custom tag: Supervisor (Y/N)-1]
	--, crt.[Custom tag: RIVA Path -1]
	--, crt.[Custom tag: Clearance/Sponsor-1]
	--, crt.[Custom tag: Business Units-1]
--order by [CV Partner CV ID]
;

