create view cvp.vw_TableCounts as

select 'cvp.BusinessUnit' as TableName, count(0) as Ct from cvp.BusinessUnit
union all
select 'cvp.CareerLevel', count(0) from cvp.CareerLevel
union all
select 'cvp.Certification', count(0) from cvp.Certification
union all
select 'cvp.CvCertificationLu', count(0) from cvp.CvCertificationLu
union all
select 'cvp.ClearanceSponsor', count(0) from cvp.ClearanceSponsor
union all
select 'cvp.Cv', count(0) from cvp.Cv
union all
select 'cvp.CvSkillLu', count(0) from cvp.CvSkillLu
union all
select 'cvp.Employee', count(0) from cvp.Employee
union all
select 'cvp.Field', count(0) from cvp.Field
union all
select 'cvp.JobTitle', count(0) from cvp.JobTitle
union all
select 'cvp.JobTitleEmployeeLu', count(0) from cvp.JobTitleEmployeeLu
union all
select 'cvp.Path', count(0) from cvp.Path
union all
select 'cvp.Section', count(0) from cvp.Section
union all
select 'cvp.Skill', count(0) from cvp.Skill
union all
select 'cvp.SkillCategory', count(0) from cvp.SkillCategory
union all
select 'cvp.SkillCategoryLu', count(0) from cvp.SkillCategoryLu
union all
select 'cvp.Usage', count(0) from cvp.Usage
union all
select 'cvp_load.CvPartnerCertifications', count(0) from cvp_load.CvPartnerCertifications
union all
select 'cvp_load.CvPartnerTechnologies', count(0) from cvp_load.CvPartnerTechnologies
union all
select 'cvp_load.CvPartnerUsageReport', count(0) from cvp_load.CvPartnerUsageReport
;