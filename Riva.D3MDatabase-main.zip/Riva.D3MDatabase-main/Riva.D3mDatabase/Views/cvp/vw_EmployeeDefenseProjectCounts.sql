CREATE view cvp.vw_EmployeeDefenseProjectCounts as

with cte_emps as (
select
	emp.[Last Name] as Lastname
	, emp.[Preferred/First Name] as Firstname
	, case 
		when emp.[Employee Id] is not null 
			then concat('E00', emp.[Employee Id]) 
		else NULL 
	end as EmployeeId
	, n.Access
	, n.Eligibility
	, emp.[Employee Type] as EmpType
from 
	cvp_load.SecurityClearanceNames as n

	left join deltek.EmployeeList as emp
		on (emp.[Last Name] = n.Lastname)
		and (
			n.Firstname like '%'+emp.[Preferred/First Name]+'%' 
			or emp.[Preferred/First Name] like '%'+n.Firstname+'%'
			or n.Firstname = 'Robert' and emp.[Preferred/First Name] in ('Bobby', 'Bob')
			or n.Firstname = 'Ricky' and emp.[Preferred/First Name] in ('Richard', 'Rich', 'Rick')
			or n.Firstname = 'Douglas' and emp.[Preferred/First Name] in ('Doug')
			or n.Firstname = 'Joseph' and emp.[Preferred/First Name] in ('Joe')
			or n.Firstname = 'Anthony' and emp.[Preferred/First Name] in ('Tony')
			or n.Firstname = 'Ezekiel' and emp.[Preferred/First Name] in ('Zeke')
			or n.Firstname = 'Kristina' and emp.[Preferred/First Name] in ('Krissi', 'Kris')
			or n.Firstname = 'Michael' and emp.[Preferred/First Name] in ('Mike')
			or n.Firstname = 'David' and emp.[Preferred/First Name] in ('Dave')
			or n.Firstname = 'Charles' and emp.[Preferred/First Name] in ('Charlie')
		)
 --where emp.[Employee Id] is null
)

, cte_util as (
	select u.[Employee ID], u.[Project ID] from deltek.Utilization as u group by u.[Employee ID], u.[Project ID]
)

, cte_defense as (
	select p.[Project ID], p.[Project Name] 
	from deltek.ProjectList as p
	where 
		p.[Project Name] like '%Army%'
		or p.[Project Name] like '%Navy%'
		or p.[Project Name] like '%USAF%'
		or p.[Project Name] like '%USMC%'
		or p.[Project Name] like '%Coastguard%'
		or p.[Project Name] like '%NavyAir%'
		or p.[Project Name] like '%Defense%'
		or p.[Project Name] like '%DHS%'
		or p.[Project Name] like '%Homeland%'
		or p.[Project Name] like '%Home land%'
		or p.[Project Name] like 'DOD%'
	group by p.[Project ID], p.[Project Name]  
)

, cte_dod as (
select distinct
	emp.EmployeeId
	, emp.Firstname
	, emp.Lastname
	, emp.Access
	, emp.Eligibility
	, EmpType
	, p.[Project ID]
	, p.[Project Name]
from
	cte_emps as emp
	inner join cte_util as u on emp.EmployeeId = u.[Employee ID]
	inner join cte_defense as p on u.[Project ID] = p.[Project ID]
)

select
	EmployeeId
	, Firstname
	, Lastname
	, concat(Firstname, ' ', Lastname) as Fullname
	, Access
	, Eligibility
	, EmpType as EmployeeType
	, it.Asset_Type
	, d.[Project Name]
from 
	cte_dod as d
	left join dbo.IT_asset_management_list as it
		on concat(Firstname, ' ', Lastname) = it.Assigned_To 
;
GO


