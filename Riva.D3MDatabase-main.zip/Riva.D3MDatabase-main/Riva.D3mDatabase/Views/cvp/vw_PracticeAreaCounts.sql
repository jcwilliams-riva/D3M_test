create view cvp.vw_PracticeAreaCounts as

with cte_practice as (
	select 
		Practice
		, sum(NumEmployees) as NumEmployees
	from 
		cvp.vw_EmployeeCountsBySubpractice
	group by
		Practice
)

, cte_pp_practice as (
	select sum(PastPerfCount) as PastPerfCount, Practice
	from dbo.vw_PastPerformanceCounts
	group by Practice
)

select 
	s.Practice as [Pratice Area]
	, isnull(pp.PastPerfCount, 0) as [# of PP by PA]
	, isnull(p.NumEmployees, 0) as [# of People by PA]
	, isnull(opps.OpportunityCount, 0) as [# of Future Opps by PA]
	, s.Subpractice as [Sub Pracitce Area]
	, isnull(pp2.PastPerfCount, 0) as [# of PP by Sub PA]
	, isnull(s.NumEmployees, 0) as [# of People by Sub PA]
	--, '' as [# of Future Opps by Sub PA]
from 
	cvp.vw_EmployeeCountsBySubpractice as s

	inner join cte_practice as p on s.Practice = p.Practice

	left join dbo.vw_FutureOpportunityCounts as opps 
		on p.Practice = opps.FunctionalArea

	left join cte_pp_practice as pp
		on pp.Practice = p.Practice

	left join dbo.vw_PastPerformanceCounts as pp2
		on s.Subpractice = pp2.Subpractice and p.Practice = pp2.Practice
where
	s.Subpractice != 'Uncategorized'
--order by s.Practice, s.Subpractice
;