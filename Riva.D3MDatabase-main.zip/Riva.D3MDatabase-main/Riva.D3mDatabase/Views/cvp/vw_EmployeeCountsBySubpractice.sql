
create view [cvp].[vw_EmployeeCountsBySubpractice] as

select 
	count(distinct CvUserId) as NumEmployees
	, Practice
	, Subpractice
from (
	select 
		[CV Partner User ID] as CvUserId
		, case 
			when ([Category (int)] like 'data %' or [Category (int)] = 'Business Intelligence (BI)') 
				then 'Data & Analytics'
			when [Category (int)] in ('Web Services', 'Web Development and Maintenance', 'Enterprise Architecture') 
				then 'Application Services'
			when [Category (int)] in ('Cloud', 'Code Compliance') 
				then 'Cloud & Infrastructure'
			when [Category (int)] = 'Human Centered Design'
				then 'Human Centered Design'
			when [Category (int)] = 'Cybersecurity'
				then 'Cybersecurity'
			when [Category (int)] = 'Systems Engineering'
				then 'Digital Platforms'
			else 'Other'
		end as Practice
		, [Category (int)] as Subpractice
	from 
		cvp_load.CvPartnerTechnologies
) as t
where Practice != 'Other'
group by
	Practice
	, Subpractice
;
GO