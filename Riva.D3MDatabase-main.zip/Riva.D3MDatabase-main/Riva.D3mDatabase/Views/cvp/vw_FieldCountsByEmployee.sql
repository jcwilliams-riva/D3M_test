create view cvp.vw_FieldCountsByEmployee as

select
	emp.EmployeeId as InternalEmployeeId
	, cv.CvId as InternalCvId
	, unpvt.[CV Partner User ID] as CvPartnerUserId
	, unpvt.[CV Partner CV ID] as CvPartnerCvId
	, unpvt.FieldName
	, cast(unpvt.FieldCount as int) as FieldCount
	, cast(fld.IsRequired as int) as IsRequired
	, (case 
		when (fld.IsRequired = 1 and unpvt.FieldCount > 0) 
			or (fld.IsRequired = 0) then 1
		else 0 
	end) as IsCompliant
from (
	select
		[CV Partner User ID]
		, [CV Partner CV ID]
		, sum(Educations) as Educations
		, sum([Project Experiences]) as [Project Experiences]
		, sum(case when [Skill categories] <= 1 then 0 else [Skill categories] end) as [Skill categories]
		, sum([Summary Of Qualifications]) as [Summary Of Qualifications]
		, sum([Work experiences]) as [Work experiences]
		
		, sum(case 
			when [Custom tag: Business Units] is null then 0
			else 1
		end) as [Custom tag: Business Units]

		, sum(case 
			when [Custom tag: Clearance/Sponsor] is null then 0
			else 1
		end) as [Custom tag: Clearance/Sponsor]

		, sum(case 
			when [Custom tag: RIVA Career Level] is null then 0
			else 1
		end) as [Custom tag: RIVA Career Level] 

		, sum(case 
			when [Custom tag: RIVA Path ] is null then 0
			else 1
		end) as [Custom tag: RIVA Path] 

		, sum(case 
			when [Custom tag: Supervisor (Y/N)] is null then 0
			else 1
		end) as [Custom tag: Supervisor (Y/N)]

		, sum(case 
			when [Custom tag: Supervisor name] is null then 0
			else 1
		end) as [Custom tag: Supervisor name]

		, sum(case 
			when [Custom tag: Years of Experience ] is null then 0
			else 1
		end) as [Custom tag: Years of Experience]

		, sum(Certifications) as [Certifications]
		, sum(Courses) as [Courses]
		, sum([Highlighted roles]) as [Highlighted roles]
		, sum([Honors and awards]) as [Honors and awards]
		, sum([Languages]) as [Languages]
		, sum([Positions]) as [Positions]
		, sum([Presentations]) as [Presentations]
		, sum([Publications]) as [Publications]
		, sum([Unique roles]) as [Unique roles]
		, sum([Years of education]) as [Years of education]
	from 
		cvp_load.CvPartnerUsageReport as t
	group by
		[CV Partner User ID]
		, [CV Partner CV ID]
) as t1
unpivot(FieldCount for FieldName in (
	[Educations]
	, [Project Experiences]
	, [Skill categories]
	, [Summary Of Qualifications]
	, [Work experiences]
	, [Custom tag: Business Units]
	, [Custom tag: Clearance/Sponsor]
	, [Custom tag: RIVA Career Level]
	, [Custom tag: RIVA Path]
	, [Custom tag: Supervisor (Y/N)]
	, [Custom tag: Supervisor name]
	, [Custom tag: Years of Experience]
	, [Certifications]
	, [Courses]
	, [Highlighted roles]
	, [Honors and awards]
	, [Languages]
	, [Positions]
	, [Presentations]
	, [Publications]
	, [Unique roles]
	, [Years of education]
)) as unpvt
left join cvp.Employee as emp on unpvt.[CV Partner User ID] = emp.ExternalUserId
left join cvp.Field as fld on fld.FieldName = unpvt.FieldName
left join cvp.Cv as cv on cv.EmployeeId = emp.EmployeeId
;