create view [util].[vw_WorkableHoursByMonth] as

-- select * from dbo.vw_WorkableHoursByMonth order by TheYear, TheMonth

select
	TheYear
	, TheMonth
	, TheMonthName
	, count(0) * 8 as WorkableHours
	, count(0) as WorkableDays
from 
	util.vw_Calendar
where 
	IsHoliday = 0
	and IsWeekend = 0
group by 
	TheYear, TheMonthName, TheMonth;
GO


