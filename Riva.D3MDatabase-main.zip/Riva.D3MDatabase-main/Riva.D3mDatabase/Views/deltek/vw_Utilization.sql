CREATE view deltek.vw_Utilization as

with cte_emp_levels as (
	select [Employee Id], [Riva Level Util], [Position Name], [Position Code], BU
	from (
		select
			(case
				when e.[Position Code] like '% VII%' then 0.25
				when e.[Position Code] like '% VI%' then 0.5
				when e.[Position Code] like '% IV%' then 0.83
				when e.[Position Code] like '% V%' then 0.75
				when e.[Position Code] like '% III%' then 0.85
				when e.[Position Code] like '% II%' then 0.93
				when e.[Position Code] like '% I%' then 0.95
				else 1.0
			end) as [Riva Level Util]
			, value as [Position Name]
			, e.[Employee Id]
			, e.[Position Code]
			, (case 
				when e.[Position Code] like 'CORP%' or e.[Position Code] = 'X' then 'CORP'
				when e.[Position Code] like 'CIV%' then 'FEDCIV'
				when e.[Position Code] like 'DOD%' then 'DOD/NS'
				when e.[Position Code] like 'HEA%' then 'FEDHEALTH'
			end) as BU
		from 
			deltek.EmployeeList as e
			cross apply string_split(e.[Position Code], ' ')
	) as t
	group by [Employee Id], [Riva Level Util], [Position Name], [Position Code], BU
)

, cte_emp_position_names as (
	select [Employee Id], [Position Name]
	from cte_emp_levels as t 
	where t.[Position Name] not in ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII')
	group by [Employee Id], [Position Name]
)

, cte_emp_position_levels as (
	select t.[Employee Id], t.[Position Code], [Position Name] as [Position Level], [Riva Level Util], BU
	from cte_emp_levels as t
	where t.[Position Name] in ('I', 'II', 'III', 'IV', 'V', 'VI', 'VII')
    group by t.[Employee Id], t.[Position Code], [Position Name], [Riva Level Util], BU
	
)

, cte_emp as (
    select
        e.[Employee Id]
        , e.[Cost Cent Description]
        , e.[Current Work Email]
        , e.[Preferred/First Name]
        , concat('E00', e.[Employee Id]) as DeltekId
        , e.[Position Code]
        , null as [Position Name]
        , concat(e.[Preferred/First Name], ' ', e.[Last Name]) as [Employee Name]
        , e.[Employee Type]
        , e.[Hire Date]
        , e.[Termination Date]
        , lvl.[Riva Level Util]
        , lvl.[Position Level]
        , lvl.BU
        , lvl.[Position Level] as [RIVA Level]
    from 
        deltek.EmployeeList as e

        left join cte_emp_position_levels as lvl 
            on e.[Employee Id] = lvl.[Employee Id]

        left join cte_emp_position_names as pnames 
            on e.[Employee Id] = pnames.[Employee Id]
    group by
        e.[Employee Id]
        , e.[Cost Cent Description]
        , e.[Current Work Email]
        , e.[Preferred/First Name]
        , concat('E00', e.[Employee Id])
        , e.[Position Code]
        , concat(e.[Preferred/First Name], ' ', e.[Last Name])
        , e.[Employee Type]
        , e.[Hire Date]
        , e.[Termination Date]
        , lvl.[Riva Level Util]
        , lvl.[Position Level]
        , lvl.BU
        , lvl.[Position Level]
)

, cte_proj_name_code as (
    select ProjectId, ProjectNameCode from (
        select
            [Project ID] as ProjectId
            , (case 
                when [Project ID] like '%.%' then SUBSTRING([Project ID], 0, CHARINDEX('.', [Project ID])) 
                else [Project ID] 
            end) as ProjectNameCode
        from
            deltek.ProjectList
    ) as t
    group by ProjectId, ProjectNameCode
)

, cte_billable as (
    select ProjectId, Billable from (
        select
            ProjectId
            , (case 
                when ProjectNameCode like '%FRINGE' then 'NON-BILLABLE - FRINGE'
                when ProjectNameCode in ('GENADM', 'NON-BILLABLE - G&A', 'BNPADM') then 'NON-BILLABLE - G&A'
                when ProjectNameCode in ('NON-BILLABLE - O/H', 'NON-BILLABLE O/H', 'KARMA1', 'MATHND', 'OVHEAD', 'SVCNTR') 
                    or ProjectNameCode like 'BNPOST%'
                    then 'NON-BILLABLE - O/H'
                else 'BILLABLE'
            end) as Billable
        from cte_proj_name_code
    ) as t
    group by ProjectId, Billable
)

, cte_proj as (
	select
		[Project ID] as ProjectId
        , c.ProjectNameCode
        , [Project Name] as ProjectName
        , [Project Start Date] as ProjectStartDate
        , [Project End Date] as ProjectEndDate
        , [Total Funded] as TotalFunded
        , [Cost Funded] as CostFunded
        , [Fee Funded] as FeeFunded
        , [Project Value Cost] as ProjectValueCost
        , [Project Value Fee] as ProjectValueFee
        , [Project Type Desc] as ProjectTypeDesc
        , [Project Classification] as ProjectClassification
        , b.Billable
	from 
        deltek.ProjectList as p
        inner join cte_proj_name_code as c on p.[Project ID] = c.ProjectId
        inner join cte_billable as b on p.[Project ID] = b.ProjectId
)

, cte_emp_hours as (
	select
		replace(u.[Employee ID], 'E00', '') as EmployeeId
		, p.Billable
		, datepart(year, [Hours Date]) as [Year]
		, datepart(month, [Hours Date]) as [Month]
		, w.WorkableHours
		, sum(u.[Entered Hours]) as TotalHoursWorked
	from
		deltek.Utilization as u

		left join cte_proj as p
			on u.[Project ID] = p.ProjectId

		left join util.vw_WorkableHoursByMonth as w
			on datepart(year, [Hours Date]) = w.[TheYear]
				and datepart(month, [Hours Date]) = w.TheMonth
    where 
        u.[Project ID] not like '%FRINGE%'
    group by
        replace(u.[Employee ID], 'E00', '')
		, p.Billable
		, datepart(year, [Hours Date])
		, datepart(month, [Hours Date])
        , w.WorkableHours
)

, cte_emp_total_hours_month as (
	select EmployeeId, [Year], [Month], WorkableHours
    , sum(TotalHoursWorked) as TotalHoursWorked
    , concat('E00', EmployeeId) as DeltekId 
	from cte_emp_hours
	group by EmployeeId, [Year], [Month], WorkableHours
)

, cte_emp_billable_hours_month as (
	select EmployeeId, [Year], [Month], WorkableHours
    , sum(TotalHoursWorked) as TotalBillableHours
    , concat('E00', EmployeeId) as DeltekId 
	from cte_emp_hours 
	where Billable = 'BILLABLE'
	group by EmployeeId, [Year], [Month], WorkableHours
)

-- Fringe / Hourse Entered
, cte_emp_fringe as (
	select DeltekId, [Year], [Month], TotalFringeHours, TotalHoursEntered, PercFringe
	from (
        select
            u.[Employee ID] as DeltekId
            , datepart(year, [Hours Date]) as [Year]
            , datepart(month, [Hours Date]) as [Month]
            , sum([Entered Hours]) as TotalFringeHours
            , hrs.TotalHoursWorked as TotalHoursEntered
            , convert(decimal(5,2), case 
                when hrs.TotalHoursWorked > 0 
                    then sum([Entered Hours]) / convert(real, hrs.TotalHoursWorked)
                else 0.00
            end) as PercFringe
        from 
            deltek.Utilization as u
            
            left join cte_emp_total_hours_month as hrs 
                on u.[Employee ID] = hrs.DeltekId
                    and datepart(year, [Hours Date]) = hrs.[Year]
                    and datepart(month, [Hours Date]) = hrs.[Month]
        where 
            [Project ID] like '%FRINGE%'
        group by
            u.[Employee ID]
            , datepart(year, [Hours Date])
            , datepart(month, [Hours Date])
            , hrs.TotalHoursWorked
    ) as t
)

, cte_emp_util as (
    select
        tot.EmployeeId
        , tot.[Year]
        , tot.[Month]
        , tot.WorkableHours
        , tot.TotalHoursWorked
        , bill.TotalBillableHours
        , TotalHoursWorked / tot.WorkableHours as PercWorkedHours
        , (case 
            when TotalHoursWorked < tot.WorkableHours and isnull(TotalHoursWorked,0) > 0 then TotalBillableHours / TotalHoursWorked 
            else isnull(TotalBillableHours, 0) / tot.WorkableHours
        end) as BillablePercAccountsPayable
    from 
        cte_emp_total_hours_month as tot

        left join cte_emp_billable_hours_month as bill
            on tot.EmployeeId = bill.EmployeeId
                and tot.[Year] = bill.[Year] 
                and tot.[Month] = bill.[Month]
)

, cte_emp_utilization as (
    select
        EmployeeId, DeltekId, [Year], [Month], WorkableHours, TotalHoursWorked, TotalBillableHours
        , PercWorkedHours, BillablePercAccountsPayable, Meets85PercUtilLvl, MeetsWorkHours
        , AvgBillablePercAccountsPayable    
        , (case 
            when AvgBillablePercAccountsPayable is null then 'NO BILLABLE TIME ENTERED'
            when round(AvgBillablePercAccountsPayable, 2) = 0.00 then 'NO BILLABLE EXPECTATION'
            when round(AvgBillablePercAccountsPayable, 2) < 0.85 then 'BELOW'
            when round(AvgBillablePercAccountsPayable, 2) = 0.85 then 'MEETS'
            when round(AvgBillablePercAccountsPayable, 2) > 0.85 and round(AvgBillablePercAccountsPayable, 2) <= 1 then 'EXCEEDS W/IN EXPECTATION'
            else 'EXCEEDS BEYOND EXPECTATION'
        end) as [Meets 85% Util Lvl (Proj)]
    from (
        select
            EmployeeId
            , concat('E00', EmployeeId) as DeltekId
            , [Year]
            , [Month]
            , WorkableHours
            , TotalHoursWorked
            , TotalBillableHours
            , PercWorkedHours
            , BillablePercAccountsPayable
            , AVG(BillablePercAccountsPayable) over(partition by EmployeeId) as AvgBillablePercAccountsPayable
            , (case
                when BillablePercAccountsPayable is null then 'NO BILLABLE TIME ENTERED'
                when round(BillablePercAccountsPayable, 2) = 0.00 then 'NO BILLABLE EXPECTATION'
                when round(BillablePercAccountsPayable, 2) < 0.85 then 'BELOW'
                when round(BillablePercAccountsPayable, 2) = 0.85 then 'MEETS'
                when round(BillablePercAccountsPayable, 2) > 0.85 and round(BillablePercAccountsPayable, 2) <= 1.0 then 'EXCEEDS W/IN EXPECTATION'
                else 'EXCEEDS BEYOND EXPECTATION'
            end) as Meets85PercUtilLvl
            , (case
                when PercWorkedHours is null then 'NO BILLABLE TIME ENTERED'
                when round(PercWorkedHours, 2) = 0.0 then 'NO BILLABLE EXPECTATION'
                when round(PercWorkedHours, 2) < 1.0 then 'BELOW'
                when round(PercWorkedHours, 2) = 1.0 then 'MEETS'
                else 'EXCEEDS EXPECTATION'
            end) as MeetsWorkHours
        from 
            cte_emp_util
    ) as t
)

/*
[Billable % A/P 40 hrs] = 
    IF [Total Hrs Worked Per Mo] < [Workable Hour Per Month]
        THEN [Total Billable Hours Per Mo] / [Total Hrs Worked Per Mo]
    ELSE [Total Billable Hours Per Mo] / [Workable Hour Per Month]

[% worked hrs / 40 hrs by Mon] = [Total Hrs Worked Per Mo] / [Workable Hour Per Month]

--
[Meets Work Hours] = 
    IF ISNULL([% worked hrs / 40 hrs by Mon]) = TRUE THEN 'NO BILLABLE TIME ENTERED'
    ELSEIF [% worked hrs / 40 hrs by Mon] = 0 THEN 'NO BILLABLE EXPECTATION'
    ELSEIF [% worked hrs / 40 hrs by Mon] < 1 THEN 'BELOW'
    ELSEIF [% worked hrs / 40 hrs by Mon] = 1 THEN 'MEETS'
    ELSE 'EXCEEDS EXPECTATION' END
--

[Meets 85% Util Lvl] = 
    IF ISNULL([Billable % A/P 40 hrs]) = TRUE THEN 'NO BILLABLE TIME ENTERED'
    ELSEIF [Billable % A/P 40 hrs] = 0 THEN 'NO BILLABLE EXPECTATION'
    ELSEIF [Billable % A/P 40 hrs] < 0.85 THEN 'BELOW'
    ELSEIF [Billable % A/P 40 hrs] = 0.85 THEN 'MEETS'
    ELSEIF [Billable % A/P 40 hrs] > 0.85 AND [Billable % A/P 40 hrs] <= 1 THEN 'EXCEEDS W/IN EXPECTATION'
    ELSE 'EXCEEDS BEYOND EXPECTATION' END
--

[Billable % A/P 40 hrs (Proj)] = AVG([Billable % A/P 40 hrs])
--
[Meets 85% Util Lvl (Proj)] = 
    IF ISNULL([Billable % A/P 40 hrs (Proj)]) = TRUE THEN 'NO BILLABLE TIME ENTERED'
    ELSEIF [Billable % A/P 40 hrs (Proj)] = 0 THEN 'NO BILLABLE EXPECTATION'
    ELSEIF [Billable % A/P 40 hrs (Proj)]) < 0.85 THEN 'BELOW'
    ELSEIF [Billable % A/P 40 hrs (Proj)] = 0.85 THEN 'MEETS'
    ELSEIF [Billable % A/P 40 hrs (Proj)] > 0.85 AND [Billable % A/P 40 hrs (Proj)] <= 1 THEN 'EXCEEDS W/IN EXPECTATION'
    ELSE 'EXCEEDS BEYOND EXPECTATION' END
*/
, cte_final as (
-- "Clean 25" in Tableau Prep
    select distinct
        SUBSTRING(u.[Project ID], 1, 6) as [Project Name Code]
        , u.[Employee ID] as [Employee ID (DLTK)]
        , u.[Year]
        , datepart(month, [Hours Date]) as [Month]
        , u.[Period Number]
        , u.[Status]
        , u.[Project ID]
        , u.[Pay Type]
        , u.[Hours Date]
        , u.[Entered Hours]
        -- Projects
        , p.ProjectName as [Project Name]
        , p.ProjectTypeDesc as [Project Type Desc]
        , p.ProjectClassification as [Project Classification]
        , p.ProjectStartDate as [Project Start Date]
        , p.ProjectEndDate as [Project End Date]
        , p.TotalFunded as [Total Funded]
        , p.CostFunded as [Cost Funded]
        , p.FeeFunded as [Fee Funded]
        , p.ProjectValueCost as [Project Value Cost]
        , p.ProjectValueFee as [Project Value Fee]
        , p.Billable
        , parent.[Project ID] as [Project ID (6-Digit)]
        , (case
            when parent.[Project ID] is null 
                or parent.[Project ID] like 'GENADM%'
                or parent.[Project ID] like 'BNPADM%'
                or parent.[Project ID] like 'SVCCNTR%'
                or parent.[Project ID] like 'OVHEAD%'
                or parent.[Project ID] like 'KARMA%'
                then 'CORP'
            when parent.[Project ID] like 'CIV%' 
                or parent.[Project ID] like 'USDA%' 
                or parent.[Project ID] like 'NOAA%'
                or parent.[Project ID] like 'DOL%'
                or parent.[Project ID] like 'DOI%'
                or parent.[Project ID] like 'DOED%'
                or parent.[Project ID] like 'RIV%'
                or parent.[Project ID] like 'SMR%'
                or parent.[Project ID] like 'TIINC%'
                or parent.[Project ID] like 'UITC%'
                or parent.[Project ID] like 'PAE%'
                or parent.[Project ID] like 'PTO%'
                or parent.[Project ID] like 'CAC%'
                or parent.[Project ID] like 'FAA%'
                or parent.[Project ID] like 'FTC%'
                or parent.[Project ID] like 'GSA%'
                or parent.[Project ID] like 'NRC%'
                or parent.[Project ID] like 'NSF%' 
                or parent.[Project ID] like 'PSC%'
                or parent.[Project ID] like 'RIGIL%'
                or parent.[Project ID] like 'PERS%'
                then 'FEDCIV'
            when parent.[Project ID] like 'DOD%' 
                or parent.[Project ID] like 'USAF%' 
                or parent.[Project ID] like 'VLNT%'
                or parent.[Project ID] like 'ARMY%'
                or parent.[Project ID] like 'CBP%'
                or parent.[Project ID] like 'NGB%'
                or parent.[Project ID] like 'OMC%'
                or parent.[Project ID] like 'NAV%'
                or parent.[Project ID] like 'NSWC%'
                or parent.[Project ID] like 'KAD%'
                then 'DOD/NS'
            when parent.[Project ID] like 'HEA%' 
                or parent.[Project ID] like 'NIH%'
                or parent.[Project ID] like 'AHRQ%'
                or parent.[Project ID] like 'FMP%'
                or parent.[Project ID] like 'HHS%'
                or parent.[Project ID] like 'PERA%'
                then 'FEDHEALTH'
            else 
                substring(parent.[Project ID], 1, 6)
        end) as [Project BU]
        , parent.[Project Name] as [Project Name (6-Digit)]
        , parent.[Project Type Desc] as [Project Type Desc (6-Digit)]
        , parent.[Project Classification] as [Project Classification (6-Digit)]
        , parent.[Project Start Date] as [Project Start Date (6-Digit)]
        , parent.[Project End Date] as [Project End Date (6-Digit)]
        , parent.[Total Funded] as [Total Funded (6-Digit)]
        , parent.[Cost Funded] as [Cost Funded (6-Digit)]
        , parent.[Fee Funded] as [Fee Funded (6-Digit)]
        , parent.[Project Value Cost] as [Project Value Cost (6-Digit)]
        , parent.[Project Value Fee] as [Project Value Fee (6-Digit)]
        -- -- Employees
        , e.DeltekId as [DelTek Key]
        , e.BU
        , e.[Employee Id]
        , e.[Employee Name]
        , e.[Preferred/First Name]
        , e.[Riva Level Util]
        , e.[RIVA Level]
        , e.[Cost Cent Description]
        , e.[Position Code]
        , e.[Position Name]
        , e.[Hire Date]
        , e.[Current Work Email]
        , e.[Employee Type]
        , e.[Termination Date]
        -- Utilization Math
        , eu.MeetsWorkHours as [Meets Work Hours]
        , eu.PercWorkedHours as [% Worked hrs / 40 hrs by Mon]
        , eu.BillablePercAccountsPayable as [Billable % A/P 40 hrs]
        , eu.AvgBillablePercAccountsPayable as [Billable % A/P 40 hrs (Proj)]
        , eu.TotalBillableHours as [Total Billable Hours Per Mo]
        , eu.TotalHoursWorked as [Total Hrs Worked Per Mo]
        , eu.WorkableHours as [Workable Hours Per Month]
        , eu.TotalBillableHours as [Billable Hours]
        , eu.Meets85PercUtilLvl [Meets 85% Util Lvl]
        , eu.[Meets 85% Util Lvl (Proj)]
        -- Working Hours
        , w.WorkableDays as [Workable Days]
        , fringe.TotalFringeHours
        , fringe.PercFringe
        , fringe.TotalHoursEntered
    from
        deltek.Utilization as u

    left join cte_proj as p
        on u.[Project ID] = p.ProjectId

    left join deltek.ProjectList as parent 
        on parent.[Project ID] = SUBSTRING(u.[Project ID], 1, 6)

    left join cte_emp as e
        on u.[Employee ID] = e.DeltekId

    left join util.vw_WorkableHoursByMonth as w
        on datepart(year, [Hours Date]) = w.TheYear
            and datepart(month, [Hours Date]) = w.TheMonth

    left join cte_emp_utilization as eu 
        on e.[Employee Id] = eu.EmployeeId 
            and datepart(year, [Hours Date]) = eu.[Year]
            and datepart(month, [Hours Date]) = eu.[Month]

    left join cte_emp_fringe as fringe
        on u.[Employee ID] = fringe.DeltekId
            and datepart(year, [Hours Date]) = fringe.[Year]
            and datepart(month, [Hours Date]) = fringe.[Month]
)

-- The final view matching the column names in Tableau Prep (yuck!).
select
    BU
    , BU as [Macro Organization]
    , round([Billable % A/P 40 hrs], 3) as [Billable % A/P 40 hrs]
    , [Meets 85% Util Lvl (Proj)]
    , round([Billable % A/P 40 hrs (Proj)], 3) as [Billable % A/P 40 hrs (Proj)]
    , [Meets 85% Util Lvl]
    , Billable as [BILLABLE]
    , [Meets Work Hours]
    , round([% Worked hrs / 40 hrs by Mon], 3) as [% Worked hrs / 40 hrs by Mon]
    , [Total Billable Hours Per Mo]
    , [Total Hrs Worked Per Mo]
    , [Workable Hours Per Month]
    , [Billable Hours]
    , [Project Name Code]
    , [Riva Level Util] as [RIVA LEVEL UTIL]
    , [Position Name] as [POSITION NAME]
    , [Riva Level] as [RIVA LEVEL]
    , [Employee Name]
    , [Employee Name] as [NAME 2]
    , [DelTek Key]
    , [Employee ID (DLTK)]
    , [Year]
    , [Year] as [Year-1]
    , [Period Number]
    , [Status]
    , [Project ID] as [Project ID-1]
    , [Pay Type]
    , format([Hours Date], 'yyyy-MM-dd', 'en-US') as [Hours Date]
    , [Entered Hours]
    , [Month]
    , [Workable Days] as [Working Days]
    , [Project ID]
    , [Project Name]
    , [Project Type Desc]
    , [Project Classification]
    , [Project Start Date]
    , [Project End Date]
    , [Total Funded]
    , [Cost Funded]
    , [Fee Funded]
    , [Project Value Cost]
    , [Project Value Fee]
    , [Project ID (6-Digit)]
    , [Project BU]
    , [Project Name (6-Digit)]
    , [Project Type Desc (6-Digit)]
    , [Project Classification (6-Digit)]
    , [Project Start Date (6-Digit)]
    , [Project End Date (6-Digit)]
    , [Total Funded (6-Digit)]
    , [Cost Funded (6-Digit)]
    , [Fee Funded (6-Digit)]
    , [Project Value Cost (6-Digit)]
    , [Project Value Fee (6-Digit)]
    , [Employee Id] as [Employee ID]
    , [Preferred/First Name]
    , [Cost Cent Description]
    , [Position Code]
    , format([Hire Date], 'yyyy-MM-dd', 'en-US') as [Hire Date]
    , [Current Work Email]
    , [Employee Type]
    , format([Termination Date], 'yyyy-MM-dd', 'en-US') as [Termination Date]
    , SUM([Entered Hours]) OVER(partition by [Employee Id]) as [Total(Entered Hours)]
    , (case when [Termination Date] is null then 1 else 0 end) as IsActive
    , TotalFringeHours
    , PercFringe
    , TotalHoursEntered

from cte_final;


--select * from cte_emp_hours where Billable <> 'BILLABLE'
--select count(0) from cte_proj -- 2,200
--select count(0) from cte_billable -- 2,200
--select count(0) from cte_emp --1,576
--select count(0) from cte_emp_billable_hours_month --11,379
--select count(0) from cte_emp_hours -- 296,918
--select count(0) from cte_emp_levels -- 1,718
--select count(0) from cte_emp_position_levels -- 544
--select count(0) from cte_emp_position_names -- 1,174
--select count(0) from cte_emp_total_hours_month -- 12,504
--select count(0) from cte_emp_util -- 12,504
--select count(0) from cte_emp_utilization -- 12,504
--select count(0) from cte_final -- 320,883
--select [Project BU] from cte_final group by [Project BU] order by [Project BU]
--select * from deltek.vw_Utilization
GO


