create view deltek.vw_UtilizationByProjectSeries as
select 
    c.TheLastOfMonth
    , substring(u.[Project ID],1,6) as ProjectCode
    , sum([Entered Hours]) as EnteredHours
from
    deltek.Utilization as u

    left join util.vw_Calendar as c 
        on datepart(year, [Hours Date]) = c.TheYear
        and datepart(month, [Hours Date]) = c.TheMonth
group by
    c.TheLastOfMonth
    , datepart(year, [Hours Date])
    , datepart(month, [Hours Date])
    , substring(u.[Project ID],1,6)
go