create view deltek.vw_UtilizationByMonthSeries as
select 
    c.TheLastOfMonth
    , sum([Entered Hours]) as EnteredHours
from
    deltek.Utilization as u

    left join util.vw_Calendar as c 
        on datepart(year, [Hours Date]) = c.TheYear
        and datepart(month, [Hours Date]) = c.TheMonth
group by
    c.TheLastOfMonth
    , datepart(year, [Hours Date])
    , datepart(month, [Hours Date])
go