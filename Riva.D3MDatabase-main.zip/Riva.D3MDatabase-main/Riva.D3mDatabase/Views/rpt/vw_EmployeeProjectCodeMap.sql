
/*
people -> project
people -> to BU
*/
create view rpt.vw_EmployeeProjectCodeMap as

with cte_proj_map as (
    select
        t.EmployeeId
        , t.EmployeeName
        , p.[Project Start Date] as ProjectStartDate
        , p.[Project End Date] as ProjectEndDate
        , code.BusinessUnitName as ProjectBU
        , code.ProjectCodeName
    from (
        select 
            convert(int, replace([Employee ID], 'E', '')) as EmployeeId
            , [Employee Name] as EmployeeName
            , substring([Project ID], 1, 6) as ProjectCodeName
        from 
            deltek.Utilization
        group by 
            [Employee ID], substring([Project ID], 1, 6), [Employee Name]
    ) as t

    inner join deltek.ProjectList as p 
        on p.[Project ID] = t.ProjectCodeName
    
    left join rpt.vw_ProjectCodeMap as code 
        on t.ProjectCodeName = code.ProjectCodeName
)

-- add project start/end
select
    -- 7 digit max for emp no
    (case
        when e.[Employee Number] not like 'E%'
            then concat('E',
                        case len(e.[Employee Number])
                            when 5 then '0'
                            when 4 then '00'
                            when 3 then '000'
                            when 2 then '0000'
                            when 1 then '00000'
                            else ''
                        end,
                        e.[Employee Number]
                    )
        else e.[Employee Number]
    end) as EmployeeId
    , e.[Employee Name (Last Suffix, First MI)] as EmployeeName
    , e.[Employee Email] as EmployeeEmail
    , map.ProjectBU
    , map.ProjectCodeName
    , map.ProjectStartDate
    , map.ProjectEndDate
    , (case when e.[Employment Status] = 'Active' then 1 else 0 end) as IsActive
from 
    ukg.EmployeeList as e

    left join deltek.BusinessUnit as bu
        on e.[Org Level 3] = bu.BusinessUnitFullName

    left join cte_proj_map as map
        on map.EmployeeId = convert(int, replace(e.[Employee Number], 'E', ''))
where 
    e.[Employee Name (Last Suffix, First MI)] not like 'TEST%,%'
go