create view rpt.vw_UtilizationBase as

with cte_utilization as (
    select
        u.[Employee ID] as EmployeeId
        , convert(int, replace(u.[Employee ID], 'E', '')) as EmpId
        , u.[Period Number] as PeriodNumber
        , u.[Status]
        , u.[Account ID] as AccountId
        , u.[Pay Type] as PayType
        , datepart(year, u.[Hours Date]) as HoursYear
        , datepart(month, u.[Hours Date]) as HoursMonth
        , convert(date, u.[Hours Date]) as HoursDate
        , u.[Entered Hours] as EnteredHours
        , u.[Project ID] as ProjectId
        , substring(u.[Project ID], 1, 6) as ProjectNameCode
    from
        deltek.Utilization as u
    where
        u.[Employee ID] not like 'W%'
)

, cte_emp_lvl as (
    select 
        EmpId as EmpId
        , CareerLevel
        , case CareerLevel
            when 'VII' then 0.25
            when 'VI' then 0.5
            when 'V' then 0.75
            when 'IV' then 0.83
            when 'III' then 0.85
            when 'II' then 0.93
            when 'I' then 0.95
            else 1.0
        end as RivaUtilLevel
        , EmployeeType as EmployeeType
    from (
        select 
            convert(int, replace([Employee Number], 'E', '')) as EmpId
            , (case 
                when [Employment_CareerLevel] like '%VII' then 'VII'
                when [Employment_CareerLevel] like '%VI' then 'VI'
                when [Employment_CareerLevel] like '%IV' then 'IV'
                when [Employment_CareerLevel] like '%V' then 'V'
                when [Employment_CareerLevel] like '%III' then 'III'
                when [Employment_CareerLevel] like '%II' then 'II'
                when [Employment_CareerLevel] like '%I' then 'I'
            end) as CareerLevel
            , case when Employment_CareerLevel = 'SCA' then 'SCA' else 'Non-SCA' end as EmployeeType
        from ukg.CareerLevel
        where [Employee Number] not like 'W%'
    ) as t
)

, cte_emp as (
    select
        emp.[Employee ID] as EmployeeId
        , convert(int, replace([Employee ID], 'E', '')) as EmpId
        , e.EmpLastName
        , e.EmpFirstName
        , e.EmpMiddle
        , e.OrgId
        , e.OrgName
        , emp.[Cost Cent Description] as CostCenterDescription
        , emp.[Position Code] as PositionCode
        , emp.[Current Work Email] as EmployeeEmail
        , emp.[Employee Type] as EmployeeType
        , l.CareerLevel as EmployeeCareerLevel
        , l.RivaUtilLevel
        , convert(date, emp.[Hire Date]) as EmployeeHireDate
        , convert(date, emp.[Termination Date]) as TerminationDate
    from 
        deltek.EmployeeList as emp

        left join ukg.vw_EmployeeOrgMap as e
            on convert(int, replace(emp.[Employee ID], 'E', '')) = convert(int, replace(e.EmpId, 'E', ''))

        left join cte_emp_lvl as l
            on convert(int, replace([Employee ID], 'E', '')) = l.EmpId 
    where
        [Employee ID] not like 'W%'
)

, cte_proj as (
	select
		[Project ID] as ProjectId
        , isnull(pc.ProjectCodeName, substring([Project ID], 1, 6)) as ProjectNameCode
        , [Project Name] as ProjectName
        , convert(date, [Project Start Date]) as ProjectStartDate
        , convert(date, [Project End Date]) as ProjectEndDate
        , [Total Funded] as TotalFunded
        , [Cost Funded] as CostFunded
        , [Fee Funded] as FeeFunded
        , [Project Value Cost] as ProjectValueCost
        , [Project Value Fee] as ProjectValueFee
        , [Project Type Desc] as ProjectTypeDesc
        , [Project Classification] as ProjectClassification
        , (case 
            when isnull(pc.ProjectCodeName, substring([Project ID], 1, 6)) = 'FRINGE' then 'NON-BILLABLE - FRINGE'
            when isnull(pc.ProjectCodeName, substring([Project ID], 1, 6)) in ('GENADM', 'NON-BILLABLE - G&A', 'BNPADM') then 'NON-BILLABLE - G&A'
            when isnull(pc.ProjectCodeName, substring([Project ID], 1, 6)) in ('NON-BILLABLE - O/H', 'NON-BILLABLE O/H', 'KARMA1', 'MATHND', 'OVHEAD', 'SVCNTR') 
                or isnull(pc.ProjectCodeName, substring([Project ID], 1, 6)) like 'BNPOST%'
                then 'NON-BILLABLE - O/H'
            else 'BILLABLE'
        end) as Billable
        , pc.BusinessUnitName as ProjectBU
	from 
        deltek.ProjectList as p

        left join rpt.vw_ProjectCodeMap as pc
            on substring([Project ID], 1, 6) = pc.ProjectCodeName
)

, cte_emp_hours as (
	select
		u.EmpId
		, u.HoursYear
		, u.HoursMonth
        , p.Billable
        , w.WorkableHours
        , w.WorkableDays
        , sum(convert(real, u.EnteredHours)) as TotalEnteredHours
	from
		cte_utilization as u

		left join cte_proj as p
			on u.ProjectId = p.ProjectId

		left join util.vw_WorkableHoursByMonth as w
			on u.HoursYear = w.TheYear 
            and u.HoursMonth = w.TheMonth
    where 
        u.ProjectNameCode not like 'FRINGE%'
    group by
        u.EmpId
		, u.HoursYear
		, u.HoursMonth
        , p.Billable
        , w.WorkableHours
        , w.WorkableDays
)

, cte_emp_total_hours_month as (
	select
        EmpId
		, HoursYear
		, HoursMonth
        , WorkableHours
        , WorkableDays
        , sum(convert(real, TotalEnteredHours)) as TotalEnteredHours
	from
        cte_emp_hours
    group by
        EmpId
		, HoursYear
		, HoursMonth
        , WorkableHours
        , WorkableDays
)

, cte_emp_billable_hours_month as (
	select
        EmpId
		, HoursYear
		, HoursMonth
        , WorkableHours
        , WorkableDays
        , sum(convert(real, TotalEnteredHours)) as TotalBillableHours
	from
        cte_emp_hours
    where 
        Billable = 'BILLABLE'
    group by
        EmpId
		, HoursYear
		, HoursMonth
        , WorkableHours
        , WorkableDays
)

, cte_emp_fringe as (
    select
        u.EmpId
        , u.HoursYear
        , u.HoursMonth
        , sum(u.EnteredHours) as TotalFringeHours
        , convert(decimal(5,2), case 
            when hrs.TotalEnteredHours > 0 
                then sum(u.EnteredHours) / hrs.TotalEnteredHours
            else 0.00
        end) as PercFringe
    from 
        cte_utilization as u
        
        left join cte_emp_total_hours_month as hrs 
            on u.EmpId = hrs.EmpId
                and u.HoursYear = hrs.HoursYear
                and u.HoursMonth = hrs.HoursMonth
    where 
        u.ProjectNameCode like 'FRINGE%'
    group by
        u.EmpId
        , u.HoursYear
        , u.HoursMonth
        , hrs.TotalEnteredHours
)

, cte_emp_util as (
    select
        hrs.EmpId
        , hrs.HoursYear
        , hrs.HoursMonth
        , hrs.TotalEnteredHours
        , bill.TotalBillableHours
        , hrs.WorkableHours
        , hrs.WorkableDays
        , round(hrs.TotalEnteredHours / hrs.WorkableHours, 2) as PercWorkedHours
        , round((case 
            when (hrs.TotalEnteredHours < hrs.WorkableHours) and (isnull(hrs.TotalEnteredHours, 0) > 0)
                then (bill.TotalBillableHours / hrs.TotalEnteredHours)
            else (isnull(bill.TotalBillableHours, 0) / hrs.WorkableHours)
        end), 2) as BillablePercAccountsPayable
    from 
        cte_emp_total_hours_month as hrs

        left join cte_emp_billable_hours_month as bill
            on hrs.EmpId = bill.EmpId
                and hrs.HoursYear = bill.HoursYear
                and hrs.HoursMonth = bill.HoursMonth
)

, cte_emp_utilization as (
    select
        EmpId
        , HoursYear
        , HoursMonth
        , WorkableHours
        , TotalEnteredHours
        , TotalBillableHours
        , PercWorkedHours
        , BillablePercAccountsPayable
        , Meets85PercUtilLvl
        , MeetsWorkHours
        , WorkableDays
        , AvgBillablePercAccountsPayable as AvgBillablePercAccountsPayable
        , (case 
            when AvgBillablePercAccountsPayable is null then 'NO BILLABLE TIME ENTERED'
            when AvgBillablePercAccountsPayable = 0.00 then 'NO BILLABLE EXPECTATION'
            when AvgBillablePercAccountsPayable < 0.85 then 'BELOW'
            when AvgBillablePercAccountsPayable = 0.85 then 'MEETS'
            when AvgBillablePercAccountsPayable > 0.85 and AvgBillablePercAccountsPayable <= 1 then 'EXCEEDS W/IN EXPECTATION'
            else 'EXCEEDS BEYOND EXPECTATION'
        end) as Meets85PercUtilLvlProj
    from (
        select
            EmpId
            , HoursYear
            , HoursMonth
            , WorkableHours
            , TotalEnteredHours
            , TotalBillableHours
            , PercWorkedHours
            , WorkableDays
            , BillablePercAccountsPayable
            , round(AVG(BillablePercAccountsPayable), 2) as AvgBillablePercAccountsPayable
            , (case
                when BillablePercAccountsPayable is null then 'NO BILLABLE TIME ENTERED'
                when BillablePercAccountsPayable = 0.00 then 'NO BILLABLE EXPECTATION'
                when BillablePercAccountsPayable < 0.85 then 'BELOW'
                when BillablePercAccountsPayable = 0.85 then 'MEETS'
                when BillablePercAccountsPayable > 0.85 and BillablePercAccountsPayable <= 1.0 then 'EXCEEDS W/IN EXPECTATION'
                else 'EXCEEDS BEYOND EXPECTATION'
            end) as Meets85PercUtilLvl
            , (case
                when PercWorkedHours is null then 'NO BILLABLE TIME ENTERED'
                when PercWorkedHours = 0.0 then 'NO BILLABLE EXPECTATION'
                when PercWorkedHours < 1.0 then 'BELOW'
                when PercWorkedHours = 1.0 then 'MEETS'
                else 'EXCEEDS EXPECTATION'
            end) as MeetsWorkHours
        from 
            cte_emp_util as u
        group by
            EmpId
            , HoursYear
            , HoursMonth
            , WorkableHours
            , TotalEnteredHours
            , TotalBillableHours
            , PercWorkedHours
            , WorkableDays
            , BillablePercAccountsPayable
    ) as t
)

select
    u.EmployeeId
    , e.EmpLastName
    , e.EmpFirstName
    , e.EmpMiddle
    , e.OrgId
    , e.OrgName
    , e.CostCenterDescription
    , e.PositionCode
    , e.EmployeeEmail
    , e.EmployeeType
    , e.EmployeeHireDate
    , e.TerminationDate
    , e.EmployeeCareerLevel
    , u.PeriodNumber
    , u.[Status]
    , u.AccountId
    , u.PayType
    , u.HoursDate
    , u.EnteredHours
    , u.ProjectId
    , p.ProjectName
    , p.ProjectNameCode
    , p.ProjectClassification
    , p.ProjectEndDate
    , p.ProjectStartDate
    , p.ProjectTypeDesc
    , p.ProjectValueCost
    , p.ProjectValueFee
    , p.CostFunded
    , p.FeeFunded
    , p.TotalFunded
    -- formulas
    , eu.AvgBillablePercAccountsPayable
    , eu.BillablePercAccountsPayable
    , eu.HoursMonth
    , eu.HoursYear
    , eu.Meets85PercUtilLvl
    , eu.Meets85PercUtilLvlProj
    , eu.MeetsWorkHours
    , eu.PercWorkedHours
    , eu.TotalBillableHours
    , eu.TotalEnteredHours
    , eu.WorkableDays
    , eu.WorkableHours
    , fringe.PercFringe
    , fringe.TotalFringeHours
from
    cte_utilization as u

left join cte_proj as p
    on u.ProjectId = p.ProjectId

-- left join deltek.ProjectList as parent 
--     on parent.[Project ID] = u.ProjectNameCode

left join cte_emp as e
    on u.EmpId = e.EmpId

left join cte_emp_utilization as eu 
    on e.EmpId = eu.EmpId 
        and u.HoursYear = eu.HoursYear
        and u.HoursMonth = eu.HoursMonth

left join cte_emp_fringe as fringe
    on u.EmpId = fringe.EmpId
        and u.HoursYear = fringe.HoursYear
        and u.HoursMonth = fringe.HoursMonth
go