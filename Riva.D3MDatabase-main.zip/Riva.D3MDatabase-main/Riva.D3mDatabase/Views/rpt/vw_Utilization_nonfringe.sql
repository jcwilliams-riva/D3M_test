--create view rpt.vw_Utilization as

with cte_utilization as (
    select
        [Account ID] as util_AccountId
        , [Employee ID] as util_EmpNum
        , [Employee Name] as util_EmployeeName
        , [Entered Hours] as util_EnteredHours
        , [Hours Date] as util_HoursDate
        , [Pay Type] as util_PayType
        , [Period Number] as util_PeriodNumber
        , [Project ID] as util_ProjectId
        , SUBSTRING([Project ID], 1, 6) as util_ProjectNameCode
        , [Status] as util_Status
        , datepart(year, [Hours Date]) as util_Year
        , datepart(month, [Hours Date]) as util_Month
        , convert(int, replace([Employee ID], 'E', '')) as util_EmpId
        , pc.BusinessUnitName as ProjectBU
    from
        deltek.Utilization as u

        left join rpt.vw_ProjectCodeMap as pc
            on SUBSTRING([Project ID], 1, 6) = pc.ProjectCodeName 
)

, cte_emp_lvl as (
    select 
        EmpId as lvl_EmpId
        , CareerLevel as lvl_CareerLevel
        , case CareerLevel
            when 'VII' then 0.25
            when 'VI' then 0.5
            when 'V' then 0.75
            when 'IV' then 0.83
            when 'III' then 0.85
            when 'II' then 0.93
            when 'I' then 0.95
            else 1.0
        end as lvl_RivaUtilLevel
        , EmployeeType as lvl_EmployeeType
    from (
        select 
            convert(int, replace([Employee Number], 'E', '')) as EmpId
            , (case 
                when [Employment_CareerLevel] like '%VII' then 'VII'
                when [Employment_CareerLevel] like '%VI' then 'VI'
                when [Employment_CareerLevel] like '%IV' then 'IV'
                when [Employment_CareerLevel] like '%V' then 'V'
                when [Employment_CareerLevel] like '%III' then 'III'
                when [Employment_CareerLevel] like '%II' then 'II'
                when [Employment_CareerLevel] like '%I' then 'I'
            end) as CareerLevel
            , case when Employment_CareerLevel = 'SCA' then 'SCA' else 'Non-SCA' end as EmployeeType
        from ukg.CareerLevel
    ) as t
)

, cte_emp as (
    select 
        emp_EmpId
        , emp_EmployeeName
        , emp_EmploymentStatus
        , emp_PositionName
        , emp_OrgLevel1
        , emp_OrgLevel2
        , emp_OrgLevel3
        , emp_SupervisorName
        , emp_HireDate
        , emp_TerminationDate
        , emp_BU
        , emp_IsActive
        , lvl_CareerLevel as emp_CareerLevel
        , lvl_RivaUtilLevel as emp_RivaUtilLevel
        , lvl_EmployeeType as emp_EmployeeType
        , Email as emp_Email
    from (
        select
            convert(int, replace([Employee Number], 'E', '')) as emp_EmpId
            , [Employee Name (Last Suffix, First MI)] as emp_EmployeeName
            , [Employment Status] as emp_EmploymentStatus
            , Job as emp_PositionName
            , [Org Level 1] as emp_OrgLevel1
            , [Org Level 2] as emp_OrgLevel2
            , [Org Level 3] as emp_OrgLevel3
            , [Supervisor Name (Unsecured)] as emp_SupervisorName
            , [Original Hire] as emp_HireDate
            , [Termination Date] as emp_TerminationDate
            , bu.BusinessUnitName as emp_BU
            , (case when [Employment Status] = 'Active' then 1 else 0 end) as emp_IsActive
            , e.[Employee Email] as Email
        from 
            ukg.EmployeeList as e

            left join deltek.BusinessUnit as bu
                on e.[Org Level 3] = bu.BusinessUnitFullName 
    ) as emp

    left join cte_emp_lvl as lvl
        on emp.emp_EmpId = lvl.lvl_EmpId
)

, cte_proj as (
	select
		[Project ID] as proj_ProjectId
        , isnull(pc.ProjectCodeName, substring([Project ID], 1, 6)) as proj_ProjectNameCode
        , [Project Name] as proj_ProjectName
        , [Project Start Date] as proj_ProjectStartDate
        , [Project End Date] as proj_ProjectEndDate
        , [Total Funded] as proj_TotalFunded
        , [Cost Funded] as proj_CostFunded
        , [Fee Funded] as proj_FeeFunded
        , [Project Value Cost] as proj_ProjectValueCost
        , [Project Value Fee] as proj_ProjectValueFee
        , [Project Type Desc] as proj_ProjectTypeDesc
        , [Project Classification] as proj_ProjectClassification
        , (case 
            when isnull(pc.ProjectCodeName, substring([Project ID], 1, 6)) = 'FRINGE' then 'NON-BILLABLE - FRINGE'
            when isnull(pc.ProjectCodeName, substring([Project ID], 1, 6)) in ('GENADM', 'NON-BILLABLE - G&A', 'BNPADM', 'QAMGMT') then 'NON-BILLABLE - G&A'
            when isnull(pc.ProjectCodeName, substring([Project ID], 1, 6)) in ('NON-BILLABLE - O/H', 'NON-BILLABLE O/H', 'KARMA1', 'MATHND', 'OVHEAD', 'SVCNTR') 
                or isnull(pc.ProjectCodeName, substring([Project ID], 1, 6)) like 'BNPOST%'
                then 'NON-BILLABLE - O/H'
            else 'BILLABLE'
        end) as proj_Billable
        , pc.BusinessUnitName as proj_ProjectBU
	from 
        deltek.ProjectList as p
        left join rpt.vw_ProjectCodeMap as pc on substring([Project ID], 1, 6) = pc.ProjectCodeName
)

, cte_emp_hours as (
	select
		util_EmpId as hrs_EmpId
		, util_Year as hrs_Year
		, util_Month as hrs_Month
        , proj_Billable as hrs_Billable
		, sum(convert(real, util_EnteredHours)) as hrs_TotalEnteredHours
        , w.WorkableHours as hrs_WorkableHours
        , w.WorkableDays as hrs_WorkableDays
	from
		cte_utilization

		left join cte_proj
			on util_ProjectID = proj_ProjectId

		left join util.vw_WorkableHoursByMonth as w
			on util_Year = w.TheYear 
            and util_Month = w.TheMonth
    where 
        util_ProjectID not like '%FRINGE%'
    group by
        util_EmpId
		, util_Year
		, util_Month
        , proj_Billable
        , w.WorkableHours
        , w.WorkableDays
)

, cte_emp_total_hours_month as (
	select
        hrs_EmpId
		, hrs_Year
		, hrs_Month
        , hrs_WorkableHours
        , hrs_WorkableDays
        , sum(convert(real, hrs_TotalEnteredHours)) as hrs_TotalEnteredHours
	from
        cte_emp_hours
    group by
        hrs_EmpId
		, hrs_Year
		, hrs_Month
        , hrs_WorkableHours
        , hrs_WorkableDays
)

, cte_emp_billable_hours_month as (
	select
        hrs_EmpId as bill_EmpId
		, hrs_Year as bill_Year
		, hrs_Month as bill_Month
        , sum(hrs_TotalEnteredHours) as bill_TotalBillableHours
	from 
        cte_emp_hours 
	where 
        hrs_Billable = 'BILLABLE'
    group by
        hrs_EmpId
		, hrs_Year
		, hrs_Month
)

, cte_emp_fringe as (
    select
        util_EmpId as fringe_EmpId
        , util_Year as fringe_Year
        , util_Month as fringe_Month
        , sum(util_EnteredHours) as fringe_TotalFringeHours
        , convert(decimal(5,2), case 
            when hrs_TotalEnteredHours > 0 
                then sum(util_EnteredHours) / hrs_TotalEnteredHours
            else 0.00
        end) as fringe_PercFringe
    from 
        cte_utilization
        
        left join cte_emp_total_hours_month as hrs 
            on util_EmpId = hrs_EmpId
                and util_Year = hrs_Year
                and util_Month = hrs_Month
    where 
        util_ProjectID like '%FRINGE%'
    group by
        util_EmpId
        , util_Year
        , util_Month
        , hrs_TotalEnteredHours
)

, cte_emp_util as (
    select
        hrs_EmpId as emputil_EmpId
        , hrs_Year as emputil_Year
        , hrs_Month as emputil_Month
        , hrs_TotalEnteredHours as emputil_TotalEnteredHours
        , bill_TotalBillableHours as emputil_TotalBillableHours
        , hrs_WorkableHours as emputil_WorkableHours
        , hrs_WorkableDays as emputil_WorkableDays
        , round(hrs_TotalEnteredHours / hrs_WorkableHours, 2) as emputil_PercWorkedHours
        , round((case 
            when (hrs_TotalEnteredHours < hrs_WorkableHours) and (isnull(hrs_TotalEnteredHours, 0) > 0)
                then (bill_TotalBillableHours / hrs_TotalEnteredHours)
            else (isnull(bill_TotalBillableHours, 0) / hrs_WorkableHours)
        end), 2) as emputil_BillablePercAccountsPayable
    from 
        cte_emp_total_hours_month as hrs

        left join cte_emp_billable_hours_month as bill
            on hrs_EmpId = bill_EmpId
                and hrs_Year = bill_Year 
                and hrs_Month = bill_Month
)

, cte_emp_utilization as (
    select
        emputil_EmpId
        , emputil_Year
        , emputil_Month
        , emputil_WorkableHours
        , emputil_TotalEnteredHours
        , emputil_TotalBillableHours
        , emputil_PercWorkedHours
        , emputil_BillablePercAccountsPayable
        , emputil_Meets85PercUtilLvl
        , emputil_MeetsWorkHours
        , emputil_WorkableDays
        , AvgBillablePercAccountsPayable as emputil_AvgBillablePercAccountsPayable
        , (case 
            when AvgBillablePercAccountsPayable is null then 'NO BILLABLE TIME ENTERED'
            when AvgBillablePercAccountsPayable = 0.00 then 'NO BILLABLE EXPECTATION'
            when AvgBillablePercAccountsPayable < 0.85 then 'BELOW'
            when AvgBillablePercAccountsPayable = 0.85 then 'MEETS'
            when AvgBillablePercAccountsPayable > 0.85 and AvgBillablePercAccountsPayable <= 1 then 'EXCEEDS W/IN EXPECTATION'
            else 'EXCEEDS BEYOND EXPECTATION'
        end) as emputil_Meets85PercUtilLvlProj
    from (
        select
            emputil_EmpId
            , emputil_Year
            , emputil_Month
            , emputil_WorkableHours
            , emputil_TotalEnteredHours
            , emputil_TotalBillableHours
            , emputil_PercWorkedHours
            , emputil_WorkableDays
            , emputil_BillablePercAccountsPayable
            , round(AVG(emputil_BillablePercAccountsPayable), 2) as AvgBillablePercAccountsPayable
            , (case
                when emputil_BillablePercAccountsPayable is null then 'NO BILLABLE TIME ENTERED'
                when emputil_BillablePercAccountsPayable = 0.00 then 'NO BILLABLE EXPECTATION'
                when emputil_BillablePercAccountsPayable < 0.85 then 'BELOW'
                when emputil_BillablePercAccountsPayable = 0.85 then 'MEETS'
                when emputil_BillablePercAccountsPayable > 0.85 and emputil_BillablePercAccountsPayable <= 1.0 then 'EXCEEDS W/IN EXPECTATION'
                else 'EXCEEDS BEYOND EXPECTATION'
            end) as emputil_Meets85PercUtilLvl
            , (case
                when emputil_PercWorkedHours is null then 'NO BILLABLE TIME ENTERED'
                when emputil_PercWorkedHours = 0.0 then 'NO BILLABLE EXPECTATION'
                when emputil_PercWorkedHours < 1.0 then 'BELOW'
                when emputil_PercWorkedHours = 1.0 then 'MEETS'
                else 'EXCEEDS EXPECTATION'
            end) as emputil_MeetsWorkHours
        from 
            cte_emp_util
        group by
            emputil_EmpId
            , emputil_Year
            , emputil_Month
            , emputil_WorkableHours
            , emputil_TotalEnteredHours
            , emputil_TotalBillableHours
            , emputil_PercWorkedHours
            , emputil_WorkableDays
            , emputil_BillablePercAccountsPayable
            , emputil_PercWorkedHours
            , emputil_BillablePercAccountsPayable
    ) as t
)

/*
[Billable % A/P 40 hrs] = 
    IF [Total Hrs Worked Per Mo] < [Workable Hour Per Month]
        THEN [Total Billable Hours Per Mo] / [Total Hrs Worked Per Mo]
    ELSE [Total Billable Hours Per Mo] / [Workable Hour Per Month]

[% worked hrs / 40 hrs by Mon] = [Total Hrs Worked Per Mo] / [Workable Hour Per Month]

--
[Meets Work Hours] = 
    IF ISNULL([% worked hrs / 40 hrs by Mon]) = TRUE THEN 'NO BILLABLE TIME ENTERED'
    ELSEIF [% worked hrs / 40 hrs by Mon] = 0 THEN 'NO BILLABLE EXPECTATION'
    ELSEIF [% worked hrs / 40 hrs by Mon] < 1 THEN 'BELOW'
    ELSEIF [% worked hrs / 40 hrs by Mon] = 1 THEN 'MEETS'
    ELSE 'EXCEEDS EXPECTATION' END
--

[Meets 85% Util Lvl] = 
    IF ISNULL([Billable % A/P 40 hrs]) = TRUE THEN 'NO BILLABLE TIME ENTERED'
    ELSEIF [Billable % A/P 40 hrs] = 0 THEN 'NO BILLABLE EXPECTATION'
    ELSEIF [Billable % A/P 40 hrs] < 0.85 THEN 'BELOW'
    ELSEIF [Billable % A/P 40 hrs] = 0.85 THEN 'MEETS'
    ELSEIF [Billable % A/P 40 hrs] > 0.85 AND [Billable % A/P 40 hrs] <= 1 THEN 'EXCEEDS W/IN EXPECTATION'
    ELSE 'EXCEEDS BEYOND EXPECTATION' END
--

[Billable % A/P 40 hrs (Proj)] = AVG([Billable % A/P 40 hrs])
--
[Meets 85% Util Lvl (Proj)] = 
    IF ISNULL([Billable % A/P 40 hrs (Proj)]) = TRUE THEN 'NO BILLABLE TIME ENTERED'
    ELSEIF [Billable % A/P 40 hrs (Proj)] = 0 THEN 'NO BILLABLE EXPECTATION'
    ELSEIF [Billable % A/P 40 hrs (Proj)]) < 0.85 THEN 'BELOW'
    ELSEIF [Billable % A/P 40 hrs (Proj)] = 0.85 THEN 'MEETS'
    ELSEIF [Billable % A/P 40 hrs (Proj)] > 0.85 AND [Billable % A/P 40 hrs (Proj)] <= 1 THEN 'EXCEEDS W/IN EXPECTATION'
    ELSE 'EXCEEDS BEYOND EXPECTATION' END
*/
, cte_final as (
-- "Clean 25" in Tableau Prep
    select distinct
        proj_ProjectNameCode as [Project Name Code]
        , util_EmpNum as [Employee ID (DLTK)]
        , util_Year [Year]
        , util_Month as [Month]
        , util_PeriodNumber as [Period Number]
        , util_Status as [Status]
        , util_ProjectId as [Project ID]
        , util_PayType [Pay Type]
        , util_HoursDate as [Hours Date]
        , util_EnteredHours as [Entered Hours]
        -- Projects
        , proj_ProjectName as [Project Name]
        , proj_ProjectTypeDesc as [Project Type Desc]
        , proj_ProjectClassification as [Project Classification]
        , proj_ProjectStartDate as [Project Start Date]
        , proj_ProjectEndDate as [Project End Date]
        , proj_TotalFunded as [Total Funded]
        , proj_CostFunded as [Cost Funded]
        , proj_FeeFunded as [Fee Funded]
        , proj_ProjectValueCost as [Project Value Cost]
        , proj_ProjectValueFee as [Project Value Fee]
        , proj_Billable as Billable
        , parent.[Project ID] as [Project ID (6-Digit)]
        , proj_ProjectBU as [Project BU]
        , parent.[Project Name] as [Project Name (6-Digit)]
        , parent.[Project Type Desc] as [Project Type Desc (6-Digit)]
        , parent.[Project Classification] as [Project Classification (6-Digit)]
        , parent.[Project Start Date] as [Project Start Date (6-Digit)]
        , parent.[Project End Date] as [Project End Date (6-Digit)]
        , parent.[Total Funded] as [Total Funded (6-Digit)]
        , parent.[Cost Funded] as [Cost Funded (6-Digit)]
        , parent.[Fee Funded] as [Fee Funded (6-Digit)]
        , parent.[Project Value Cost] as [Project Value Cost (6-Digit)]
        , parent.[Project Value Fee] as [Project Value Fee (6-Digit)]
        -- -- Employees
        , util_EmpNum as [DelTek Key]
        , emp_BU as BU
        , emp_EmpId as [Employee Id]
        , emp_EmployeeName as [Employee Name]
        , emp_RivaUtilLevel as [Riva Level Util]
        , emp_RivaUtilLevel as [RIVA Level]
        , emp_PositionName as [Position Code]
        , emp_PositionName as [Position Name]
        , emp_HireDate as [Hire Date]
        , emp_EmployeeType as [Employee Type]
        , emp_TerminationDate as [Termination Date]
        , emp_SupervisorName as [Supervisor Name]
        , emp_EmploymentStatus as [Employment Status]
        , emp_IsActive as IsActive
        , emp_OrgLevel1 as [Org Level 1]
        , emp_OrgLevel2 as [Org Level 2]
        , emp_OrgLevel3 as [Org Level 3]
        , emp_Email as [Employee Email]
        -- Utilization
        , emputil_MeetsWorkHours as [Meets Work Hours]
        , emputil_PercWorkedHours as [% Worked hrs / 40 hrs by Mon]
        , emputil_BillablePercAccountsPayable as [Billable % A/P 40 hrs]
        , emputil_AvgBillablePercAccountsPayable as [Billable % A/P 40 hrs (Proj)]
        , emputil_TotalBillableHours as [Total Billable Hours Per Mo]
        , emputil_TotalEnteredHours as [Total Hrs Worked Per Mo]
        , emputil_WorkableHours as [Workable Hours Per Month]
        , emputil_TotalBillableHours as [Billable Hours]
        , emputil_Meets85PercUtilLvl [Meets 85% Util Lvl]
        , emputil_Meets85PercUtilLvlProj as [Meets 85% Util Lvl (Proj)]
        , emputil_TotalEnteredHours as TotalEnteredHours
        , emputil_WorkableDays as [Workable Days]
        , fringe_TotalFringeHours as [TotalFringeHours]
        , fringe_PercFringe as [PercFringe]
    from
        cte_utilization as u

    left join cte_proj as p
        on util_ProjectId = proj_ProjectId

    left join deltek.ProjectList as parent 
        on parent.[Project ID] = util_ProjectNameCode

    left join cte_emp as e
        on util_EmpId = emp_EmpId

    left join cte_emp_utilization as eu 
        on emp_EmpId = eu.emputil_EmpId 
            and util_Year = emputil_Year
            and util_Month = emputil_Month

    left join cte_emp_fringe as fringe
        on util_EmpId = fringe_EmpId
            and util_Year = fringe_Year
            and util_Month = fringe_Month
)

-- The final view matching the column names in Tableau Prep (yuck!).
select
    BU
    , BU as [Macro Organization]
    , round([Billable % A/P 40 hrs], 3) as [Billable % A/P 40 hrs]
    , [Meets 85% Util Lvl (Proj)]
    , round([Billable % A/P 40 hrs (Proj)], 3) as [Billable % A/P 40 hrs (Proj)]
    , [Meets 85% Util Lvl]
    , Billable as [BILLABLE]
    , [Meets Work Hours]
    , round([% Worked hrs / 40 hrs by Mon], 3) as [% Worked hrs / 40 hrs by Mon]
    , [Total Billable Hours Per Mo]
    , [Total Hrs Worked Per Mo]
    , [Workable Hours Per Month]
    , [Billable Hours]
    , [Project Name Code]
    , [Riva Level Util] as [RIVA LEVEL UTIL]
    , [Position Name] as [POSITION NAME]
    , [Riva Level] as [RIVA LEVEL]
    , [Employee Name]
    , [Employee Name] as [NAME 2]
    , [Employee Email]
    , [DelTek Key]
    , [Employee ID (DLTK)]
    , [Year]
    , [Year] as [Year-1]
    , [Period Number]
    , [Status]
    , [Project ID] as [Project ID-1]
    , [Pay Type]
    , format([Hours Date], 'yyyy-MM-dd', 'en-US') as [Hours Date]
    , [Entered Hours]
    , [Month]
    , [Workable Days] as [Working Days]
    , [Project ID]
    , [Project Name]
    , [Project Type Desc]
    , [Project Classification]
    , [Project Start Date]
    , [Project End Date]
    , [Total Funded]
    , [Cost Funded]
    , [Fee Funded]
    , [Project Value Cost]
    , [Project Value Fee]
    , [Project ID (6-Digit)]
    , [Project BU]
    , [Project Name (6-Digit)]
    , [Project Type Desc (6-Digit)]
    , [Project Classification (6-Digit)]
    , [Project Start Date (6-Digit)]
    , [Project End Date (6-Digit)]
    , [Total Funded (6-Digit)]
    , [Cost Funded (6-Digit)]
    , [Fee Funded (6-Digit)]
    , [Project Value Cost (6-Digit)]
    , [Project Value Fee (6-Digit)]
    , [Employee Id] as [Employee ID]
    , null as [Preferred/First Name]
    , null as [Cost Cent Description]
    , [Position Code]
    , format([Hire Date], 'yyyy-MM-dd', 'en-US') as [Hire Date]
    , null as [Current Work Email]
    , [Employee Type]
    , format([Termination Date], 'yyyy-MM-dd', 'en-US') as [Termination Date]
    , SUM([Entered Hours]) OVER(partition by [Employee Id], [Year]) as [Total(Entered Hours)]
    , IsActive
    , TotalFringeHours
    , PercFringe
    , TotalEnteredHours as TotalHoursEntered
    , [Org Level 1]
    , [Org Level 2]
    , [Org Level 3]
    , [Supervisor Name]
    , [Employment Status]
    
from cte_final;

--select * from cte_emp_hours where Billable <> 'BILLABLE'
--select count(0) from deltek.ProjectList -- 1,937
--select count(0) from cte_proj -- 1,937
--select count(0) from cte_billable -- 2,237
--select count(0) from cte_emp --1,369
--select count(0) from cte_emp_billable_hours_month --12,097
--select count(0) from cte_emp_hours -- 14,114
--select count(0) from cte_emp_total_hours_month -- 13,442
--select count(0) from cte_emp_util -- 13,442
--select count(0) from cte_emp_utilization -- 13,442
--select count(0) from cte_final -- 319,324
--select count(0) from deltek.vw_Utilization -- 319,324