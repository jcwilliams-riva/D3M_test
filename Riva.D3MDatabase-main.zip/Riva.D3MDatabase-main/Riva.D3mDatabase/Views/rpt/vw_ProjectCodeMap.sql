﻿CREATE VIEW rpt.vw_ProjectCodeMap AS

SELECT
	map.Id as MapId
	, bu.BusinessUnitId
	, bu.BusinessUnitName
	, bu.BusinessUnitFullName
	, pc.ProjectCodeId
	, pc.ProjectCodeName
FROM
	deltek.ProjectCodeMap AS map
	INNER JOIN deltek.BusinessUnit AS bu ON map.BusinessUnitId = bu.BusinessUnitId
	INNER JOIN deltek.ProjectCode AS pc ON map.ProjectCodeId = pc.ProjectCodeId
GO
