create view ukg.vw_EmployeeOrgMap as
select
    mp.EmpId
    , e.EmpLastName
    , e.EmpFirstName
    , e.EmpMiddle
    , mp.OrgId
    , o.OrgName
from
    ukg.EmployeeOrgMap as mp

    left join ukg.Employee as e on mp.EmpId = e.EmpId

    left join ukg.Org as o on mp.OrgId = o.OrgId
go