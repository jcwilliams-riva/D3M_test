
create view survey.vw_SurveyForm as 
select 
    u.Id as SurveyId
    , map.Question
    , Answer
    , QuestionNum 
from (
select
    Id,
    cast( Q001 as varchar(400)) as Q001,
    cast( Q002 as varchar(400)) as Q002,
    cast( Q003 as varchar(400)) as Q003,
    cast( Q004 as varchar(400)) as Q004,
    cast( Q005 as varchar(400)) as Q005,
    cast( Q006 as varchar(400)) as Q006,
    cast( Q007 as varchar(400)) as Q007,
    cast( Q008 as varchar(400)) as Q008,
    cast( Q009 as varchar(400)) as Q009,
    cast( Q010 as varchar(400)) as Q010,
    cast( Q011 as varchar(400)) as Q011,
    cast( Q012 as varchar(400)) as Q012,
    cast( Q013 as varchar(400)) as Q013,
    cast( Q014 as varchar(400)) as Q014,
    cast( Q015 as varchar(400)) as Q015,
    cast( Q016 as varchar(400)) as Q016,
    cast( Q017 as varchar(400)) as Q017,
    cast( Q018 as varchar(400)) as Q018,
    cast( Q019 as varchar(400)) as Q019,
    cast( Q020 as varchar(400)) as Q020,
    cast( Q021 as varchar(400)) as Q021,
    cast( Q022 as varchar(400)) as Q022,
    cast( Q023 as varchar(400)) as Q023,
    cast( Q024 as varchar(400)) as Q024,
    cast( Q025 as varchar(400)) as Q025,
    cast( Q026 as varchar(400)) as Q026,
    cast( Q027 as varchar(400)) as Q027,
    cast( Q028 as varchar(400)) as Q028,
    cast( Q029 as varchar(400)) as Q029,
    cast( Q030 as varchar(400)) as Q030,
    cast( Q031 as varchar(400)) as Q031,
    cast( Q032 as varchar(400)) as Q032,
    cast( Q033 as varchar(400)) as Q033,
    cast( Q034 as varchar(400)) as Q034,
    cast( Q035 as varchar(400)) as Q035,
    cast( Q036 as varchar(400)) as Q036,
    cast( Q037 as varchar(400)) as Q037,
    cast( Q038 as varchar(400)) as Q038,
    cast( Q039 as varchar(400)) as Q039,
    cast( Q040 as varchar(400)) as Q040,
    cast( Q041 as varchar(400)) as Q041,
    cast( Q042 as varchar(400)) as Q042,
    cast( Q043 as varchar(400)) as Q043,
    cast( Q044 as varchar(400)) as Q044,
    cast( Q045 as varchar(400)) as Q045,
    cast( Q046 as varchar(400)) as Q046,
    cast( Q047 as varchar(400)) as Q047,
    cast( Q048 as varchar(400)) as Q048,
    cast( Q049 as varchar(400)) as Q049,
    cast( Q050 as varchar(400)) as Q050,
    cast( Q051 as varchar(400)) as Q051,
    cast( Q052 as varchar(400)) as Q052,
    cast( Q053 as varchar(400)) as Q053,
    cast( Q054 as varchar(400)) as Q054,
    cast( Q055 as varchar(400)) as Q055,
    cast( Q056 as varchar(400)) as Q056,
    cast( Q057 as varchar(400)) as Q057,
    cast( Q058 as varchar(400)) as Q058,
    cast( Q059 as varchar(400)) as Q059,
    cast( Q060 as varchar(400)) as Q060,
    cast( Q061 as varchar(400)) as Q061,
    cast( Q062 as varchar(400)) as Q062,
    cast( Q063 as varchar(400)) as Q063,
    cast( Q064 as varchar(400)) as Q064,
    cast( Q065 as varchar(400)) as Q065,
    cast( Q066 as varchar(400)) as Q066,
    cast( Q067 as varchar(400)) as Q067,
    cast( Q068 as varchar(400)) as Q068,
    cast( Q069 as varchar(400)) as Q069,
    cast( Q070 as varchar(400)) as Q070,
    cast( Q071 as varchar(400)) as Q071,
    cast( Q072 as varchar(400)) as Q072,
    cast( Q073 as varchar(400)) as Q073,
    cast( Q074 as varchar(400)) as Q074,
    cast( Q075 as varchar(400)) as Q075,
    cast( Q076 as varchar(400)) as Q076,
    cast( Q077 as varchar(400)) as Q077,
    cast( Q078 as varchar(400)) as Q078,
    cast( Q079 as varchar(400)) as Q079,
    cast( Q080 as varchar(400)) as Q080,
    cast( Q081 as varchar(400)) as Q081,
    cast( Q082 as varchar(400)) as Q082,
    cast( Q083 as varchar(400)) as Q083,
    cast( Q084 as varchar(400)) as Q084,
    cast( Q085 as varchar(400)) as Q085,
    cast( Q086 as varchar(400)) as Q086,
    cast( Q087 as varchar(400)) as Q087,
    cast( Q088 as varchar(400)) as Q088,
    cast( Q089 as varchar(400)) as Q089,
    cast( Q090 as varchar(400)) as Q090,
    cast( Q091 as varchar(400)) as Q091,
    cast( Q092 as varchar(400)) as Q092,
    cast( Q093 as varchar(400)) as Q093,
    cast( Q094 as varchar(400)) as Q094,
    cast( Q095 as varchar(400)) as Q095,
    cast( Q096 as varchar(400)) as Q096,
    cast( Q097 as varchar(400)) as Q097,
    cast( Q098 as varchar(400)) as Q098,
    cast( Q099 as varchar(400)) as Q099,
    cast( Q100 as varchar(400)) as Q100,
    cast( Q101 as varchar(400)) as Q101,
    cast( Q102 as varchar(400)) as Q102,
    cast( Q103 as varchar(400)) as Q103,
    cast( Q104 as varchar(400)) as Q104,
    cast( Q105 as varchar(400)) as Q105,
    cast( Q106 as varchar(400)) as Q106,
    cast( Q107 as varchar(400)) as Q107,
    cast( Q108 as varchar(400)) as Q108,
    cast( Q109 as varchar(400)) as Q109,
    cast( Q110 as varchar(400)) as Q110,
    cast( Q111 as varchar(400)) as Q111,
    cast( Q112 as varchar(400)) as Q112,
    cast( Q113 as varchar(400)) as Q113,
    cast( Q114 as varchar(400)) as Q114,
    cast( Q115 as varchar(400)) as Q115,
    cast( Q116 as varchar(400)) as Q116,
    cast( Q117 as varchar(400)) as Q117,
    cast( Q118 as varchar(400)) as Q118,
    cast( Q119 as varchar(400)) as Q119,
    cast( Q120 as varchar(400)) as Q120,
    cast( Q121 as varchar(400)) as Q121,
    cast( Q122 as varchar(400)) as Q122,
    cast( Q123 as varchar(400)) as Q123,
    cast( Q124 as varchar(400)) as Q124,
    cast( Q125 as varchar(400)) as Q125,
    cast( Q126 as varchar(400)) as Q126,
    cast( Q127 as varchar(400)) as Q127,
    cast( Q128 as varchar(400)) as Q128,
    cast( Q129 as varchar(400)) as Q129,
    cast( Q130 as varchar(400)) as Q130,
    cast( Q131 as varchar(400)) as Q131,
    cast( Q132 as varchar(400)) as Q132,
    cast( Q133 as varchar(400)) as Q133,
    cast( Q134 as varchar(400)) as Q134

from survey.SurveyForm) as p
unpivot
(
    Answer for QuestionNum in (
    [Q001], [Q002], [Q003], [Q004], [Q005], [Q006], [Q007], [Q008], [Q009], [Q010]
    , [Q011], [Q012], [Q013], [Q014], [Q015], [Q016], [Q017], [Q018], [Q019], [Q020]
    , [Q021], [Q022], [Q023], [Q024], [Q025], [Q026], [Q027], [Q028], [Q029], [Q030]
    , [Q031], [Q032], [Q033], [Q034], [Q035], [Q036], [Q037], [Q038], [Q039], [Q040]
    , [Q041], [Q042], [Q043], [Q044], [Q045], [Q046], [Q047], [Q048], [Q049], [Q050]
    , [Q051], [Q052], [Q053], [Q054], [Q055], [Q056], [Q057], [Q058], [Q059], [Q060]
    , [Q061], [Q062], [Q063], [Q064], [Q065], [Q066], [Q067], [Q068], [Q069], [Q070]
    , [Q071], [Q072], [Q073], [Q074], [Q075], [Q076], [Q077], [Q078], [Q079], [Q080]
    , [Q081], [Q082], [Q083], [Q084], [Q085], [Q086], [Q087], [Q088], [Q089], [Q090]
    , [Q091], [Q092], [Q093], [Q094], [Q095], [Q096], [Q097], [Q098], [Q099], [Q100]
    , [Q101], [Q102], [Q103], [Q104], [Q105], [Q106], [Q107], [Q108], [Q109], [Q110]
    , [Q111], [Q112], [Q113], [Q114], [Q115], [Q116], [Q117], [Q118], [Q119], [Q120]
    , [Q121], [Q122], [Q123], [Q124], [Q125], [Q126], [Q127], [Q128], [Q129], [Q130]
    , [Q131], [Q132], [Q133], [Q134]
    )
) as u
left join survey.SurveyFormMap as map on u.QuestionNum = map.ColName
go