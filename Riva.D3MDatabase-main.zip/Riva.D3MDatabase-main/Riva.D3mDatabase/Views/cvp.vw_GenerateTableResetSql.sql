create view cvp.vw_GenerateTableResetSql as

select concat('alter table ', TABLE_SCHEMA, '.', TABLE_NAME , ' nocheck constraint all;') as [sql] 
from INFORMATION_SCHEMA.tables 
where TABLE_SCHEMA = 'cvp' and TABLE_TYPE = 'BASE TABLE'

union all

select concat('delete from ', TABLE_SCHEMA, '.', TABLE_NAME , ';') as [sql] 
from INFORMATION_SCHEMA.tables 
where TABLE_SCHEMA = 'cvp' and TABLE_TYPE = 'BASE TABLE'

union all

select concat('dbcc checkident(''', TABLE_SCHEMA, '.', TABLE_NAME, ''', reseed, 0);') as [sql] 
from INFORMATION_SCHEMA.tables 
where TABLE_SCHEMA = 'cvp' and TABLE_TYPE = 'BASE TABLE'

union all

select concat('alter table ', TABLE_SCHEMA, '.', TABLE_NAME , ' with check check constraint all;') as [sql] 
from INFORMATION_SCHEMA.tables 
where TABLE_SCHEMA = 'cvp' and TABLE_TYPE = 'BASE TABLE'
;
