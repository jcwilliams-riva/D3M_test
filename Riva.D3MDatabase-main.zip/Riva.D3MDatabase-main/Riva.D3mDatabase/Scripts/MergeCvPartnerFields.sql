﻿merge into cvp.Field as t
using(
	values
	(1, 'Certifications', 0, 1),
	(2, 'Courses', 0, 1),
	(3, 'Educations', 1, 0),
	(4, 'Highlighted roles', 0, 1),
	(5, 'Honors and awards', 0, 1),
	(6, 'Languages', 0, 1),
	(7, 'Positions', 0, 1),
	(8, 'Presentations', 0, 1),
	(9, 'Project Experiences', 1, 0),
	(10, 'Publications', 0, 1),
	(11, 'Skill categories', 1, 0),
	(12, 'Summary of Qualifications', 1, 0),
	(13, 'Unique roles', 0, 1),
	(14, 'Work experiences', 1, 0),
	(15, 'Years of education', 0, 1),
	(16, 'Custom tag: Business Units', 1, 0),
	(17, 'Custom tag: Clearance/Sponsor', 1, 0),
	(18, 'Custom tag: RIVA Career Level', 1, 0),
	(19, 'Custom tag: RIVA Path', 1, 0),
	(20, 'Custom tag: Supervisor (Y/N)', 1, 0),
	(21, 'Custom tag: Years of Experience', 1, 0),
	(22, 'Custom tag: Supervisor name', 1, 0)
) as x (Id, FieldName, IsRequired, IsBeneficial)
on t.FieldName = x.FieldName
when not matched then
insert(Id, FieldName, IsRequired, IsBeneficial)
values(Id, FieldName, IsRequired, IsBeneficial);