﻿
MERGE INTO deltek.BusinessUnit AS t
USING (
	VALUES
	(1, 'CORP', 'Corporate'),
	(2, 'DOD/NS', 'DoD National Security'),
	(3, 'FEDCIV', 'Federal Civilian'),
	(4, 'FEDHEALTH', 'Federal Health'),
	(5, 'FRINGE', 'FRINGE')
) AS x (BusinessUnitId, BusinessUnitName, BusinessUnitFullName) 
	ON x.BusinessUnitId = t.BusinessUnitId

WHEN NOT MATCHED THEN
	INSERT(BusinessUnitId, BusinessUnitName, BusinessUnitFullName)
	VALUES(BusinessUnitId, BusinessUnitName, BusinessUnitFullName)
WHEN MATCHED THEN
	UPDATE SET t.BusinessUnitName = x.BusinessUnitName, t.BusinessUnitFullName = x.BusinessUnitFullName
;