﻿
MERGE INTO cvp.CustomTag AS t
USING (
	VALUES
	(1, 'RIVA Career Level'),
	(2, 'Years of Experience'),
	(3, 'Supervisor name'),
	(4, 'Supervisor (Y/N)'),
	(5, 'RIVA Path'),
	(6, 'Business Units'),
	(7, 'Clearance/Sponsor')
) AS x (TagId, TagName) ON x.TagName = t.TagName

WHEN NOT MATCHED THEN
	INSERT(TagId, TagName)
	VALUES(TagId, TagName)
;