MERGE INTO riva.Category AS t
USING (
    VALUES
    (1, 'Technical', null),
    (2, 'NonTechnical', null),
    (3, 'Applications and Services', 1),
    (4, 'Cloud and Infrastructure', 1),
    (5, 'Data and Analytics', 1),
    (6, 'Functional', 2),
    (7, 'Human Centered Design', 2),
    (8, 'Project Management', 2),
    -- Applications and Services
    (9, 'ACCESSIBILITY', 3),
    (10, 'BROWSER', 3),
    (11, 'COMMUNICATIONS_SOFTWARE', 3),
    (12, 'HEALTHCARE_APPLICATION', 3),
    (13, 'LINUX_OS', 3),
    (14, 'OPERATING_SYSTEM', 3),
    (15, 'ORDER_AND_FULFILLMENT', 3),
    (16, 'PLATFORM', 3),
    (17, 'PRODUCTIVITY_SOFTWARE', 3),
    (18, 'PROGRAMMING_LANGUAGE', 3),
    (19, 'SOFTWARE_DEVELOPMENT', 3),
    -- Cloud and Infrastructure
    (20, 'AWS_SERVICE', 4),
    (21, 'AZURE_SERVICE', 4),
    (22, 'CLOUD', 4),
    (23, 'CYBERSECURITY', 4),
    (24, 'GOOGLE_CLOUD_PLATFORM', 4),
    (25, 'IT_SERVICE', 4),
    (26, 'IT_SUPPORT', 4),
    (27, 'VIRTUALIZATION', 4),
    -- Data and Analytics
    (28, 'ANALYTICS', 5),
    (29, 'BIOINFORMATICS', 5),
    (30, 'DATA_ENGINEERING', 5),
    (31, 'DATA_GOVERNANCE', 5),
    (32, 'DATA_SCIENCE', 5),
    (34, 'DATABASE', 5),
    (35, 'DATABASE_VENDOR', 5),
    (36, 'GIS', 5),
    (37, 'HEALTHCARE_ANALYTICS', 5),
    -- Functional
    (38, 'DEFENSE_LOGISTICS', 6),
    (39, 'ENGINEERING', 6),
    (40, 'SCIENCE', 6),
    -- Human Centered Design
    (41, 'HUMAN_CENTERED_DESIGN', 7),
    -- Project Management
    (42, 'AGILE', 8),
    (43, 'MANAGEMENT', 8),
    (44, 'PROJECT_MANAGEMENT', 8),
    -- General Tech
    (45, 'General', 1),
    (46, 'TECHNOLOGY', 45)
) AS x (CategoryId, CategoryName, ParentId) ON x.CategoryId = t.CategoryId

WHEN NOT MATCHED THEN
    INSERT(CategoryId, CategoryName, ParentId)
    VALUES(CategoryId, CategoryName, ParentId)

WHEN MATCHED THEN
    UPDATE SET t.CategoryName = x.CategoryName, t.ParentId = x.ParentId
;