from services.PyCsvImport import PyCsvImport
import os
import paths
import constants
import utils
from typing import Dict
import psycopg2


if __name__ == "__main__":
    """
    Entry Point.
    Import data to PostgreSQL instance.
    2022-11-29
    John Bonfardeci
    """
    env = 'prod' # Change environment variable to local|prod.
    cred: Dict = utils.get_json(paths.PGDB_CREDENTIALS_JSON)[env]
    get_connection = lambda:psycopg2.connect(
        database=cred['database'],
        host=cred['server'],
        user=cred['uid'],
        password=cred['pwd'],
        port=cred['port']
    )
    
    importer = PyCsvImport(connection=get_connection, column_name_qualifier='""')
    conn = get_connection()
    cursor = conn.cursor()
    # Import tables.
    tables_sql: str = utils.get_file(paths.CREATE_TABLES_SQL)
    #cursor.execute(tables_sql)
    # Import views.
    views_sql: str = utils.get_file(paths.CREATE_VIEWS_SQL)
    cursor.execute(views_sql)
    cursor.close()
    conn.close()
    tables = [
        (paths.COMPANY, constants.COMPANY_TABLE_NAME),
        (paths.CODE_TYPE_CSV, constants.CODE_TYPE_TABLE_NAME),
        (paths.CODE_CSV, constants.CODE_TABLE_NAME),
        (paths.NAICS_PSC_MAP_CSV, constants.NAICS_PSC_MAP_TABLE_NAME),
        (paths.PSC_OCC_MAP_CSV, constants.PSC_OCC_MAP_TABLE_NAME),
        (paths.SPEND_CATEGORIES_PSC_MAP_CSV, constants.SPEND_CATEGORIES_PSC_MAP_TABLE_NAME)
    ]
    
    for fp, table in tables:
        table_schema, table_name = table.split(".")
        importer.from_file(
            filepath=fp,
            table_schema=table_schema,
            table_name=table_name
        )
        print(f"Imported {table_schema}.{table_name}.")
    # for