PGDB_CREDENTIALS_JSON            = './credentials/postgresql.json'
DATA_DIR                        = './data'
CODE_TYPE_CSV                   = f'{DATA_DIR}/code_type.csv'
CODE_CSV                        = f'{DATA_DIR}/code.csv'
COMPANY                         = f'{DATA_DIR}/company.csv'
SPEND_CATEGORIES_PSC_MAP_CSV    = f'{DATA_DIR}/spend_categories_psc_map.csv'
PSC_OCC_MAP_CSV                 = f'{DATA_DIR}/psc_occ_map.csv'
NAICS_PSC_MAP_CSV               = f'{DATA_DIR}/naics_psc_map.csv'

# Database DDL
CREATE_TABLES_SQL               = './tables/create_tables.pgsql'
CREATE_VIEWS_SQL                = './views/create_views.pgsql'


# CSV Data Source References:
"""
https://www.acquisition.gov/psc-manual
https://www.census.gov/naics/
https://psctool.us/mappings
"""
SPEND_CATEGORIES_PSC_MAP_URL    = 'https://psctool.us/assets/pscmap/spend_categories_psc_map.csv'
PSC_OCC_MAP_URL                 = 'https://psctool.us/assets/pscmap/psc_occ_map.csv'
NAICS_PSC_MAP_URL               = 'https://psctool.us/assets/pscmap/naics_psc_map.csv'