from typing import Any, List, Dict, Tuple
import os
import csv
import json
import requests


def get_file_extension(filepath: str):
    ext = filepath.split('.')[-1:]
    if ext:
        return '.' + ext[0].lower()
    return None


def get_file_list(dir: str, extensions: List[str]=None) -> List[str]:
    paths = []
    for dir, _, files in os.walk(dir):
        if extensions is not None and len(extensions) > 0:
            paths.extend([os.path.join(dir, fn) for fn in files if get_file_extension(fn) in extensions])
        else:
            paths.extend([os.path.join(dir, fn) for fn in files])
    return paths


def get_file(filepath: str) -> str:
    if not os.path.exists(filepath):
        raise FileNotFoundError(f'The file at {filepath} does not exist!')
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()
    
    
def get_csv(filepath: str, delimiter=',') -> Tuple[List[List[str]], List[str]]:
    data: List[List[str]] = []
    col_names = []
    if not os.path.exists(filepath):
        raise FileNotFoundError(f'The file at {filepath} does not exist!')
    with open(filepath, 'r', encoding='utf-8') as f:
        rdr = csv.reader(f, delimiter=delimiter)
        col_names = next(rdr)
        for row in rdr:
            data.append(row)
    # with
    return (data, col_names)


def get_json(filepath: str) -> Any:
    return json.loads(get_file(filepath))


def write_json(data: Any, filepath: str, indent: int=None) -> None:
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=indent)


def get_html(url:str, filepath:str, host_name:str) -> str:
    if os.path.exists(filepath):
        return get_file(filepath)

    headers = {
        'User-Agent': 'RIVA Solutions, Inc.',
        'Accept-Encoding': 'gzip, deflate',
        'Host': host_name}

    dirs = os.path.dirname(filepath)
    if not os.path.exists(dirs):
        os.makedirs(dirs, exist_ok=True)

    response = requests.get(url, headers=headers, stream=True)
    with open(filepath, "wb") as f:
        for chunk in response.iter_content(chunk_size=512):
            if chunk:
                f.write(chunk)

    return get_file(filepath)